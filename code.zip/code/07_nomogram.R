# -*- coding: utf-8 -*-
# =====================================================================
# STEP 4.1: 列线图 (Nomogram) —— HCC 生境影像组学 术前预测模型
# =====================================================================
# 目的: 为最终联合模型 (mixed_RADSCORE + AFP, 2 变量, 术前预测) 构建
#       临床可用的列线图 (逻辑回归). 仅输出列线图, 不含校准曲线 / DCA.
#
# 模型: label ~ mixed_RADSCORE + AFP  (逻辑回归, 训练集 295 例)
#   - mixed_RADSCORE: 联合影像组学评分 (连续变量, 原始尺度)
#   - AFP:           血清 AFP 分级 (1 / 2 / 3, 有序分类, 因子编码)
#   - label:         结局 (1 = 术后复发, 0 = 未复发)
#
# 输入: 第一步/output/train_selected.xlsx  (case_id, label, mixed_RADSCORE)
#       第一步/input/Train.csv              (case_id, AFP)
# 输出: 第4.1步/output/Nomogram.tiff       (300 dpi LZW TIFF, 与项目约定一致)
#
# 依赖包: rms, openxlsx
# =====================================================================

# ------------------------- 依赖包 ------------------------- #
for (pkg in c("rms", "openxlsx")) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, repos = "https://cloud.r-project.org")
  }
}
suppressPackageStartupMessages({
  library(rms)
  library(openxlsx)
})

# ------------------------- 路径定位 (跨 RStudio / Rscript) ------------------------- #
args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
if (length(file_arg) > 0) {
  script_dir <- normalizePath(dirname(sub("^--file=", "", file_arg[1])))
} else {
  script_dir <- normalizePath(dirname(rstudioapi::getActiveDocumentContext()$path))
}
base_dir   <- dirname(script_dir)                    # f:\HCC DL
step1_out  <- file.path(base_dir, "第一步", "output")
step1_in   <- file.path(base_dir, "第一步", "input")
out_dir    <- file.path(script_dir, "output")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

cat("脚本目录:", script_dir, "\n")
cat("数据目录:", step1_out, "\n")
cat("输出目录:", out_dir, "\n\n")

# ------------------------- 数据加载与整理 ------------------------- #
sel <- read.xlsx(file.path(step1_out, "train_selected.xlsx"))
clin <- read.csv(file.path(step1_in, "Train.csv"), stringsAsFactors = FALSE)

sel$case_id <- as.character(sel$case_id)
clin$case_id <- as.character(clin$case_id)

df <- merge(sel[, c("case_id", "label", "mixed_RADSCORE")],
            clin[, c("case_id", "AFP")],
            by = "case_id", all.x = TRUE)

df$label <- as.integer(df$label)
df$mixed_RADSCORE <- as.numeric(df$mixed_RADSCORE)
df$AFP <- as.integer(df$AFP)

# AFP 分级 (1/2/3) 作有序分类因子; mixed_RADSCORE 为连续变量
df$AFP <- factor(df$AFP, levels = c(1, 2, 3))

cat(sprintf("训练集: n = %d  (label 0 = %d, label 1 = %d)\n",
            nrow(df), sum(df$label == 0), sum(df$label == 1)))
cat(sprintf("mixed_RADSCORE: [%.3f, %.3f]\n",
            min(df$mixed_RADSCORE), max(df$mixed_RADSCORE)))
cat("AFP 水平分布:\n"); print(table(df$AFP, useNA = "ifany")); cat("\n")

# ------------------------- 变量标签 (用于列线图轴标签) ------------------------- #
label(df$mixed_RADSCORE) <- "Radiomics Score"
label(df$AFP)            <- "AFP Level"

# ------------------------- 逻辑回归模型 ------------------------- #
dd <- datadist(df)
options(datadist = "dd")

fit <- lrm(label ~ mixed_RADSCORE + AFP, data = df, x = TRUE, y = TRUE)

cat("========== 逻辑回归模型 ==========\n")
print(fit)
cat(sprintf("\n训练集 C-index (AUC) = %.4f\n\n", fit$stats["C"]))

# ------------------------- 列线图 ------------------------- #
nom <- nomogram(
  fit,
  fun        = plogis,
  funlabel   = "Predicted Probability",
  fun.at     = seq(0.1, 0.9, by = 0.1),
  lp         = FALSE,          # 隐藏线性预测子轴, 仅保留概率轴
  conf.int   = FALSE,          # 隐藏点轴置信区间
  maxscale   = 100
)

out_tiff <- file.path(out_dir, "Nomogram.tiff")
tiff(out_tiff, width = 11, height = 7, units = "in", res = 300,
     compression = "lzw", bg = "white")
plot(nom)
title(main = "Nomogram for Predicting HCC Recurrence Risk",
      cex.main = 1.15, font.main = 1)
dev.off()

cat("列线图已保存:", out_tiff, "\n")
