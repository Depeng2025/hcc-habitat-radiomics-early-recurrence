# -*- coding: utf-8 -*-
"""=====================================================================
影像组学生态分析: 全池联合筛选 (4 生境分区) + LASSO + 联合签名 (主流程)

建模策略 (2026-08-30 起, 术前预测模型):
  全池 1205 个特征 (瘤内 H1/H2/H3 + 瘤周5mm PERI5, 共 4 个生境分区) 统一筛选,
  最终模型 = 联合 RADSCORE + 临床 (AFP; 术前可得变量, 不含术后病理分化 Differentiation);
  区域拆分双 RADSCORE 降为敏感性对比。

流程 (与参考 notebook / R 脚本一致, 默认无泄漏):
  1. 缺失值填补 (训练集中位数, PREPROCESS_FIT_ON_TRAIN=True 时)
  2. R 式 RMS 缩放 scale(center=F, scale=T) (训练集拟合常数)
  3. 全池单因素筛选 (训练集: Shapiro+Barlett -> t/Wilcoxon, P<0.05)
  4. 全池 LASSO 10折CV (按 log-loss/deviance 选 C)
  5. 联合 RADSCORE = intercept + Σ coef × RMS缩放特征
  6. 最终模型: LR [mixed_RADSCORE + 标准化临床]
  7. 敏感性分析: 区域拆分双 RADSCORE + 临床 (仅一行对比)

输出 (output/):
  - Variable_Selection_Results.xlsx   (Table1 / 单因素·多因素逻辑回归 /
       模型性能 / 联合·区域公式 / 联合签名+临床公式 / Summary; 过程表不出)
  - radscore.csv / radscore.xlsx      (mixed_RADSCORE + intra/peri_RADSCORE + 各模型概率)
  - train/val/test_selected.xlsx      (联合筛选特征 z_* + mixed_RADSCORE, 供第二步)
  - lasso_mixed_{coef_path,cv_deviance_path,waterfall}.tiff (区域拆分不出图)
  - roc_{train,val,test}_6models.tiff (联合签名主模型实线 + 双RADSCORE+临床敏感性虚线)
  - selected_summary.md

运行: cd 第一步 && python 特征筛选.py
=====================================================================
"""

import pandas as pd
import numpy as np
import os
import io
import re
import warnings
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['axes.unicode_minus'] = False

from scipy import stats as scipy_stats
import statsmodels.api as sm
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from sklearn.metrics import roc_auc_score, roc_curve, accuracy_score, confusion_matrix
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from PIL import Image   # 用于输出 LZW 压缩的 TIFF

warnings.filterwarnings('ignore')

# ============================================================
# 配置
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STEP_DIR = BASE_DIR
INPUT_DIR = os.path.join(STEP_DIR, 'input')
OUTPUT_DIR = os.path.join(STEP_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

SEED = 42           # 随机种子 (可复现)
N_CV = 10           # LASSO 交叉验证折数
N_LAMBDA = 100      # 正则化参数网格数量

OUTCOME = 'label'                        # 结局列 (在临床文件中)
CLINICAL_COLS = ['AFP', 'Sex', 'Age']            # 临床特征 (Table 1 用)
CLIN_MODEL_COLS = ['AFP']                        # 临床/联合模型用临床特征 (术前预测模型, 仅术前可得变量)

# ---- 特征筛选参数 ----
MAX_MISSING_FRAC = 1.0        # 训练集中缺失比例超过该值的特征将被剔除 (1.0=全部保留后中位数填补)
P_SCREEN = 0.05               # 单因素筛选阈值 (P<0.05 进入 LASSO)
SHAPIRO_P_THRESH = 0.05       # Shapiro 正态性检验阈值 (参考 5_unvariate.R)
BARTLETT_P_THRESH = 0.05      # Bartlett 方差齐性检验阈值 (参考 5_unvariate.R)
USE_UNIVARIABLE_SCREEN = True # True=先单因素 P<0.05 再 LASSO (影像组学最常见流程)
ENABLE_CORRELATION_FILTER = False
CORR_THRESHOLD = 0.95

# 预处理泄漏控制: True(默认)=中位数填补 + RMS 缩放常数仅在训练集拟合, 严格无泄漏(投稿推荐)
PREPROCESS_FIT_ON_TRAIN = os.environ.get('PREPROCESS_FIT_ON_TRAIN', '1') != '0'

HABITAT_PREFIXES = ('H1_', 'H2_', 'H3_', 'PERI5_')
INTRA_PREFIXES = ('H1_', 'H2_', 'H3_')
PERI_PREFIX = 'PERI5_'

# 区域拆分定义
REGIONS = [
    {'name': 'intra', 'label': '瘤内 (H1+H2+H3)', 'prefixes': INTRA_PREFIXES,
     'out_prefix': 'intra'},
    {'name': 'peri', 'label': '瘤周5mm (PERI5)', 'prefixes': (PERI_PREFIX,),
     'out_prefix': 'peri'},
]

KNOWN_FAMILIES = {'firstorder', 'glcm', 'gldm', 'glrlm', 'glszm', 'ngtdm', 'shape'}

print('=' * 70)
print('影像组学生态分析: 全池联合筛选 (4 生境分区) + LASSO + 联合签名')
print('=' * 70)

# ============================================================
# 通用工具
# ============================================================
def parse_feature(name):
    """解析特征名 -> (Habitat, Phase, Family, Base)"""
    parts = name.split('_')
    habitat = parts[0]
    phase = parts[1] if len(parts) > 1 else ''
    if len(parts) >= 3 and parts[2] in KNOWN_FAMILIES:
        family = parts[2]
        base = '_'.join(parts[3:])
    else:
        family = phase
        base = '_'.join(parts[2:])
    return habitat, phase, family, base


def fmt_p(p):
    if isinstance(p, (int, float)) and not np.isnan(p):
        return '<0.001' if p < 0.001 else f'{p:.3f}'
    return 'NA'


def fmt_med_iqr(s):
    if s.empty:
        return 'NA'
    q1, med, q3 = np.percentile(s, [25, 50, 75])
    return f'{med:.2f} ({q1:.2f}-{q3:.2f})'


def save_fig(fig, name, dpi=300):
    """只输出 LZW 压缩 TIFF (先渲染 PNG 内存, 再 Pillow 转存), 不保留 PNG"""
    tiff_path = os.path.join(OUTPUT_DIR, name + '.tiff')
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=dpi, bbox_inches='tight')
    buf.seek(0)
    im = Image.open(buf)
    im.convert('RGB').save(tiff_path, format='TIFF', compression='tiff_lzw', dpi=(dpi, dpi))
    plt.close(fig)
    return tiff_path


def r_scale_center_false_scale_true(X, fit_mask=None):
    """R: scale(X, center=F, scale=T), root-mean-square 缩放; fit_mask 训练集拟合 (无泄漏)"""
    X = np.asarray(X, dtype=float)
    if fit_mask is None:
        denom = max(X.shape[0] - 1, 1)
        scale_values = np.sqrt(np.nansum(X ** 2, axis=0) / denom)
    else:
        Xf = X[fit_mask]
        denom = max(int(fit_mask.sum()) - 1, 1)
        scale_values = np.sqrt(np.nansum(Xf ** 2, axis=0) / denom)
    nonzero = np.isfinite(scale_values) & (scale_values > 0)
    X_scaled = X[:, nonzero] / scale_values[nonzero]
    return X_scaled, scale_values, nonzero


def _safe_shapiro_p(x, max_n=5000, seed=SEED):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 3 or np.nanstd(x) == 0:
        return np.nan
    if len(x) > max_n:
        rng = np.random.default_rng(seed)
        x = rng.choice(x, size=max_n, replace=False)
    try:
        return float(scipy_stats.shapiro(x).pvalue)
    except Exception:
        return np.nan


def _safe_bartlett_p(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y).astype(int)
    groups = [x[y == v] for v in sorted(np.unique(y))]
    groups = [g[np.isfinite(g)] for g in groups]
    if len(groups) != 2 or min(len(g) for g in groups) < 2:
        return np.nan
    if any(np.nanstd(g) == 0 for g in groups):
        return np.nan
    try:
        return float(scipy_stats.bartlett(*groups).pvalue)
    except Exception:
        return np.nan


def _safe_ttest(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y).astype(int)
    g0, g1 = x[y == 0], x[y == 1]
    g0, g1 = g0[np.isfinite(g0)], g1[np.isfinite(g1)]
    if len(g0) < 2 or len(g1) < 2 or np.nanstd(g0) == 0 or np.nanstd(g1) == 0:
        return np.nan, np.nan
    try:
        res = scipy_stats.ttest_ind(g0, g1, equal_var=False, nan_policy='omit')
        return float(res.statistic), float(res.pvalue)
    except Exception:
        return np.nan, np.nan


def _safe_wilcox(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y).astype(int)
    g0, g1 = x[y == 0], x[y == 1]
    g0, g1 = g0[np.isfinite(g0)], g1[np.isfinite(g1)]
    if len(g0) < 1 or len(g1) < 1:
        return np.nan, np.nan
    try:
        res = scipy_stats.mannwhitneyu(g0, g1, alternative='two-sided')
        return float(res.statistic), float(res.pvalue)
    except Exception:
        return np.nan, np.nan


def univariate_filter_like_R(X, y, features, missing_frac=None, p_screen=P_SCREEN):
    """参考 5_unvariate.R: Shapiro+Bartlett 均不拒绝 -> t.test, 否则 wilcox.test; P<0.05 入选 (仅训练集)"""
    rows = []
    y = np.asarray(y).astype(int)
    for f in features:
        x = np.asarray(X[f].values, dtype=float)
        ps = _safe_shapiro_p(x)
        pb = _safe_bartlett_p(x, y)
        if (not np.isnan(ps) and not np.isnan(pb)
                and ps > SHAPIRO_P_THRESH and pb > BARTLETT_P_THRESH):
            stat_v, p_v = _safe_ttest(x, y)
            test = 't-test'
        else:
            stat_v, p_v = _safe_wilcox(x, y)
            test = 'Wilcoxon'
        g0 = x[y == 0][np.isfinite(x[y == 0])]
        g1 = x[y == 1][np.isfinite(x[y == 1])]
        miss = missing_frac.get(f, np.nan) if missing_frac is not None else np.nan
        rows.append({'Feature': f, 'Shapiro_P': ps, 'Bartlett_P': pb, 'Test': test,
                     'Statistic': stat_v, 'P_value': p_v,
                     'Selected': bool(not np.isnan(p_v) and p_v < p_screen),
                     'Group0_median_IQR': fmt_med_iqr(pd.Series(g0)),
                     'Group1_median_IQR': fmt_med_iqr(pd.Series(g1)),
                     'Missing_pct_train': round(float(miss) * 100, 2) if pd.notna(miss) else np.nan})
    stat_df = pd.DataFrame(rows).sort_values('P_value', ascending=True, na_position='last')
    selected = stat_df.loc[stat_df['Selected'], 'Feature'].tolist()
    return stat_df, selected


def _calc_metrics(y, prob, threshold=0.5):
    y = np.asarray(y).astype(int)
    prob = np.asarray(prob, dtype=float)
    pred = (prob >= threshold).astype(int)
    auc = roc_auc_score(y, prob)
    acc = accuracy_score(y, pred)
    try:
        tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
        sens = tp / (tp + fn) if (tp + fn) > 0 else np.nan
        spec = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    except Exception:
        sens, spec = np.nan, np.nan
    return auc, acc, sens, spec


def youden_threshold(y_tr, p_tr):
    fpr, tpr, thr = roc_curve(y_tr, p_tr)
    j = tpr - fpr
    return thr[int(np.nanargmax(j))]


# ---------------- DeLong (Sun & Xu 2014, 与第二步主脚本一致) ----------------
def compute_midrank(x):
    J = np.argsort(x); Z = x[J]; N = len(x); T = np.zeros(N, dtype=float); i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1); i = j
    T2 = np.empty(N, dtype=float); T2[J] = T
    return T2


def fast_deLong(preds_sorted, label_1_count):
    m = label_1_count; n = preds_sorted.shape[1] - m
    pos = preds_sorted[:, :m]; neg = preds_sorted[:, m:]; k = preds_sorted.shape[0]
    tx = np.empty([k, m]); ty = np.empty([k, n]); tz = np.empty([k, m + n])
    for r in range(k):
        tx[r, :] = compute_midrank(pos[r, :])
        ty[r, :] = compute_midrank(neg[r, :])
        tz[r, :] = compute_midrank(preds_sorted[r, :])
    aucs = tz[:, :m].sum(axis=1) / m / n - float(m + 1.0) / 2.0 / n
    v01 = (tz[:, :m] - tx[:, :]) / n
    v10 = 1.0 - (tz[:, m:] - ty[:, :]) / m
    sx = np.cov(v01); sy = np.cov(v10)
    return aucs, sx / m + sy / n


def delong_roc_test(y_true, preds1, preds2):
    y_true = np.asarray(y_true, dtype=np.float64)
    idx = np.argsort(-y_true)
    y_true = y_true[idx]; preds1 = preds1[idx]; preds2 = preds2[idx]
    m = int(y_true.sum())
    aucs, cov = fast_deLong(np.vstack((preds1, preds2)), m)
    try:
        z = (aucs[0] - aucs[1]) / np.sqrt(cov[0, 0] + cov[1, 1] - 2 * cov[0, 1])
        p = 2 * (1 - scipy_stats.norm.cdf(abs(z)))
    except Exception:
        z, p = np.nan, np.nan
    return z, p


# ============================================================
# 1. 加载数据 + 合并临床分集
# ============================================================
print(f'\n[1/11] 加载数据...')
hab_path = os.path.join(INPUT_DIR, 'habitat_features.csv')
clin_paths = {s: os.path.join(INPUT_DIR, f'{s}.csv') for s in ['Train', 'Val', 'Test']}
if not all(os.path.exists(p) for p in [hab_path] + list(clin_paths.values())):
    print('错误: 缺少输入文件, 请将 habitat_features.csv 和 Train/Val/Test.csv 放入 input/')
    exit(1)

hab = pd.read_csv(hab_path)
clin_list = []
for s in ['Train', 'Val', 'Test']:
    d = pd.read_csv(clin_paths[s])
    d['split'] = s
    clin_list.append(d)
clin = pd.concat(clin_list, ignore_index=True)

df = hab.merge(clin, on='case_id', how='inner')
y = df[OUTCOME].values
split_arr = df['split'].values
is_train = split_arr == 'Train'
is_val = split_arr == 'Val'
is_test = split_arr == 'Test'
print(f'  样本 {len(df)}: 训练 {int(is_train.sum())} | 验证 {int(is_val.sum())} | 测试 {int(is_test.sum())}')
print(f'  训练集阳性率: {y[is_train].mean()*100:.1f}% | 验证集 {y[is_val].mean()*100:.1f}% | 测试集 {y[is_test].mean()*100:.1f}%')

feat_cols = [c for c in df.columns if c.startswith(HABITAT_PREFIXES)]
print(f'  影像组学特征列: {len(feat_cols)} 个 (瘤内 H1/H2/H3 + 瘤周5mm PERI5)')

X_all = df[feat_cols].astype(float).copy()

# ============================================================
# 2. 缺失值填充 (训练集中位数, 无泄漏默认)
# ============================================================
print(f'\n[2/11] 缺失值填充 ({"训练集中位数" if PREPROCESS_FIT_ON_TRAIN else "全部样本中位数"})...')
X_train_raw = X_all[is_train]
nan_frac_train = X_train_raw.isna().mean()

drop_missing = [c for c in feat_cols if nan_frac_train[c] > MAX_MISSING_FRAC]
if drop_missing:
    print(f'  缺失率>{MAX_MISSING_FRAC*100:.0f}% 剔除 {len(drop_missing)} 个特征')
    keep_feats = [c for c in feat_cols if c not in drop_missing]
else:
    keep_feats = list(feat_cols)
X_all = X_all[keep_feats]

if PREPROCESS_FIT_ON_TRAIN:
    impute_values = X_all.loc[is_train].median()
else:
    impute_values = X_all.median()
X_imp = X_all.fillna(impute_values)

std0 = [c for c in keep_feats if X_imp.loc[is_train, c].std() < 1e-12]
if std0:
    keep_feats = [c for c in keep_feats if c not in std0]
    X_imp = X_imp[keep_feats]
print(f'  填补后用于分析的特征数: {len(keep_feats)}')

# ============================================================
# 3. R 式 RMS 缩放 scale(center=F, scale=T) (训练集拟合常数)
# ============================================================
print(f'\n[3/11] R 式 RMS 缩放 ({"训练集拟合常数, 严格无泄漏" if PREPROCESS_FIT_ON_TRAIN else "全部样本"})...')
fit_mask = np.asarray(is_train) if PREPROCESS_FIT_ON_TRAIN else None
X_scaled_arr, rms_scale, nonzero_mask = r_scale_center_false_scale_true(X_imp.values.astype(float), fit_mask=fit_mask)
feature_names = X_imp.columns[nonzero_mask].tolist()
X_z = pd.DataFrame(X_scaled_arr, columns=feature_names, index=X_imp.index)
if len(feature_names) < X_imp.shape[1]:
    print(f'  剔除零尺度特征: {int(X_imp.shape[1] - len(feature_names))} 个')
keep_feats = feature_names
X_imp = X_imp[keep_feats]
rms_series = pd.Series(rms_scale[nonzero_mask], index=feature_names)
print(f'  保留特征: 瘤内池 {len([f for f in keep_feats if f.startswith(INTRA_PREFIXES)])} | '
      f'瘤周池 {len([f for f in keep_feats if f.startswith(PERI_PREFIX)])}')

# ============================================================
# 4. 临床基线特征表 (Table 1)
# ============================================================
print(f'\n[4/11] 临床基线特征表 (Table 1)...')
g0 = df[df[OUTCOME] == 0]
g1 = df[df[OUTCOME] == 1]
g0_lab = f'Label=0 (N={len(g0)})'
g1_lab = f'Label=1 (N={len(g1)})'

table1_rows = []
for var in CLINICAL_COLS:
    if var == 'Age':
        a0 = g0[var].astype(float); a1 = g1[var].astype(float)
        shp = scipy_stats.shapiro(pd.concat([a0, a1]))[1]
        if shp > 0.05:
            m0, s0 = a0.mean(), a0.std(); m1, s1 = a1.mean(), a1.std()
            t, p = scipy_stats.ttest_ind(a0.dropna(), a1.dropna())
            table1_rows.append({'Variable': f'{var} (mean ± SD)', g0_lab: f'{m0:.1f} ± {s0:.1f}',
                                g1_lab: f'{m1:.1f} ± {s1:.1f}', 'P-value': fmt_p(p), 'Test': 't-test'})
        else:
            table1_rows.append({'Variable': f'{var} (median, IQR)', g0_lab: fmt_med_iqr(a0),
                                g1_lab: fmt_med_iqr(a1), 'P-value': fmt_p(scipy_stats.mannwhitneyu(a0, a1)[1]),
                                'Test': 'Mann-Whitney U'})
    else:
        lev = sorted(df[var].dropna().unique())
        cells0 = {k: int((g0[var] == k).sum()) for k in lev}
        cells1 = {k: int((g1[var] == k).sum()) for k in lev}
        pct0 = {k: 100.0 * cells0[k] / max(len(g0), 1) for k in lev}
        pct1 = {k: 100.0 * cells1[k] / max(len(g1), 1) for k in lev}
        n0_str = '; '.join([f'{k}: {cells0[k]} ({pct0[k]:.1f}%)' for k in lev])
        n1_str = '; '.join([f'{k}: {cells1[k]} ({pct1[k]:.1f}%)' for k in lev])
        ct = pd.crosstab(df[OUTCOME], df[var])
        correction = len(lev) == 2
        chi2, p, _, _ = scipy_stats.chi2_contingency(ct, correction=correction)
        test = 'Chi-square (Yates)' if correction else 'Chi-square'
        table1_rows.append({'Variable': var, g0_lab: n0_str, g1_lab: n1_str,
                            'P-value': fmt_p(p), 'Test': test})
table1_df = pd.DataFrame(table1_rows)
print(f'  临床变量 {len(table1_df)} 个比较完成')

# ============================================================
# 5. 逐区域单因素筛选 (训练集)
# ============================================================
print(f'\n[5/11] 逐区域单因素筛选 (训练集, P<{P_SCREEN})...')
X_imp_tr = X_imp.loc[is_train]
y_tr = y[is_train]
Cs = np.logspace(-3, 3, N_LAMBDA)

region_results = {}
for rg in REGIONS:
    rname = rg['name']
    feats = [f for f in keep_feats if f.startswith(rg['prefixes'])]
    print(f'  [{rname}] 区域特征 {len(feats)} 个...')
    uni_df, uni_sig = univariate_filter_like_R(
        X_imp_tr, y_tr, feats, missing_frac=nan_frac_train, p_screen=P_SCREEN)
    parse_map = {f: parse_feature(f) for f in feats}
    uni_df['Habitat'] = uni_df['Feature'].map(lambda f: parse_map[f][0])
    uni_df['Phase'] = uni_df['Feature'].map(lambda f: parse_map[f][1])
    uni_df['Family'] = uni_df['Feature'].map(lambda f: parse_map[f][2])
    uni_df['Significant_P<0.05'] = uni_df['Selected'].map(lambda b: 'Yes' if b else 'No')
    n_ttest = int((uni_df['Test'] == 't-test').sum())
    n_wilcox = int((uni_df['Test'] == 'Wilcoxon').sum())
    lasso_feats = uni_sig if USE_UNIVARIABLE_SCREEN else list(feats)
    print(f'    P<0.05 显著 {len(uni_sig)}/{len(feats)} (t-test {n_ttest}, Wilcoxon {n_wilcox}); 进入 LASSO {len(lasso_feats)}')
    region_results[rname] = {'feats': feats, 'uni_df': uni_df, 'uni_sig': uni_sig,
                             'lasso_feats': lasso_feats}

# ============================================================
# 6. 逐区域 LASSO 10 折 CV
# ============================================================
print(f'\n[6/11] 逐区域 LASSO 10折CV (按 CV 对数损失/deviance 选 C)...')

def add_feature_count_top_axis(ax, log_lambdas, counts, max_ticks=8):
    order = np.argsort(log_lambdas)
    x_s = log_lambdas[order]
    c_s = np.asarray(counts)[order]
    change_idx = np.unique(np.r_[0, np.where(np.diff(c_s) != 0)[0] + 1, len(x_s) - 1])
    if len(change_idx) > max_ticks:
        change_idx = change_idx[np.linspace(0, len(change_idx) - 1, max_ticks, dtype=int)]
    ax2 = ax.twiny()
    ax2.set_xlim(ax.get_xlim())
    ax2.set_xticks(x_s[change_idx])
    ax2.set_xticklabels([str(int(v)) for v in c_s[change_idx]])
    ax2.set_xlabel('Number of Selected Features', labelpad=10)
    return ax2


def run_region_lasso(rname, plot_figs=True):
    rg = region_results[rname]
    lasso_feats = rg['lasso_feats']
    if len(lasso_feats) == 0:
        print(f'  [{rname}] 无特征通过筛选, 跳过')
        return None
    X_z_train = X_z.loc[is_train, lasso_feats].values
    lasso = LogisticRegressionCV(Cs=Cs, penalty='l1', solver='liblinear',
                                 cv=N_CV, scoring='neg_log_loss',
                                 random_state=SEED, max_iter=10000, n_jobs=-1)
    lasso.fit(X_z_train, y_tr)
    Cs_grid = lasso.Cs_
    best_C = float(lasso.C_[0])
    best_idx = int(np.argmin(np.abs(Cs_grid - best_C)))
    scores = np.asarray(lasso.scores_[1])
    if scores.ndim == 3:
        scores = scores[0]
    cv_nll_mean = scores.mean(axis=0)
    cv_nll_std = scores.std(axis=0)
    cv_dev_mean = -2.0 * cv_nll_mean
    cv_dev_std = 2.0 * cv_nll_std
    best_nll = float(cv_nll_mean[best_idx])
    final_coef = lasso.coef_[0]
    intercept_z = float(lasso.intercept_[0])
    best_lambda = 1.0 / best_C

    sel_idx = [i for i in range(len(lasso_feats)) if abs(final_coef[i]) > 1e-6]
    lasso_selected = [lasso_feats[i] for i in sel_idx]
    coef_z_sel = final_coef[sel_idx]
    coef_orig = np.array([coef_z_sel[k] / rms_series[f] for k, f in enumerate(lasso_selected)])
    lasso_coefs = {lasso_feats[i]: final_coef[i] for i in range(len(lasso_feats))}

    print(f'  [{rname}] 最优 C={best_C:.4f} (lambda={best_lambda:.4f}), CV log-loss={-best_nll:.4f}, '
          f'LASSO 选中 {len(lasso_selected)} 个:')

    # ---- LASSO 系数路径 + CV 偏差路径 + 瀑布图 (每区域; 联合混合模型不出图) ----
    if plot_figs:
        coef_path = []
        for C in Cs_grid:
            lr = LogisticRegression(penalty='l1', solver='liblinear', C=C, max_iter=10000, random_state=SEED)
            lr.fit(X_z_train, y_tr)
            coef_path.append(lr.coef_[0])
        coef_path = np.array(coef_path)
        lambdas = 1.0 / Cs_grid
        x_axis = np.log(lambdas)
        lasso_feat_counts = (np.abs(coef_path) > 1e-6).sum(axis=1)

        # 系数路径
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(x_axis, coef_path, lw=0.6, color='0.80', alpha=0.7)
        sel_colors = ['#E74C3C' if final_coef[i] > 0 else '#3498DB' for i in sel_idx]
        for k, i in enumerate(sel_idx):
            ax.plot(x_axis, coef_path[:, i], lw=2.2, color=sel_colors[k], label=lasso_feats[i])
        ax.axvline(np.log(best_lambda), color='red', ls='--', lw=1.5, label=f'lambda={best_lambda:.4f}')
        ax.set_xlabel('log(lambda)'); ax.set_ylabel('Standardized Coefficients')
        ax.set_title(f'LASSO Coefficient Path ({rname})')
        ax.legend(loc='center left', bbox_to_anchor=(1.02, 0.5), fontsize=8)
        ax.axhline(0, color='black', lw=0.5); ax.grid(alpha=0.3)
        add_feature_count_top_axis(ax, x_axis, lasso_feat_counts)
        plt.tight_layout()
        save_fig(fig, f'lasso_{rname}_coef_path', dpi=150)

        # CV 偏差路径
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(x_axis, cv_dev_mean, color='black', lw=2, label='Mean deviance', zorder=3)
        ax.errorbar(x_axis, cv_dev_mean, yerr=cv_dev_std, fmt='none', ecolor='#808080',
                    alpha=0.6, elinewidth=1, capsize=3, capthick=1, label='±1 SD')
        ax.axvline(np.log(best_lambda), color='red', ls='--', lw=1.5,
                   label=f'lambda={best_lambda:.4f}', zorder=2)
        ax.scatter([np.log(best_lambda)], [cv_dev_mean[best_idx]], color='red', s=80, zorder=5)
        ax.set_xlabel('log(lambda)'); ax.set_ylabel('Mean Deviance (10-fold CV)')
        ax.set_title(f'LASSO CV Deviance Path ({rname})')
        ax.legend(loc='lower left', fontsize=10); ax.grid(alpha=0.3)
        add_feature_count_top_axis(ax, x_axis, lasso_feat_counts)
        plt.tight_layout()
        save_fig(fig, f'lasso_{rname}_cv_deviance_path', dpi=300)

        # 瀑布图
        coef_sorted = sorted(lasso_coefs.items(), key=lambda x: x[1])
        vars_w = [v[0] for v in coef_sorted if abs(v[1]) > 1e-6]
        coefs_w = [v[1] for v in coef_sorted if abs(v[1]) > 1e-6]
        colors_w = ['#E74C3C' if c > 0 else '#3498DB' for c in coefs_w]
        fig, ax = plt.subplots(figsize=(10, 6))
        bars = ax.barh(range(len(vars_w)), coefs_w, color=colors_w)
        for i, c in enumerate(coefs_w):
            ax.text(c + (0.01 if c > 0 else -0.01), i, f'{c:.3f}',
                    va='center', ha='left' if c > 0 else 'right', fontsize=9)
        ax.set_yticks(range(len(vars_w))); ax.set_yticklabels(vars_w, fontsize=9)
        ax.set_xlabel('Standardized Coefficients')
        ax.set_title(f'LASSO Selected Features ({rname}, lambda={best_lambda:.4f})')
        ax.axvline(0, color='black', lw=0.8); ax.grid(alpha=0.3, axis='x')
        from matplotlib.patches import Patch
        ax.legend(handles=[Patch(facecolor='#E74C3C', label='Positive (coef>0)'),
                           Patch(facecolor='#3498DB', label='Negative (coef<0)')],
                  loc='lower right', fontsize=10)
        plt.tight_layout()
        save_fig(fig, f'lasso_{rname}_waterfall', dpi=300)

    for i in sel_idx:
        print(f'    {lasso_feats[i]}: {final_coef[i]:.4f}')

    return {'lasso': lasso, 'best_C': best_C, 'best_lambda': best_lambda,
            'best_nll': best_nll, 'cv_dev_mean': cv_dev_mean, 'cv_dev_std': cv_dev_std,
            'lasso_selected': lasso_selected, 'coef_z_sel': coef_z_sel,
            'coef_orig': coef_orig, 'intercept_z': intercept_z,
            'lasso_coefs': lasso_coefs, 'sel_idx': sel_idx, 'lasso_feats': lasso_feats}


region_lasso = {}
for rg in REGIONS:
    # 区域拆分已降为敏感性分析: 不出 LASSO 图
    region_lasso[rg['name']] = run_region_lasso(rg['name'], plot_figs=False)

# ============================================================
# 7. 双 RADSCORE 与模型构建
# ============================================================
print(f'\n[7/11] 构建双 RADSCORE 与模型...')

intra_rs = pd.Series(region_lasso['intra']['intercept_z']
                     + X_z[region_lasso['intra']['lasso_selected']].values.astype(float)
                     @ region_lasso['intra']['coef_z_sel'], index=df.index, name='intra_RADSCORE')
peri_rs = pd.Series(region_lasso['peri']['intercept_z']
                    + X_z[region_lasso['peri']['lasso_selected']].values.astype(float)
                    @ region_lasso['peri']['coef_z_sel'], index=df.index, name='peri_RADSCORE')

# 临床预处理 (训练集拟合中位数 + StandardScaler)
clin_train = df.loc[is_train, CLIN_MODEL_COLS].apply(pd.to_numeric, errors='coerce')
clin_med = clin_train.median().fillna(0.0)
clin_scaler = StandardScaler().fit(clin_train.fillna(clin_med).values)


def prep_clin(sub):
    return sub[CLIN_MODEL_COLS].apply(pd.to_numeric, errors='coerce').fillna(clin_med)


Xclin = {'tr': clin_scaler.transform(prep_clin(df.loc[is_train]).values),
         'va': clin_scaler.transform(prep_clin(df.loc[is_val]).values),
         'te': clin_scaler.transform(prep_clin(df.loc[is_test]).values)}

# 区域 radscore 每分集
i_rs = {'tr': intra_rs.values[is_train], 'va': intra_rs.values[is_val], 'te': intra_rs.values[is_test]}
p_rs = {'tr': peri_rs.values[is_train], 'va': peri_rs.values[is_val], 'te': peri_rs.values[is_test]}

MODEL_DEFS = [
    ('Mixed',              '联合签名 (4生境分区) + 临床 (最终模型, 术前预测)'),
    ('Clinical',           '临床模型 (AFP)'),
    ('Intra',              '瘤内 RADSCORE (敏感性)'),
    ('Peri',               '瘤周5mm RADSCORE (敏感性)'),
    ('Intra+Peri',         '双 RADSCORE (敏感性)'),
    ('双RADSCORE+临床',      '敏感性: 双 RADSCORE + AFP'),
]

# 图中英文标签 (仅用于 ROC 图; 工作簿 Model_Performance 与汇总 MD 仍用中文模型名)
ROC_LABELS = {
    'Mixed':             'Joint 4-habitat signature + AFP (Final model)',
    'Clinical':          'Clinical (AFP)',
    'Intra':             'Intra-tumoral RADSCORE (sensitivity)',
    'Peri':              'Peri-tumoral (5 mm) RADSCORE (sensitivity)',
    'Intra+Peri':        'Dual RADSCORE (sensitivity)',
    '双RADSCORE+临床':     'Sensitivity: Dual RADSCORE + AFP',
}

models = {}

def fit_model(name, make_X):
    lr = LogisticRegression(max_iter=10000, random_state=SEED)
    lr.fit(make_X('tr'), y_tr)
    models[name] = {'lr': lr,
                    'tr': lr.predict_proba(make_X('tr'))[:, 1],
                    'va': lr.predict_proba(make_X('va'))[:, 1],
                    'te': lr.predict_proba(make_X('te'))[:, 1]}


fit_model('Clinical', lambda k: Xclin[k])
fit_model('Intra', lambda k: i_rs[k].reshape(-1, 1))
fit_model('Peri', lambda k: p_rs[k].reshape(-1, 1))
fit_model('Intra+Peri', lambda k: np.column_stack([i_rs[k], p_rs[k]]))
fit_model('双RADSCORE+临床', lambda k: np.column_stack([i_rs[k], p_rs[k], Xclin[k]]))

# ============================================================
# 8. 主流程: 全池联合筛选 (4 生境分区 H1/H2/H3/PERI5 合并 → LASSO radscore + 临床)
#    联合签名 = 主模型; 区域拆分双 RADSCORE 降为敏感性对比
# ============================================================
print(f'\n[8/11] 主流程: 全池联合筛选 (4 生境分区) LASSO radscore + 临床...')
mix_feats = list(keep_feats)
mix_uni, mix_sig = univariate_filter_like_R(X_imp_tr, y_tr, mix_feats,
                                            missing_frac=nan_frac_train, p_screen=P_SCREEN)
region_results['mixed'] = {'feats': mix_feats, 'uni_df': mix_uni, 'uni_sig': mix_sig,
                           'lasso_feats': mix_sig if USE_UNIVARIABLE_SCREEN else mix_feats}
print(f'  全池 {len(mix_feats)} 特征, 单因素显著 {len(mix_sig)}, 进入 LASSO {len(mix_sig)}')
mixed_lasso = run_region_lasso('mixed', plot_figs=True)
region_lasso['mixed'] = mixed_lasso

if mixed_lasso is not None:
    mixed_rs = pd.Series(mixed_lasso['intercept_z']
                         + X_z[mixed_lasso['lasso_selected']].values.astype(float)
                         @ mixed_lasso['coef_z_sel'], index=df.index, name='mixed_RADSCORE')
    m_rs = {'tr': mixed_rs.values[is_train], 'va': mixed_rs.values[is_val], 'te': mixed_rs.values[is_test]}
    fit_model('Mixed', lambda k: np.column_stack([m_rs[k], Xclin[k]]))
    z_dual_vs_mixed, p_dual_vs_mixed = delong_roc_test(y[is_val], models['双RADSCORE+临床']['va'],
                                                       models['Mixed']['va'])
    print(f'  验证集 DeLong: 联合签名 vs 双RADSCORE+临床(敏感性) = {z_dual_vs_mixed:.3f}, P={p_dual_vs_mixed:.4f}')
else:
    mixed_rs = None
    z_dual_vs_mixed, p_dual_vs_mixed = np.nan, np.nan

# ---- ROC 图 (联合签名主模型实线强调 + 双RADSCORE+临床敏感性虚线 + 区域/临床细实线) ----
print(f'\n[8/11] ROC 曲线图...')
ROC_ORDER = ['Mixed', 'Clinical', 'Intra', 'Peri', 'Intra+Peri', '双RADSCORE+临床']
ROC_LINE = {
    'Mixed':          {'color': '#E67E22', 'lw': 2.6, 'ls': '-'},
    'Clinical':       {'color': '#95A5A6', 'lw': 1.4, 'ls': '-'},
    'Intra':          {'color': '#E74C3C', 'lw': 1.4, 'ls': '-'},
    'Peri':           {'color': '#3498DB', 'lw': 1.4, 'ls': '-'},
    'Intra+Peri':     {'color': '#9B59B6', 'lw': 1.4, 'ls': '-'},
    '双RADSCORE+临床':  {'color': '#16A085', 'lw': 1.6, 'ls': '--'},
}
SET_MASK = {'train': is_train, 'val': is_val, 'test': is_test}
SET_KEY = {'train': 'tr', 'val': 'va', 'test': 'te'}
SET_EN = {'train': 'Training Set', 'val': 'Validation Set', 'test': 'Test Set'}
for set_name in ['train', 'val', 'test']:
    mask = SET_MASK[set_name]
    skey = SET_KEY[set_name]
    y_set = y[mask]
    fig, ax = plt.subplots(figsize=(6.8, 6.8))
    for mname in ROC_ORDER:
        if mname not in models or models[mname] is None:
            continue
        p = models[mname][skey]
        fpr, tpr, _ = roc_curve(y_set, p)
        auc = roc_auc_score(y_set, p)
        st = ROC_LINE[mname]
        ax.plot(fpr, tpr, lw=st['lw'], ls=st['ls'], color=st['color'],
                label=f'{ROC_LABELS[mname]} (AUC={auc:.3f})')
    ax.plot([0, 1], [0, 1], color='gray', ls=':', lw=1.2)
    ax.set_xlabel('1 - Specificity'); ax.set_ylabel('Sensitivity')
    ax.set_title(f'ROC Curves - {SET_EN[set_name]}')
    ax.legend(loc='lower right', fontsize=8)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    save_fig(fig, f'roc_{set_name}_6models')

# ---- DeLong 两两 P 矩阵 (验证集, 5 模型) ----
delong_pairs = []
delong_models = ['Intra', 'Peri', 'Intra+Peri', '双RADSCORE+临床']
if models.get('Mixed') is not None:
    delong_models.append('Mixed')
y_va = y[is_val]
for i in range(len(delong_models)):
    for j in range(i + 1, len(delong_models)):
        zz, pp = delong_roc_test(y_va, models[delong_models[i]]['va'], models[delong_models[j]]['va'])
        delong_pairs.append({'Model_A': delong_models[i], 'Model_B': delong_models[j],
                             'DeLong_Z': zz, 'DeLong_P': pp})
delong_df = pd.DataFrame(delong_pairs).sort_values('DeLong_P')
delong_df.to_csv(os.path.join(OUTPUT_DIR, 'delong_validation_5models.csv'), index=False, encoding='utf-8-sig')
print('  验证集 DeLong 两两 P 矩阵已保存 delong_validation_5models.csv')

# ============================================================
# 9. 单因素 / 多因素逻辑回归 (训练集, 联合 RADSCORE + 临床)
# ============================================================
print(f'\n[9/11] 单因素 / 多因素逻辑回归 (训练集)...')
from statsmodels.stats.outliers_influence import variance_inflation_factor

PRED_LABEL = [
    ('Mixed_RADSCORE', '联合 RADSCORE (4生境)'),
    ('AFP', 'AFP (ng/mL)'),
    ('Sex', 'Sex'),
    ('Age', 'Age (yr)'),
]
PRED_COLS = [p[0] for p in PRED_LABEL]

analysis_df = pd.DataFrame({OUTCOME: y[is_train]})
analysis_df['Mixed_RADSCORE'] = mixed_rs.values[is_train]
for c in ['AFP', 'Sex', 'Age']:
    # 按位置赋 numpy 数组 (与 y[is_train] 对齐), 避免 merge 后索引标签错位导致的隐性丢行
    analysis_df[c] = pd.to_numeric(df.loc[is_train, c], errors='coerce').to_numpy()

# ---- 单因素 ----
uni_log_rows = []
for col, lab in PRED_LABEL:
    d = analysis_df[[OUTCOME, col]].dropna()
    X = sm.add_constant(d[col])
    try:
        res = sm.Logit(d[OUTCOME], X).fit(disp=0)
        ci = res.conf_int().loc[col]
        uni_log_rows.append({'Variable': lab, 'Coefficient': res.params[col], 'SE': res.bse[col],
                             'OR': np.exp(res.params[col]),
                             'OR_95CI_low': np.exp(ci[0]), 'OR_95CI_high': np.exp(ci[1]),
                             'P_value': res.pvalues[col], 'N': len(d)})
    except Exception:
        uni_log_rows.append({'Variable': lab, 'Coefficient': np.nan, 'SE': np.nan,
                             'OR': np.nan, 'OR_95CI_low': np.nan, 'OR_95CI_high': np.nan,
                             'P_value': np.nan, 'N': len(d)})
uni_log_df = pd.DataFrame(uni_log_rows)


def vif_series(d):
    """VIF 需先加截距列 (statsmodels 标准用法); 不加截距会用无截距 R^2, 高估非中心变量 VIF"""
    Xv = sm.add_constant(d).values.astype(float)   # 第 0 列为常数
    return pd.Series([variance_inflation_factor(Xv, i + 1) for i in range(Xv.shape[1] - 1)],
                     index=d.columns)


def multivariable_logistic(dfa, candidates, outcome=OUTCOME, vif_thresh=10.0):
    """多因素逻辑回归: 含截距 VIF>vif_thresh 逐步剔除, 返回 (rows, vif_removed)"""
    mv_cols = list(candidates)
    vif_removed = []
    for _ in range(8):
        d = dfa[[outcome] + mv_cols].dropna()
        if len(mv_cols) <= 1:
            break
        v = vif_series(d[mv_cols])
        if v.max() > vif_thresh:
            drop = v.idxmax()
            vif_removed.append((drop, round(float(v.max()), 2)))
            mv_cols.remove(drop)
        else:
            break
    d = dfa[[outcome] + mv_cols].dropna()
    Xm = sm.add_constant(d[mv_cols])
    res = sm.Logit(d[outcome], Xm).fit(disp=0)
    vif_final = vif_series(d[mv_cols])
    ci = res.conf_int()
    rows = [{'Variable': c, 'Coefficient': res.params[c], 'SE': res.bse[c],
             'OR': np.exp(res.params[c]),
             'OR_95CI_low': np.exp(ci.loc[c, 0]), 'OR_95CI_high': np.exp(ci.loc[c, 1]),
             'P_value': res.pvalues[c], 'VIF': vif_final[c], 'N': len(d)} for c in mv_cols]
    return rows, vif_removed


# ---- 主流程多因素 (VIF>10 逐步剔除, 含截距 VIF) ----
mv_log_rows, vif_removed = multivariable_logistic(analysis_df, PRED_COLS)
mv_log_df = pd.DataFrame(mv_log_rows)
if vif_removed:
    print(f'  多因素 VIF>10 剔除: {vif_removed}')
print(f'  主流程多因素最终纳入 {len(mv_log_df)} 个变量 (N={mv_log_df["N"].iloc[0]})')

# ---- 敏感性: 区域拆分多因素 (瘤内/瘤周 RADSCORE + 临床, 与主流程同一候选结构) ----
analysis_df['intra_RADSCORE'] = i_rs['tr']
analysis_df['peri_RADSCORE'] = p_rs['tr']
region_mv = {}
for rs_col, rs_lab in [('intra_RADSCORE', 'Intra RADSCORE (瘤内, 敏感性)'),
                       ('peri_RADSCORE', 'Peri RADSCORE (瘤周5mm, 敏感性)')]:
    cands = [rs_col] + PRED_COLS[1:]   # RADSCORE + AFP + Sex + Age (术前预测)
    rows, vif_rm = multivariable_logistic(analysis_df, cands)
    for r in rows:
        r['Region_model'] = rs_lab
    region_mv[rs_col] = {'rows': rows, 'vif_removed': vif_rm, 'n_included': len(rows)}
    print(f'  敏感性 [{rs_lab}]: 纳入 {len(rows)} 个变量'
          + (f', VIF>10 剔除 {vif_rm}' if vif_rm else ', 无剔除'))

# ============================================================
# 10. 输出 Excel (Variable_Selection_Results.xlsx)
# ============================================================
print(f'\n[10/11] 输出 Excel...')

HEADER_FILL = PatternFill(start_color='305496', end_color='305496', fill_type='solid')
HEADER_FONT = Font(color='FFFFFF', bold=True, size=11)
ALT_FILL = PatternFill(start_color='DDEBF7', end_color='DDEBF7', fill_type='solid')
THIN = Side(style='thin', color='BFBFBF')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def write_df(ws, df, start_row=1, start_col=1, col_widths=None, index=False, num_format=None):
    if df is None or df.empty:
        return start_row
    if col_widths is None:
        col_widths = {}
    header = ([''] + list(df.columns)) if index else list(df.columns)
    for j, h in enumerate(header):
        c = ws.cell(row=start_row, column=start_col + j, value=h)
        c.fill = HEADER_FILL; c.font = HEADER_FONT
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        c.border = BORDER
    rows = list(df.itertuples(index=index))
    for i, row in enumerate(rows):
        r = start_row + 1 + i
        for j in range(len(header)):
            v = row[0] if j == 0 and index else row[j]
            if isinstance(v, (float, np.float64)) and pd.isna(v):
                v = ''
            c = ws.cell(row=r, column=start_col + j, value=v)
            c.border = BORDER
            c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            if num_format and j >= 1 and isinstance(v, (int, float)):
                c.number_format = num_format
            if i % 2 == 1:
                c.fill = ALT_FILL
    # 列宽
    for j, h in enumerate(header):
        col_letter = get_column_letter(start_col + j)
        if col_letter in col_widths:
            ws.column_dimensions[col_letter].width = col_widths[col_letter]
            continue
        col_idx = (j - 1) if index else j
        vals = [str(h)]
        if col_idx >= 0:
            vals += list(df.iloc[:, col_idx].astype(str).tolist())
        max_len = max(len(v) for v in vals)
        ws.column_dimensions[col_letter].width = min(max(max_len * 1.4 + 2, 10), 60)
    ws.row_dimensions[start_row].height = 22
    return start_row + 1 + len(df)


wb = Workbook()
wb.remove(wb.active)

# ---- Table1 ----
ws = wb.create_sheet('Table1_Baseline')
r = write_df(ws, table1_df, col_widths={'A': 26, 'B': 34, 'C': 34, 'D': 12, 'E': 14})

# ---- 单因素 / 多因素逻辑回归 ----
ws = wb.create_sheet('Univariable_Logistic')
write_df(ws, uni_log_df, col_widths={'A': 22, 'B': 12, 'C': 10, 'D': 10, 'E': 10, 'F': 10, 'G': 10, 'H': 8})

ws = wb.create_sheet('Multivariable_Logistic')
write_df(ws, mv_log_df, col_widths={'A': 22, 'B': 12, 'C': 10, 'D': 10, 'E': 10, 'F': 10, 'G': 10, 'H': 8})
if vif_removed:
    note_col = mv_log_df.shape[1] + 1
    ws.cell(row=1, column=note_col, value='多因素 VIF>10 剔除顺序')
    ws.cell(row=1, column=note_col).font = Font(bold=True, color='C0392B')
    for k, (col, vifv) in enumerate(vif_removed):
        ws.cell(row=2 + k, column=note_col, value=f'{col} (VIF={vifv})')

# ---- 敏感性: 区域拆分多因素 (瘤内/瘤周 RADSCORE + 临床) ----
region_mv_rows = []
for rs_col in ['intra_RADSCORE', 'peri_RADSCORE']:
    region_mv_rows += region_mv[rs_col]['rows']
ws = wb.create_sheet('MV_Logistic_RegionSplit')
write_df(ws, pd.DataFrame(region_mv_rows),
         col_widths={'A': 28, 'B': 22, 'C': 12, 'D': 10, 'E': 10, 'F': 10, 'G': 10, 'H': 8, 'I': 8})

# ---- 逐区域单因素筛选全表: 纯过程输出 (~1600 行统计), 不进 xlsx / csv, 需要时重跑脚本生成 ----

# ---- LASSO 全系数 / 选中变量明细: 与下方 Radscore_Formula 表重复, 不再单独出表 ----

# ---- 正则化参数 (最优 C / lambda): 过程参数, 已在 Summary 与说明 MD 报告, 不再单独出表 ----

# ---- 模型性能 ----
ws = wb.create_sheet('Model_Performance')
perf_rows = []
for mname, mlab in MODEL_DEFS:
    if mname not in models or models[mname] is None:
        continue
    row = {'Model': mlab}
    thr = youden_threshold(y_tr, models[mname]['tr'])  # 训练集 Youden 最优阈值, 三个集统一用此阈值
    for set_name in ['train', 'val', 'test']:
        mask = SET_MASK[set_name]
        skey = SET_KEY[set_name]
        auc, acc, sens, spec = _calc_metrics(y[mask], models[mname][skey], threshold=thr)
        row[f'{set_name}_AUC'] = auc
        row[f'{set_name}_ACC'] = acc
        row[f'{set_name}_Sens'] = sens
        row[f'{set_name}_Spec'] = spec
    row['Youden_thr_train'] = thr
    perf_rows.append(row)
perf_df = pd.DataFrame(perf_rows)
write_df(ws, perf_df, num_format='0.0000')

# ---- RADSCORE 公式 (仅主流程联合筛选 mixed; 区域拆分 intra/peri 已降为敏感性, 公式不再出表) ----
for rname in ['mixed']:
    lr = region_lasso.get(rname)
    if lr is None:
        continue
    ws = wb.create_sheet(f'Radscore_Formula_{rname}')
    rows = [{'Region': rname, 'Intercept': lr['intercept_z'], 'Feature': f,
             'Coefficient_standardized': c, 'Coefficient_original_scale': float(o) if pd.notna(o) else np.nan}
            for f, c, o in zip(lr['lasso_selected'], lr['coef_z_sel'], lr['coef_orig'])]
    write_df(ws, pd.DataFrame(rows), col_widths={'A': 8, 'B': 12, 'C': 44, 'D': 18, 'E': 18})

# ---- 临床联合模型公式 (联合签名 + 临床) ----
ws = wb.create_sheet('Clinical_Combined_Formula')
clin_names = ['Intercept'] + ['Mixed_RADSCORE'] + [f'{c}_std' for c in CLIN_MODEL_COLS]
final_lr = models['Mixed']['lr']
coefs = [final_lr.intercept_[0]] + list(final_lr.coef_[0])
cf_rows = [{'Term': n, 'Coefficient': c, 'exp(Coefficient)=OR': np.exp(c)} for n, c in zip(clin_names, coefs)]
write_df(ws, pd.DataFrame(cf_rows), col_widths={'A': 22, 'B': 14, 'C': 16})

# ---- 逐患者 RADSCORE / 概率: 已由 radscore.csv / radscore.xlsx 承载, 不再入 xlsx ----

# ---- Summary ----
mix_sel_feats = region_lasso['mixed']['lasso_selected']
n_sel_peri = sum(1 for f in mix_sel_feats if f.startswith('PERI5_'))
n_sel_h1 = sum(1 for f in mix_sel_feats if f.startswith('H1_'))
n_sel_h2 = sum(1 for f in mix_sel_feats if f.startswith('H2_'))
n_sel_h3 = sum(1 for f in mix_sel_feats if f.startswith('H3_'))
ws = wb.create_sheet('Summary')
summ_rows = [
    {'Item': '样本量', 'Value': f'{len(df)} (Train {int(is_train.sum())} / Val {int(is_val.sum())} / Test {int(is_test.sum())})'},
    {'Item': '全池 (4 生境分区: H1+H2+H3+PERI5)', 'Value': f'{len(mix_feats)} 特征, 单因素显著 {len(mix_sig)}, LASSO 选中 {len(region_lasso["mixed"]["lasso_selected"])}'},
    {'Item': 'LASSO 选中特征按分区', 'Value': f'PERI5 {n_sel_peri} / H1 {n_sel_h1} / H2 {n_sel_h2} / H3 {n_sel_h3}'},
    {'Item': '敏感性: 区域拆分 (瘤内+瘤周分开筛)',
     'Value': f'瘤内池 {len(region_results["intra"]["feats"])}→{len(region_results["intra"]["uni_sig"])}→{len(region_lasso["intra"]["lasso_selected"])}; 瘤周池 {len(region_results["peri"]["feats"])}→{len(region_results["peri"]["uni_sig"])}→{len(region_lasso["peri"]["lasso_selected"])}'},
    {'Item': '主模型', 'Value': '联合签名 (4 生境) + 临床 (AFP, 术前预测)'},
    {'Item': '最终模型 AUC (训练/验证/测试)',
     'Value': f'{roc_auc_score(y[is_train], models["Mixed"]["tr"]):.4f} / '
              f'{roc_auc_score(y[is_val], models["Mixed"]["va"]):.4f} / '
              f'{roc_auc_score(y[is_test], models["Mixed"]["te"]):.4f}'},
    {'Item': '敏感性: 双RADSCORE+临床 AUC (训练/验证/测试)',
     'Value': f'{roc_auc_score(y[is_train], models["双RADSCORE+临床"]["tr"]):.4f} / '
              f'{roc_auc_score(y[is_val], models["双RADSCORE+临床"]["va"]):.4f} / '
              f'{roc_auc_score(y[is_test], models["双RADSCORE+临床"]["te"]):.4f}'},
    {'Item': '验证集 DeLong P (联合签名 vs 双RADSCORE+临床)', 'Value': f'{p_dual_vs_mixed:.4f}'},
]
write_df(ws, pd.DataFrame(summ_rows), col_widths={'A': 34, 'B': 90})

# 注: 单因素全表 / 各区域公式 csv 为过程输出, 与 xlsx 中保留的表重复, 不再单独导出

xlsx_path = os.path.join(OUTPUT_DIR, 'Variable_Selection_Results.xlsx')
wb.save(xlsx_path)
print(f'  已保存 {xlsx_path}')

# ============================================================
# 11. 输出 radscore.csv / selected.xlsx / 总结
# ============================================================
print(f'\n[11/11] 输出 radscore.csv / selected.xlsx / selected_summary.md...')

# ---- radscore.csv (含各模型概率, 供后续可视化) ----
rad_out = pd.DataFrame({'case_id': df['case_id'], 'split': split_arr, OUTCOME: y})
if mixed_rs is not None:
    rad_out['mixed_RADSCORE'] = mixed_rs.values
rad_out['intra_RADSCORE'] = intra_rs.values
rad_out['peri_RADSCORE'] = peri_rs.values
for mname, mlab in MODEL_DEFS:
    if mname in models and models[mname] is not None:
        full = np.empty(len(df), dtype=float)
        for set_name, mask in SET_MASK.items():
            full[mask] = models[mname][SET_KEY[set_name]]
        rad_out[f'prob_{mname}'] = full
rad_out.to_csv(os.path.join(OUTPUT_DIR, 'radscore.csv'), index=False, encoding='utf-8-sig')
rad_out.to_excel(os.path.join(OUTPUT_DIR, 'radscore.xlsx'), index=False)
print(f'  已保存 radscore.csv ({rad_out.shape[0]} 行)')

# ---- selected.xlsx (case_id, label, mixed_RADSCORE(主), intra/peri_RADSCORE(敏感性), z_<18联合特征>) ----
all_selected_feats = region_lasso['mixed']['lasso_selected']
for set_name in ['train', 'val', 'test']:
    mask = SET_MASK[set_name]
    sel = pd.DataFrame({'case_id': df.loc[mask, 'case_id'].values,
                        'label': y[mask]})
    sel['mixed_RADSCORE'] = mixed_rs.values[mask]
    sel['intra_RADSCORE'] = intra_rs.values[mask]
    sel['peri_RADSCORE'] = peri_rs.values[mask]
    for f in all_selected_feats:
        sel[f'z_{f}'] = X_z.loc[mask, f].values
    out = os.path.join(OUTPUT_DIR, f'{set_name}_selected.xlsx')
    sel.to_excel(out, index=False)
    print(f'  已保存 {out} ({sel.shape[0]} 行 × {sel.shape[1]} 列: '
          f'1 联合 RADSCORE + {len(all_selected_feats)} 联合 z 特征 + 双 RADSCORE 敏感性)')

# ---- selected_summary.md ----
perf_line = (f'全池 {len(mix_feats)} 特征 → 单因素显著 {len(mix_sig)} → LASSO 选中 {len(region_lasso["mixed"]["lasso_selected"])}; '
             f'联合签名+临床 AUC {roc_auc_score(y[is_train], models["Mixed"]["tr"]):.4f} (训练) / '
             f'{roc_auc_score(y[is_val], models["Mixed"]["va"]):.4f} (验证) / '
             f'{roc_auc_score(y[is_test], models["Mixed"]["te"]):.4f} (测试)')
md_lines = [f'# 特征筛选总结 (4 生境分区联合签名, 术前预测模型)',
            '',
            '**建模策略**: 全池 1205 个特征 (瘤内 H1/H2/H3 + 瘤周5mm PERI5, 共 4 个生境分区) 统一筛选,',
            '最终模型 = 联合 RADSCORE + 临床 (AFP, 术前预测, 不含术后病理分化); 区域拆分双 RADSCORE 降为敏感性对比。',
            '',
            '**样本**: 训练 295 / 验证 155 / 测试 31 例 (固定分割, 结局 label)。',
            '',
            '## 联合筛选 (主流程)',
            f'- 全池: {len(mix_feats)} 特征 → 单因素 P<0.05 保留 {len(mix_sig)} → LASSO 选中 {len(region_lasso["mixed"]["lasso_selected"])}',
            f'- 选中特征按分区: PERI5 {n_sel_peri} / H1 {n_sel_h1} / H2 {n_sel_h2} / H3 {n_sel_h3}',
            '',
            '## 敏感性: 区域拆分 (瘤内/瘤周分开筛)',
            f'- 瘤内池: {len(region_results["intra"]["feats"])} 特征 → 单因素 P<0.05 保留 {len(region_results["intra"]["uni_sig"])} → LASSO 选中 {len(region_lasso["intra"]["lasso_selected"])}',
            f'- 瘤周池: {len(region_results["peri"]["feats"])} 特征 → 单因素 P<0.05 保留 {len(region_results["peri"]["uni_sig"])} → LASSO 选中 {len(region_lasso["peri"]["lasso_selected"])}',
            '',
            '## 模型性能 (AUC)',
            '| 模型 | 训练 | 验证 | 测试 |', '|---|---|---|---|']
for mname, mlab in MODEL_DEFS:
    if mname not in models or models[mname] is None:
        continue
    md_lines.append(f'| {mlab} | {roc_auc_score(y[is_train], models[mname]["tr"]):.4f} | '
                    f'{roc_auc_score(y[is_val], models[mname]["va"]):.4f} | '
                    f'{roc_auc_score(y[is_test], models[mname]["te"]):.4f} |')
md_lines.append('')
md_lines.append('**验证集 DeLong**: 联合签名 vs 双RADSCORE+临床(敏感性) P='
                f'{p_dual_vs_mixed:.4f} (差异无统计学意义)。')
md_lines.append('')
md_lines.append('## 输出文件')
md_lines.append('- radscore.csv / radscore.xlsx: 逐患者 联合/双 RADSCORE + 各模型概率')
md_lines.append(f'- train/val/test_selected.xlsx: case_id, label, mixed_RADSCORE(主), intra/peri_RADSCORE(敏感性), z_*{len(all_selected_feats)} 联合特征 (供第二步)')
md_lines.append('- Variable_Selection_Results.xlsx: Table1 / 单因素·多因素逻辑回归 / 区域拆分多因素(敏感性) / 模型性能 / 联合公式 / 最终联合公式 / Summary')
md_lines.append('- lasso_mixed_*.tiff: 联合 LASSO 系数路径 / CV 偏差路径 / 瀑布图 (区域拆分不出图)')
md_lines.append('- roc_{train,val,test}_6models.tiff: ROC 曲线 (联合签名主模型 + 敏感性)')
md_lines.append('- delong_validation_5models.csv: 验证集 DeLong 两两 P 矩阵')
with open(os.path.join(OUTPUT_DIR, 'selected_summary.md'), 'w', encoding='utf-8') as fh:
    fh.write('\n'.join(md_lines))
print('  已保存 selected_summary.md')

print('\n完成. 输出目录: ' + OUTPUT_DIR)
