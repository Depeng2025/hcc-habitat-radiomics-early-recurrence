# -*- coding: utf-8 -*-
"""
=====================================================================
STEP 2: 8种机器学习模型比较 (HCC 生境影像组学 + 临床联合输入)
=====================================================================
基于第一步最终模型的联合 RADSCORE (mixed_RADSCORE, 4 生境分区联合签名) **并联合临床变量**
(AFP), 比较 8 种机器学习分类模型的训练集/验证集判别性能.
逻辑回归完全复现第一步最终模型, 保证两步报告的训练/验证 AUC 一致.

模型输入 (联合模型, 术前预测):
  联合 RADSCORE (mixed_RADSCORE) + 标准化 AFP = 2 变量
  (不含术后病理分化 Differentiation)
  临床变量处理与第一步联合模型一致 (无泄漏): 训练集中位数填充 +
  StandardScaler (仅在训练集拟合), 再应用于训练/验证集.

输入文件:
  第一步/output/train_selected.xlsx (训练集, LASSO筛选后特征)
  第一步/output/val_selected.xlsx   (验证集)
  第一步/input/Train.csv / Val.csv  (临床变量 AFP)
  (需先运行 第一步/特征筛选.py 生成以上文件)

输出文件夹: output/  (第二步/output)
  1. roc_curves_training_set.tiff      (训练集ROC曲线)
  2. roc_curves_validation_set.tiff    (验证集ROC曲线)
  3. delong_test_training_set.tiff     (训练集DeLong检验方格图)
  4. delong_test_validation_set.tiff   (验证集DeLong检验方格图)
  5. radar_chart_training_set.tiff     (训练集雷达图)
  6. radar_chart_validation_set.tiff   (验证集雷达图)
  7. model_performance_results.csv     (模型性能指标)
  8. best_params.csv                   (各模型最优超参数)
  9. delong_p_values_training.csv / delong_p_values_validation.csv (训练/验证集 DeLong P 值矩阵)
  10. validation_auc_ci.csv            (验证集 AUC + Bootstrap 95% CI)

结局列: label

防过拟合措施:
  - GridSearchCV 使用分层 5 折交叉验证 (shuffle + 固定种子)
  - XGBoost: 强制 subsample/colsample<1, 正 L1/L2 正则, 深度<=3, 树数<=100
  - Decision Tree: 限深度<=4, 提高 min_samples_leaf
  - MLP: early_stopping + L2 alpha
  - 最终以验证集性能为准, 训练集仅用于调参

8种模型:
  Logistic Regression, Decision Tree, XGBoost, AdaBoost,
  SVM, Gaussian Naive Bayes, KNN, MLP Neural Network

依赖库: pandas, numpy, scikit-learn, xgboost, seaborn, matplotlib, scipy, Pillow
使用方法:
  cd 第二步
  python step2_model_comparison.py
=====================================================================
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import io
from sklearn.metrics import roc_curve, auc, roc_auc_score, confusion_matrix
from scipy.stats import norm
from PIL import Image
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.model_selection import GridSearchCV, StratifiedKFold
import matplotlib as mpl
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 配置
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STEP1_DIR = os.path.join(os.path.dirname(BASE_DIR), '第一步')
STEP1_OUT = os.path.join(STEP1_DIR, 'output')          # 第一步输出 (train/val_selected.xlsx)
CLIN_INPUT_DIR = os.path.join(STEP1_DIR, 'input')      # 临床原始文件 (Train/Val.csv)
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 敏感性分析模式: RADIOMICS_ONLY=1 时仅用影像组学特征 (不含临床),
# 输出写入 output/radioonly/ 子目录 (与主结果互不覆盖)
RADIOMICS_ONLY = os.environ.get('RADIOMICS_ONLY', '0') == '1'
if RADIOMICS_ONLY:
    OUTPUT_DIR = os.path.join(OUTPUT_DIR, 'radioonly')
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print("敏感性分析模式: 仅影像组学输入 (不含临床), 输出到 output/radioonly/")

TRAIN_FILE = os.path.join(STEP1_OUT, 'train_selected.xlsx')
VAL_FILE = os.path.join(STEP1_OUT, 'val_selected.xlsx')

# 结局列名 (第一步特征筛选输出)
LABEL_COL = 'label'

# 临床模型变量 (与第一步联合模型一致; 术前预测, 仅术前可得变量)
CLIN_MODEL_COLS = ['AFP']

# 全局随机种子 (统一固定)
SEED = 42

# 创建输出文件夹
output_dir = OUTPUT_DIR

# 设置全局字体和图形大小
plt.rcParams.update({
    'font.size': 12,
    'axes.titlesize': 14,
    'axes.labelsize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.figsize': (10, 8),
    'figure.dpi': 300
})
plt.rcParams['figure.facecolor'] = 'white'
plt.rcParams['axes.facecolor'] = 'white'

# 分层 5 折交叉验证 (shuffle + 固定种子, 用于 GridSearchCV 超参选择,
# 缓解小样本上超参选择的不稳定与过拟合)
CV = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

# ============================================================
# 安全保存函数 (处理文件被占用/锁定问题)
# ============================================================
def safe_savefig(fig, path, **kwargs):
    """保存为 LZW 压缩 TIFF (期刊投稿), 若文件被占用则自动追加序号保存.

    注意: matplotlib 直接 savefig('.tiff') 的 pil_kwargs 压缩不生效(输出未压缩
    巨大文件), 因此先渲染到内存 PNG, 再用 Pillow 转存为 tiff_lzw 压缩的 TIFF,
    不在磁盘上保留 PNG 文件.
    """
    dpi = kwargs.get('dpi', 300)
    base, ext = os.path.splitext(path)
    n = 1
    while True:
        try:
            if ext.lower() in ('.tiff', '.tif'):
                buf = io.BytesIO()
                fig.savefig(buf, format='png', dpi=dpi, bbox_inches='tight')
                buf.seek(0)
                Image.open(buf).convert('RGB').save(
                    path, format='TIFF', compression='tiff_lzw', dpi=(dpi, dpi))
            else:
                fig.savefig(path, **kwargs)
            return path
        except (PermissionError, OSError):
            # 文件被占用, 尝试新文件名
            n += 1
            path = f"{base}_{n}{ext}"
            if n > 50:
                raise
            print(f"  文件被占用, 尝试保存为: {path}")

# ============================================================
# 数据加载和预处理 (联合输入: 联合 RADSCORE + 临床, 2 变量, 无泄漏)
# ============================================================
print("正在加载数据...")
train = pd.read_excel(TRAIN_FILE)
val = pd.read_excel(VAL_FILE)

train[LABEL_COL] = train[LABEL_COL].astype(int)
val[LABEL_COL] = val[LABEL_COL].astype(int)

# 模型输入: 第一步最终模型的 2 变量 (联合 RADSCORE + 标准化 AFP), 与第一步完全一致
RADSCORE_COLS = ['mixed_RADSCORE']
feature_columns = [col for col in RADSCORE_COLS if col in train.columns]
print(f"联合 RADSCORE 列 ({len(feature_columns)} 个): {feature_columns}")

# ---- 临床变量加载 + 预处理 (无泄漏: 中位数 + 缩放常数仅训练集拟合) ----
clin_tr = pd.read_csv(os.path.join(CLIN_INPUT_DIR, 'Train.csv'))
clin_va = pd.read_csv(os.path.join(CLIN_INPUT_DIR, 'Val.csv'))
train['case_id'] = train['case_id'].astype(str)
val['case_id'] = val['case_id'].astype(str)
clin_tr['case_id'] = clin_tr['case_id'].astype(str)
clin_va['case_id'] = clin_va['case_id'].astype(str)
train = train.merge(clin_tr[['case_id'] + CLIN_MODEL_COLS], on='case_id', how='left')
val = val.merge(clin_va[['case_id'] + CLIN_MODEL_COLS], on='case_id', how='left')

for c in CLIN_MODEL_COLS:
    train[c] = pd.to_numeric(train[c], errors='coerce')
    val[c] = pd.to_numeric(val[c], errors='coerce')
clin_med = train[CLIN_MODEL_COLS].median().fillna(0.0)
clin_scaler = StandardScaler()
clin_scaler.fit(train[CLIN_MODEL_COLS].fillna(clin_med).values)
X_clin_tr = clin_scaler.transform(train[CLIN_MODEL_COLS].fillna(clin_med).values)
X_clin_va = clin_scaler.transform(val[CLIN_MODEL_COLS].fillna(clin_med).values)

# 联合输入矩阵: 联合 RADSCORE + 1 标准化临床变量 (AFP)
# (敏感性模式 RADIOMICS_ONLY=1 时仅联合 RADSCORE)
if RADIOMICS_ONLY:
    X_train_comb = train[feature_columns].values.astype(float)
    X_val_comb = val[feature_columns].values.astype(float)
    combined_columns = feature_columns
else:
    X_train_comb = np.column_stack([train[feature_columns].values.astype(float), X_clin_tr])
    X_val_comb = np.column_stack([val[feature_columns].values.astype(float), X_clin_va])
    combined_columns = feature_columns + CLIN_MODEL_COLS
y_tr = train[LABEL_COL].values
y_va = val[LABEL_COL].values

print(f"模型输入: {len(combined_columns)} 个变量 "
      f"(联合 RADSCORE {len(feature_columns)} + {len(CLIN_MODEL_COLS)} 临床标准化变量)" if not RADIOMICS_ONLY
      else f"模型输入: {len(combined_columns)} 个变量 (仅联合 RADSCORE)")
print(f"训练集大小: {train.shape} (模型矩阵 {X_train_comb.shape}), "
      f"验证集大小: {val.shape} (模型矩阵 {X_val_comb.shape})")
print(f"训练集Positive: {y_tr.sum()}, 验证集Positive: {y_va.sum()}")

# ============================================================
# 定义性能函数
# ============================================================
def performance(conf_matrix):
    tn, fp, fn, tp = conf_matrix.ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    ppp = tp / (tp + fp) if (tp + fp) > 0 else 0
    npp = tn / (tn + fn) if (tn + fn) > 0 else 0
    hitrate = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0
    F1 = 2 * sensitivity * ppp / (ppp + sensitivity) if (ppp + sensitivity) > 0 else 0
    result = {
        "sensitivity": sensitivity,
        "specificity": specificity,
        "positive predictive value": ppp,
        "negative predictive value": npp,
        "accuracy": hitrate,
        "F1": F1
    }
    return pd.DataFrame(result, index=["model"])

# ============================================================
# 模型训练 - 8种模型 (GridSearchCV超参数调优)
# ============================================================
print("开始训练模型 (GridSearchCV调优)...")

# 保存每个模型的最优参数
best_params_dict = {}

# ---- 辅助函数: 用GridSearchCV调参并返回最优模型 ----
def grid_fit(model, param_grid, name, cv=CV):
    """对模型做GridSearchCV(分层5折, 防过拟合), 返回最优模型."""
    import time
    print(f"调优 {name}...", flush=True)
    t0 = time.time()
    gs = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        scoring='roc_auc',
        cv=cv,
        n_jobs=-1,
        verbose=0
    )
    gs.fit(X_train_comb, y_tr)
    elapsed = time.time() - t0
    best_params_dict[name] = gs.best_params_
    print(f"  {name} 最优参数: {gs.best_params_}")
    print(f"  {name} CV AUC: {gs.best_score_:.4f} (耗时{elapsed:.0f}s)", flush=True)
    return gs.best_estimator_

# 1. 逻辑回归 — 与第一步最终模型完全一致 (C=1.0, 无类别权重, lbfgs, max_iter=10000),
#    输入即第一步联合 RADSCORE + 标准化 AFP (2 变量), 故训练/验证 AUC 完全复现第一步
#    (训练 0.873 / 验证 0.840), 两步报告数字一致; 不调参 (单点网格).
fit_logit = grid_fit(
    LogisticRegression(max_iter=10000, random_state=SEED),
    {
        'C': [1.0],
        'solver': ['lbfgs'],
        'penalty': ['l2']
    },
    'Logistic Regression'
)
prob_train_logit = fit_logit.predict_proba(X_train_comb)[:, 1]
prob_val_logit = fit_logit.predict_proba(X_val_comb)[:, 1]

# 2. 决策树 (限深度 + 提高叶节点最小样本, 防过拟合)
fit_tree = grid_fit(
    DecisionTreeClassifier(random_state=SEED, class_weight='balanced'),
    {
        'criterion': ['gini', 'entropy'],
        'max_depth': [2, 3, 4],
        'min_samples_split': [10, 20, 30],
        'min_samples_leaf': [15, 25, 40]
    },
    'Decision Tree'
)
prob_train_tree = fit_tree.predict_proba(X_train_comb)[:, 1]
prob_val_tree = fit_tree.predict_proba(X_val_comb)[:, 1]

# 3. XGBoost (防过拟合: 强制 subsample/colsample<1 随机抽样 + 正 L1/L2 正则 + 限制深度与树数)
scale_pos_weight = (y_tr == 0).sum() / (y_tr == 1).sum()
fit_xgb = grid_fit(
    XGBClassifier(objective='binary:logistic', random_state=SEED, n_jobs=-1,
                  eval_metric='logloss', verbosity=0,
                  scale_pos_weight=scale_pos_weight),
    {
        'n_estimators': [50, 100],
        'learning_rate': [0.03, 0.05],
        'max_depth': [2, 3],
        'min_child_weight': [1, 5],
        'subsample': [0.6, 0.8],
        'colsample_bytree': [0.6, 0.8],
        'reg_alpha': [0.1, 1.0],
        'reg_lambda': [2.0, 5.0]
    },
    'XGBoost'
)
prob_train_xgb = fit_xgb.predict_proba(X_train_comb)[:, 1]
prob_val_xgb = fit_xgb.predict_proba(X_val_comb)[:, 1]

# 3b. AdaBoost (自适应提升, 弱学习器加权集成; 减少树数+降低学习率防过拟合)
fit_ada = grid_fit(
    AdaBoostClassifier(random_state=SEED),
    {
        'n_estimators': [30, 50, 100],
        'learning_rate': [0.3, 0.5, 1.0]
    },
    'AdaBoost'
)
prob_train_ada = fit_ada.predict_proba(X_train_comb)[:, 1]
prob_val_ada = fit_ada.predict_proba(X_val_comb)[:, 1]

# 4. SVM (RBF核在大样本上慢, 用较小网格)
fit_svm = grid_fit(
    SVC(probability=True, random_state=SEED, class_weight='balanced'),
    {
        'C': [0.1, 1, 10],
        'gamma': ['scale', 0.01],
        'kernel': ['rbf']
    },
    'SVM'
)
prob_train_svm = fit_svm.predict_proba(X_train_comb)[:, 1]
prob_val_svm = fit_svm.predict_proba(X_val_comb)[:, 1]

# 5. 高斯朴素贝叶斯
fit_gnb = grid_fit(
    GaussianNB(),
    {
        'var_smoothing': [1e-12, 1e-11, 1e-10, 1e-9, 1e-8, 1e-7]
    },
    'Gaussian Naive Bayes'
)
prob_train_gnb = fit_gnb.predict_proba(X_train_comb)[:, 1]
prob_val_gnb = fit_gnb.predict_proba(X_val_comb)[:, 1]

# 6. K近邻
fit_knn = grid_fit(
    KNeighborsClassifier(n_jobs=-1),
    {
        'n_neighbors': [5, 10, 20, 30, 50],
        'weights': ['uniform', 'distance'],
        'p': [1, 2]
    },
    'K-Nearest Neighbors'
)
prob_train_knn = fit_knn.predict_proba(X_train_comb)[:, 1]
prob_val_knn = fit_knn.predict_proba(X_val_comb)[:, 1]

# 7. MLP神经网络 (early_stopping 已防过拟合; alpha 允许到 0.0001, 避免过度正则欠拟合)
fit_mlp = grid_fit(
    MLPClassifier(max_iter=500, random_state=SEED, early_stopping=True),
    {
        'hidden_layer_sizes': [(30,), (30, 15)],
        'activation': ['relu', 'tanh'],
        'alpha': [0.0001, 0.001, 0.01],
        'solver': ['adam']
    },
    'MLP Neural Network'
)
prob_train_mlp = fit_mlp.predict_proba(X_train_comb)[:, 1]
prob_val_mlp = fit_mlp.predict_proba(X_val_comb)[:, 1]

print("所有模型训练完成!")
print("\n各模型最优参数:")
for name, params in best_params_dict.items():
    print(f"  {name}: {params}")

# ============================================================
# 模型评估: 普通 GridSearchCV + 分层5折交叉验证 (回退嵌套 CV, 2026-08-19)
# 过拟合评估以 训练集/验证集 AUC 差距 + 5折 CV AUC 为准 (见 MD §5.3)
# ============================================================

# ============================================================
# 定义计算AUC置信区间的函数
# ============================================================
def compute_auc_ci(y_true, y_score, n_bootstrap=1000, ci=95):
    """计算AUC及其置信区间（使用自定义bootstrap方法）"""
    auc_value = roc_auc_score(y_true, y_score)

    n = len(y_true)
    auc_bootstrap = []

    np.random.seed(SEED)
    for _ in range(n_bootstrap):
        indices = np.random.choice(n, n, replace=True)

        y_true_boot = y_true[indices]
        y_score_boot = y_score[indices]

        try:
            auc_boot = roc_auc_score(y_true_boot, y_score_boot)
            auc_bootstrap.append(auc_boot)
        except:
            pass

    if len(auc_bootstrap) > 0:
        ci_low, ci_high = np.percentile(auc_bootstrap, [(100-ci)/2, 100-(100-ci)/2])
    else:
        ci_low, ci_high = auc_value, auc_value

    return auc_value, ci_low, ci_high

# ============================================================
# 定义颜色和线型
# ============================================================
model_colors = {
    'Logistic Regression': '#1f77b4',
    'Decision Tree': '#ff7f0e',
    'XGBoost': '#d62728',
    'AdaBoost': '#8c564b',
    'SVM': '#9467bd',
    'Gaussian Naive Bayes': '#17becf',
    'K-Nearest Neighbors': '#bcbd22',
    'MLP Neural Network': '#7f7f7f'
}

# ============================================================
# 模型预测概率字典
# ============================================================
models_train = {
    'Logistic Regression': prob_train_logit,
    'Decision Tree': prob_train_tree,
    'XGBoost': prob_train_xgb,
    'AdaBoost': prob_train_ada,
    'SVM': prob_train_svm,
    'Gaussian Naive Bayes': prob_train_gnb,
    'K-Nearest Neighbors': prob_train_knn,
    'MLP Neural Network': prob_train_mlp
}

models_val = {
    'Logistic Regression': prob_val_logit,
    'Decision Tree': prob_val_tree,
    'XGBoost': prob_val_xgb,
    'AdaBoost': prob_val_ada,
    'SVM': prob_val_svm,
    'Gaussian Naive Bayes': prob_val_gnb,
    'K-Nearest Neighbors': prob_val_knn,
    'MLP Neural Network': prob_val_mlp
}

model_names = sorted(models_train.keys())

# ---- 导出验证集 AUC + Bootstrap 95% CI (供报告表用) ----
auc_ci_rows = []
for name in model_names:
    auc_tr, _, _ = compute_auc_ci(y_tr, models_train[name], n_bootstrap=1000)
    auc_va, lo, hi = compute_auc_ci(y_va, models_val[name], n_bootstrap=1000)
    auc_ci_rows.append({'model': name, 'train_AUC': round(auc_tr, 4),
                        'val_AUC': round(auc_va, 4),
                        'val_AUC_ci_low': round(lo, 4), 'val_AUC_ci_high': round(hi, 4)})
pd.DataFrame(auc_ci_rows).to_csv(os.path.join(OUTPUT_DIR, 'validation_auc_ci.csv'),
                                 index=False, encoding='utf-8-sig')
print("验证集 AUC + Bootstrap 95% CI 已保存到 validation_auc_ci.csv")

# ============================================================
# 图1: 训练集ROC曲线图
# ============================================================
print("绘制训练集ROC曲线图...")

fig, ax = plt.subplots(figsize=(10, 8))

for model_name in model_names:
    prob = models_train[model_name]
    color = model_colors[model_name]

    fpr, tpr, _ = roc_curve(y_tr, prob)
    roc_auc = auc(fpr, tpr)

    auc_value, ci_low, ci_high = compute_auc_ci(y_tr, prob, n_bootstrap=1000)
    ci_str = f"({ci_low:.3f}-{ci_high:.3f})"

    ax.plot(fpr, tpr, color=color, lw=2, alpha=0.7,
            label=f'{model_name}\nAUC = {auc_value:.3f} [95% CI: {ci_str}]')

ax.plot([0, 1], [0, 1], color='black', lw=1.5, linestyle='--', alpha=0.7)
ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.05])
ax.set_xlabel('False Positive Rate', fontsize=12)
ax.set_ylabel('True Positive Rate', fontsize=12)
ax.set_title('ROC Curves for Training Set (Combined Input)', fontsize=14, fontweight='bold')
ax.legend(loc="lower right", fontsize=9, framealpha=0.8)
ax.grid(True, linestyle='--', alpha=0.3)

for spine in ax.spines.values():
    spine.set_linewidth(1.5)
    spine.set_color('#CCCCCC')

output_path = os.path.join(output_dir, "roc_curves_training_set.tiff")
saved = safe_savefig(plt.gcf(), output_path, dpi=300, bbox_inches='tight')
plt.close()
print(f"训练集ROC曲线图已保存到: {saved}")

# ============================================================
# 图2: 验证集ROC曲线图
# ============================================================
print("绘制验证集ROC曲线图...")

fig, ax = plt.subplots(figsize=(10, 8))

for model_name in model_names:
    prob = models_val[model_name]
    color = model_colors[model_name]

    fpr, tpr, _ = roc_curve(y_va, prob)
    roc_auc = auc(fpr, tpr)

    auc_value, ci_low, ci_high = compute_auc_ci(y_va, prob, n_bootstrap=1000)
    ci_str = f"({ci_low:.3f}-{ci_high:.3f})"

    ax.plot(fpr, tpr, color=color, lw=2, alpha=0.7,
            label=f'{model_name}\nAUC = {auc_value:.3f} [95% CI: {ci_str}]')

ax.plot([0, 1], [0, 1], color='black', lw=1.5, linestyle='--', alpha=0.7)
ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.05])
ax.set_xlabel('False Positive Rate', fontsize=12)
ax.set_ylabel('True Positive Rate', fontsize=12)
ax.set_title('ROC Curves for Validation Set (Combined Input)', fontsize=14, fontweight='bold')
ax.legend(loc="lower right", fontsize=9, framealpha=0.8)
ax.grid(True, linestyle='--', alpha=0.3)

for spine in ax.spines.values():
    spine.set_linewidth(1.5)
    spine.set_color('#CCCCCC')

output_path = os.path.join(output_dir, "roc_curves_validation_set.tiff")
saved = safe_savefig(plt.gcf(), output_path, dpi=300, bbox_inches='tight')
plt.close()
print(f"验证集ROC曲线图已保存到: {saved}")

# ============================================================
# DeLong检验
# ============================================================
print("进行DeLong检验...")

# 定义DeLong检验函数 (Sun & Xu 2014 秩实现, 教科书正确版)
def compute_midrank(x):
    """等价秩 (midrank), 处理并列值"""
    J = np.argsort(x)
    Z = x[J]
    N = len(x)
    T = np.zeros(N, dtype=float)
    i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1)
        i = j
    T2 = np.empty(N, dtype=float)
    T2[J] = T
    return T2

def fast_deLong(preds_sorted, label_1_count):
    """给定(2 模型 x N)排序分数矩阵(阳性在前), 返回各模型 AUC 与 Delong 协方差阵"""
    m = label_1_count
    n = preds_sorted.shape[1] - m
    pos = preds_sorted[:, :m]
    neg = preds_sorted[:, m:]
    k = preds_sorted.shape[0]

    tx = np.empty([k, m]); ty = np.empty([k, n]); tz = np.empty([k, m + n])
    for r in range(k):
        tx[r, :] = compute_midrank(pos[r, :])
        ty[r, :] = compute_midrank(neg[r, :])
        tz[r, :] = compute_midrank(preds_sorted[r, :])

    aucs = tz[:, :m].sum(axis=1) / m / n - float(m + 1.0) / 2.0 / n
    v01 = (tz[:, :m] - tx[:, :]) / n
    v10 = 1.0 - (tz[:, m:] - ty[:, :]) / m
    sx = np.cov(v01)
    sy = np.cov(v10)
    delongcov = sx / m + sy / n
    return aucs, delongcov

def delong_roc_test(y_true, preds1, preds2):
    """双尾 DeLong 检验, 返回 (z, p)"""
    y_true = np.asarray(y_true, dtype=np.float64)
    preds1 = np.asarray(preds1)
    preds2 = np.asarray(preds2)
    idx = np.argsort(-y_true)      # 阳性样本排在前面
    y_true = y_true[idx]
    preds1 = preds1[idx]
    preds2 = preds2[idx]
    label_1_count = int(y_true.sum())
    preds_sorted = np.vstack((preds1, preds2))
    aucs, cov = fast_deLong(preds_sorted, label_1_count)
    try:
        denom = np.sqrt(cov[0, 0] + cov[1, 1] - 2 * cov[0, 1])
        z = (aucs[0] - aucs[1]) / denom
        p = 2 * (1 - norm.cdf(abs(z)))
    except Exception:
        z, p = np.nan, np.nan
    return z, p

# 初始化p值矩阵 (训练集 DeLong 为重代入, 仅作参考; 验证集为主)
p_matrix_train = np.ones((len(model_names), len(model_names)))
p_matrix_val = np.ones((len(model_names), len(model_names)))

# 填充p值矩阵
print("计算训练集和验证集DeLong检验...")
for i in range(len(model_names)):
    for j in range(i+1, len(model_names)):
        model1 = model_names[i]
        model2 = model_names[j]

        # 训练集
        _, p_train = delong_roc_test(
            y_tr,
            models_train[model1],
            models_train[model2]
        )
        p_matrix_train[i, j] = p_train
        p_matrix_train[j, i] = p_train

        # 验证集
        _, p_test = delong_roc_test(
            y_va,
            models_val[model1],
            models_val[model2]
        )
        p_matrix_val[i, j] = p_test
        p_matrix_val[j, i] = p_test

# 保存 P 值矩阵 (便于正文引用)
pd.DataFrame(p_matrix_train, index=model_names, columns=model_names) \
    .to_csv(os.path.join(output_dir, 'delong_p_values_training.csv'), encoding='utf-8-sig')
pd.DataFrame(p_matrix_val, index=model_names, columns=model_names) \
    .to_csv(os.path.join(output_dir, 'delong_p_values_validation.csv'), encoding='utf-8-sig')

# 创建方格图函数
def plot_p_matrix_single(p_matrix, model_names, title, save_path, fontsize=10):
    fig, ax = plt.subplots(figsize=(12, 10))

    mask = np.zeros_like(p_matrix)
    mask[np.triu_indices_from(mask, k=1)] = True

    heatmap = sns.heatmap(
        p_matrix,
        mask=mask,
        annot=True,
        fmt=".3f",
        cmap="coolwarm",
        vmin=0,
        vmax=0.1,
        linewidths=0.5,
        annot_kws={"size": fontsize-2},
        cbar=True,
        cbar_kws={"shrink": 0.8},
        square=True,
        ax=ax
    )

    ax.set_xticks(np.arange(len(model_names)) + 0.5)
    ax.set_yticks(np.arange(len(model_names)) + 0.5)
    ax.set_xticklabels(model_names, rotation=45, ha='right', fontsize=fontsize)
    ax.set_yticklabels(model_names, rotation=0, fontsize=fontsize)

    ax.set_title(title, fontsize=14, pad=20, fontweight='bold')

    for i in range(len(model_names)):
        ax.add_patch(plt.Rectangle((i, i), 1, 1, fill=False, edgecolor='gray', lw=1))

    for i in range(len(model_names)):
        for j in range(i+1, len(model_names)):
            if p_matrix[i, j] < 0.001:
                ax.text(j+0.5, i+0.5, "***",
                        fontsize=fontsize, ha='center', va='center', color='white')
            elif p_matrix[i, j] < 0.01:
                ax.text(j+0.5, i+0.5, "**",
                        fontsize=fontsize, ha='center', va='center', color='white')
            elif p_matrix[i, j] < 0.05:
                ax.text(j+0.5, i+0.5, "*",
                        fontsize=fontsize, ha='center', va='center', color='white')

    cbar = heatmap.collections[0].colorbar
    cbar.set_label('p-value', fontsize=12)
    cbar.ax.tick_params(labelsize=10)

    safe_savefig(fig, save_path, dpi=300, bbox_inches='tight')
    plt.close()

# ============================================================
# 图3: 训练集DeLong检验方格图
# ============================================================
print("绘制训练集DeLong检验方格图...")
output_path = os.path.join(output_dir, "delong_test_training_set.tiff")
plot_p_matrix_single(p_matrix_train, model_names,
                    "DeLong Test for Training Set\n(***: p<0.001, **: p<0.01, *: p<0.05)",
                    output_path, fontsize=10)
print(f"训练集DeLong检验方格图已保存到: {output_path}")

# ============================================================
# 图4: 验证集DeLong检验方格图
# ============================================================
print("绘制验证集DeLong检验方格图...")
output_path = os.path.join(output_dir, "delong_test_validation_set.tiff")
plot_p_matrix_single(p_matrix_val, model_names,
                    "DeLong Test for Validation Set\n(***: p<0.001, **: p<0.01, *: p<0.05)",
                    output_path, fontsize=10)
print(f"验证集DeLong检验方格图已保存到: {output_path}")

# ============================================================
# 计算最优阈值 (Youden's index) — 替代固定0.5阈值
# ============================================================
print("计算最优阈值 (Youden's index)...")

optimal_thresholds = {}
for model_name in model_names:
    prob = models_train[model_name]
    fpr, tpr, thresholds = roc_curve(y_tr, prob)
    youden = tpr - fpr
    best_idx = np.argmax(youden)
    optimal_thresholds[model_name] = thresholds[best_idx]
    print(f"  {model_name}: 最优阈值 = {optimal_thresholds[model_name]:.4f}")

# ============================================================
# 计算并保存模型性能指标
# ============================================================
print("计算模型性能指标...")

train_results = []
val_perf = []

for model_name in model_names:
    prob_train = models_train[model_name]
    prob_val = models_val[model_name]
    thresh = optimal_thresholds[model_name]

    # 训练集性能
    pred_train = (prob_train >= thresh).astype(int)
    cm_train = confusion_matrix(y_tr, pred_train)
    perf_train = performance(cm_train)
    perf_train['auc'] = roc_auc_score(y_tr, prob_train)
    perf_train['dataset'] = 'Training'
    perf_train['model'] = model_name
    train_results.append(perf_train)

    # 验证集性能
    pred_val = (prob_val >= thresh).astype(int)
    cm_val = confusion_matrix(y_va, pred_val)
    perf_val = performance(cm_val)
    perf_val['auc'] = roc_auc_score(y_va, prob_val)
    perf_val['dataset'] = 'Validation'
    perf_val['model'] = model_name
    val_perf.append(perf_val)

# 合并结果
all_results = pd.concat(train_results + val_perf, ignore_index=True)

all_results = all_results[['model', 'dataset', 'auc', 'sensitivity', 'specificity',
                           'positive predictive value', 'negative predictive value',
                           'accuracy', 'F1']]

results_path = os.path.join(output_dir, "model_performance_results.csv")
all_results.to_csv(results_path, index=False)
print(f"模型性能指标已保存到: {results_path}")

# 保存最优参数
best_params_path = os.path.join(output_dir, "best_params.csv")
bp_df = pd.DataFrame([
    {'Model': k, 'Best_params': str(v)} for k, v in best_params_dict.items()
])
bp_df.to_csv(best_params_path, index=False)
print(f"最优参数已保存到: {best_params_path}")

# ============================================================
# 创建雷达图函数
# ============================================================
def create_radar_chart(performance_df, dataset_name, model_names_sorted, model_colors, save_path):
    """创建单个雷达图 (v2: 放大坐标 + 去填充 + 高亮最优)

    5个指标: Specificity / PPV / NPV / Accuracy / F1
    Sensitivity 未纳入 (与性能表 Sens 互补避免维度冗余, 保持5维便于阅读)
    5个指标均直接反映临床实用价值。

    v2 改进(相比原版):
      1. 径向轴由 0-1 放大为 0.2-1.0, 让模型间微小差异真正可见
         (原版各指标挤在窄带内, 9条曲线全部贴边无法区分)
      2. 去掉所有模型的半透明填充(糊成一团), 改为细线 + 顶点标记
      3. 表现最优模型(按Accuracy)用粗线 + 浅色填充 + ★ 突出
      4. 图例横排在图下方, 避免挤压图区且不被 bbox_inches 截断
    """
    dataset_perf = performance_df[performance_df['dataset'] == dataset_name]
    dataset_perf = dataset_perf.sort_values('model')

    metrics = ['specificity', 'positive predictive value', 'negative predictive value', 'accuracy', 'F1']
    metric_labels = ['Specificity', 'PPV', 'NPV', 'Accuracy', 'F1']

    N = len(metrics)
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]

    # 最优模型 (按Accuracy, 与控制台排名一致)
    best_model = dataset_perf.sort_values('accuracy', ascending=False).iloc[0]['model']

    fig = plt.figure(figsize=(10, 9.5))
    ax = fig.add_subplot(111, polar=True)

    title = 'Training Set Performance' if dataset_name == 'Training' else 'Validation Set Performance'
    ax.set_title(title, size=16, y=1.08, fontweight='bold')

    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metric_labels, fontsize=12)
    ax.tick_params(axis='x', pad=20)   # 指标标签与网格留白, 避免压到数值
    # 放大坐标 0.2-1.0, 放大差异 (原版 0-1 导致所有曲线贴边无法区分)
    ax.set_ylim(0.2, 1.0)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels(['0.2', '0.4', '0.6', '0.8', '1.0'], fontsize=10)

    ax.grid(True, linestyle='-', linewidth=0.8, alpha=0.3, color='#CCCCCC')
    ax.grid(axis='y', linestyle='--', linewidth=1.0, alpha=0.5, color='#BBBBBB')

    ax.spines['polar'].set_linewidth(2)
    ax.spines['polar'].set_color('#666666')

    for model_name in model_names_sorted:
        model_data = dataset_perf[dataset_perf['model'] == model_name].iloc[0]
        values = [model_data[metric] for metric in metrics]
        values += values[:1]
        color = model_colors[model_name]

        if model_name == best_model:
            ax.plot(angles, values, linewidth=3.0, linestyle='solid',
                    color=color, alpha=0.95, marker='o', markersize=6,
                    label=f'{model_name} ★ best by Acc')
            ax.fill(angles, values, alpha=0.15, color=color)
        else:
            ax.plot(angles, values, linewidth=1.3, linestyle='solid',
                    color=color, alpha=0.65, marker='o', markersize=4,
                    label=model_name)

    # 图例横排在图下方, 避免挤压图区
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.08), ncol=3,
              fontsize=9, framealpha=0.9, columnspacing=1.2, handlelength=1.5)

    # 给下方图例留出空间, 防止 bbox_inches='tight' 截断图例
    fig.subplots_adjust(bottom=0.22)

    safe_savefig(fig, save_path, dpi=300, bbox_inches='tight')
    plt.close()

# ============================================================
# 图5: 训练集雷达图
# ============================================================
print("绘制训练集雷达图...")
output_path = os.path.join(output_dir, "radar_chart_training_set.tiff")
create_radar_chart(all_results, 'Training', model_names, model_colors, output_path)
print(f"训练集雷达图已保存到: {output_path}")

# ============================================================
# 图6: 验证集雷达图
# ============================================================
print("绘制验证集雷达图...")
output_path = os.path.join(output_dir, "radar_chart_validation_set.tiff")
create_radar_chart(all_results, 'Validation', model_names, model_colors, output_path)
print(f"验证集雷达图已保存到: {output_path}")

# ============================================================
# 打印分析结果
# ============================================================
print("\n" + "="*60)
print("生成图像总结:")
print("="*60)
print("1. roc_curves_training_set.tiff - 训练集ROC曲线图 (联合输入)")
print("2. roc_curves_validation_set.tiff - 验证集ROC曲线图 (联合输入)")
print("3. delong_test_training_set.tiff - 训练集DeLong检验方格图")
print("4. delong_test_validation_set.tiff - 验证集DeLong检验方格图")
print("5. radar_chart_training_set.tiff - 训练集雷达图")
print("6. radar_chart_validation_set.tiff - 验证集雷达图")
print("7. model_performance_results.csv - 模型性能指标CSV文件")
print("8. best_params.csv - 各模型最优超参数")
print("9. delong_p_values_{training,validation}.csv - DeLong P 值矩阵")
print("10. validation_auc_ci.csv - 验证集 AUC + Bootstrap 95% CI")
print("="*60)

# 提取验证集结果
val_results = all_results[all_results['dataset'] == 'Validation']
print("\n各模型在验证集上的表现 (联合输入, Youden阈值):")
for _, row in val_results.sort_values('accuracy', ascending=False).iterrows():
    print(f"  {row['model']:<25s} AUC-acc={row['accuracy']:.3f}, Sens={row['sensitivity']:.3f}, "
          f"Spec={row['specificity']:.3f}, F1={row['F1']:.3f}")

print("\n所有分析完成! 输出文件已保存到OUTPUT文件夹。")
