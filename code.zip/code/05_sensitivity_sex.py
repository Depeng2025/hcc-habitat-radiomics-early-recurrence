# -*- coding: utf-8 -*-
"""
敏感性分析: 在最终模型 mixed_RADSCORE + AFP 基础上加入 Sex 是否带来增量预测价值
  XGBoost-2变量: mixed_RADSCORE + AFP          (原最终模型)
  XGBoost-3变量: mixed_RADSCORE + AFP + Sex    (敏感性对照)
比较: 训练/验证/测试 AUC、ACC、Sens、Spec (训练集 Youden 阈值, Bootstrap 95% CI),
      校准 (slope / E/O), DeLong 两两检验, 以及训练集内部 5-fold CV AUC。
"""
import os, io, ast
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (roc_auc_score, roc_curve, accuracy_score,
                             recall_score)
from sklearn.model_selection import StratifiedKFold, cross_val_score
from scipy.stats import norm
from xgboost import XGBClassifier
import warnings
warnings.filterwarnings('ignore')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STEP1_DIR = os.path.join(os.path.dirname(BASE_DIR), '第一步')
STEP1_OUT = os.path.join(STEP1_DIR, 'output')
CLIN_INPUT_DIR = os.path.join(STEP1_DIR, 'input')
STEP2_OUT = os.path.join(os.path.dirname(BASE_DIR), '第二步', 'output')
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

LABEL_COL = 'label'
RADSCORE_COL = 'mixed_RADSCORE'
SEED = 42

DATASETS = [
    ('train', 'train_selected.xlsx', 'Train.csv', 'Training Set'),
    ('val',   'val_selected.xlsx',   'Val.csv',    'Validation Set'),
    ('test',  'test_selected.xlsx',  'Test.csv',   'Test Set'),
]

# ---- 数据加载 (与 step3 一致) ----
data_frames = {}
for key, sel_file, clin_file, disp in DATASETS:
    df = pd.read_excel(os.path.join(STEP1_OUT, sel_file))
    df[LABEL_COL] = df[LABEL_COL].astype(int)
    clin = pd.read_csv(os.path.join(CLIN_INPUT_DIR, clin_file))
    df['case_id'] = df['case_id'].astype(str)
    clin['case_id'] = clin['case_id'].astype(str)
    clin_cols = ['AFP', 'Sex']
    df = df.merge(clin[['case_id'] + clin_cols], on='case_id', how='left')
    for c in clin_cols:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    data_frames[key] = df

train_df = data_frames['train']
clin_med = train_df[clin_cols].median().fillna(0.0)
clin_scaler = StandardScaler()
clin_scaler.fit(train_df[clin_cols].fillna(clin_med).values)

X = {}; y = {}
for key, _, _, disp in DATASETS:
    df = data_frames[key]
    X_clin = clin_scaler.transform(df[clin_cols].fillna(clin_med).values)  # [AFP, Sex]
    X_rad = df[[RADSCORE_COL]].values.astype(float)
    # 2变量: rad + AFP(第0列); 3变量: rad + AFP + Sex
    X[key] = {
        'Combined2': np.column_stack([X_rad, X_clin[:, 0:1]]),
        'Combined3': np.column_stack([X_rad, X_clin]),
    }
    y[key] = df[LABEL_COL].values

y_train, y_val, y_test = y['train'], y['val'], y['test']

# ---- XGBoost 参数 (与 step3 一致) ----
_BEST = {'colsample_bytree': 0.6, 'learning_rate': 0.03, 'max_depth': 2,
         'min_child_weight': 5, 'n_estimators': 100, 'reg_alpha': 1.0,
         'reg_lambda': 2.0, 'subsample': 0.6}
try:
    _bp = pd.read_csv(os.path.join(STEP2_OUT, 'best_params.csv'))
    _row = _bp[_bp['Model'] == 'XGBoost']['Best_params'].values[0]
    _parsed = ast.literal_eval(_row)
    if isinstance(_parsed, dict) and _parsed:
        _BEST = {k: v for k, v in _parsed.items() if k not in ('objective',)}
except Exception:
    pass

scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()
xgb_params = {
    'objective': 'binary:logistic', 'random_state': SEED, 'n_jobs': -1,
    'eval_metric': 'logloss', 'verbosity': 0,
    'scale_pos_weight': scale_pos_weight,
}
xgb_params.update(_BEST)

# ---- Bootstrap 度量 CI ----
def bootstrap_metric_ci(y_true, y_proba, y_pred, metric, n_bootstrap=1000, ci=95):
    np.random.seed(SEED)
    funcs = {
        'auc':  roc_auc_score,
        'acc':  accuracy_score,
        'sens': lambda yt, yp: recall_score(yt, yp),
        'spec': lambda yt, yp: recall_score(yt, yp, pos_label=0),
    }
    f = funcs[metric]
    n = len(y_true)
    if metric == 'auc':
        point = f(y_true, y_proba)
        boot = np.array([f(y_true[idx], y_proba[idx]) for idx in
                         (np.random.choice(n, n, replace=True) for _ in range(n_bootstrap))])
    else:
        point = f(y_true, y_pred)
        boot = np.array([f(y_true[idx], y_pred[idx]) for idx in
                         (np.random.choice(n, n, replace=True) for _ in range(n_bootstrap))])
    boot = boot[~np.isnan(boot)]
    lo, hi = np.percentile(boot, [(100 - ci) / 2, 100 - (100 - ci) / 2])
    return point, lo, hi

# ---- DeLong ----
def compute_midrank(x):
    J = np.argsort(x); Z = x[J]; N = len(x); T = np.zeros(N, dtype=float); i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]: j += 1
        T[i:j] = 0.5 * (i + j - 1); i = j
    T2 = np.empty(N, dtype=float); T2[J] = T; return T2

def fast_deLong(preds_sorted, label_1_count):
    m = label_1_count; n = preds_sorted.shape[1] - m
    pos = preds_sorted[:, :m]; neg = preds_sorted[:, m:]
    k = preds_sorted.shape[0]
    tx = np.empty([k, m]); ty = np.empty([k, n]); tz = np.empty([k, m + n])
    for r in range(k):
        tx[r, :] = compute_midrank(pos[r, :]); ty[r, :] = compute_midrank(neg[r, :])
        tz[r, :] = compute_midrank(preds_sorted[r, :])
    aucs = tz[:, :m].sum(axis=1) / m / n - float(m + 1.0) / 2.0 / n
    v01 = (tz[:, :m] - tx[:, :]) / n; v10 = 1.0 - (tz[:, m:] - ty[:, :]) / m
    sx = np.cov(v01); sy = np.cov(v10); delongcov = sx / m + sy / n
    return aucs, delongcov

def delong_roc_test(y_true, preds1, preds2):
    y_true = np.asarray(y_true, dtype=np.float64)
    preds1 = np.asarray(preds1); preds2 = np.asarray(preds2)
    idx = np.argsort(-y_true); y_true = y_true[idx]; preds1 = preds1[idx]; preds2 = preds2[idx]
    preds_sorted = np.vstack((preds1, preds2))
    aucs, cov = fast_deLong(preds_sorted, int(y_true.sum()))
    try:
        denom = np.sqrt(cov[0, 0] + cov[1, 1] - 2 * cov[0, 1])
        z = (aucs[0] - aucs[1]) / denom; p = 2 * (1 - norm.cdf(abs(z)))
    except Exception:
        z, p = np.nan, np.nan
    return z, p

# ---- 校准度量 ----
def calib_metrics(y_true, proba):
    p = np.clip(proba, 1e-6, 1 - 1e-6)
    logit = np.log(p / (1 - p))
    m = LogisticRegression(max_iter=1000).fit(logit.reshape(-1, 1), y_true)
    slope = float(m.coef_[0, 0]); intercept = float(m.intercept_[0])
    eo = float(p.mean() / max(y_true.mean(), 1e-6))
    return slope, intercept, eo

# ---- 训练两模型 ----
print("=" * 70)
print("敏感性分析: XGBoost 2变量 (RADSCORE+AFP) vs 3变量 (+Sex)")
print("=" * 70)
print(f"scale_pos_weight = {scale_pos_weight:.4f}")

MODELS = {}
for name in ['Combined2', 'Combined3']:
    cfg = {'model': XGBClassifier(**xgb_params).fit(X['train'][name], y_train)}
    for key, _, _, _ in DATASETS:
        cfg[f'prob_{key}'] = cfg['model'].predict_proba(X[key][name])[:, 1]
    fpr, tpr, thr = roc_curve(y_train, cfg['prob_train'])
    cfg['threshold'] = thr[np.argmax(tpr - fpr)]
    for key, _, _, _ in DATASETS:
        cfg[f'pred_{key}'] = (cfg[f'prob_{key}'] >= cfg['threshold']).astype(int)
    MODELS[name] = cfg

# ---- 内部 5-fold CV AUC (训练集) ----
print("\n内部 5-fold CV AUC (训练集, StratifiedKFold seed=42):")
for name in ['Combined2', 'Combined3']:
    model = XGBClassifier(**xgb_params)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    aucs = cross_val_score(model, X['train'][name], y_train, cv=cv,
                           scoring='roc_auc', n_jobs=-1)
    MODELS[name]['cv_aucs'] = aucs
    print(f"  {name}: mean={aucs.mean():.4f} (sd={aucs.std():.4f}), folds={np.round(aucs, 4).tolist()}")

# ---- 逐数据集比较 ----
print("\n各数据集性能 (各自训练集 Youden 阈值, Bootstrap 95% CI):")
rows = []
for name in ['Combined2', 'Combined3']:
    c = MODELS[name]
    for key, disp in [(k, d) for k, _, _, d in DATASETS]:
        metrics = {}
        for m in ['auc', 'acc', 'sens', 'spec']:
            p, lo, hi = bootstrap_metric_ci(y[key], c[f'prob_{key}'], c[f'pred_{key}'], m)
            metrics[m] = (p, lo, hi)
        sl, ic, eo = calib_metrics(y[key], c[f'prob_{key}'])
        print(f"  {name} [{disp}] thr={c['threshold']:.4f}: "
              f"AUC {metrics['auc'][0]:.3f} ({metrics['auc'][1]:.3f}-{metrics['auc'][2]:.3f}) | "
              f"ACC {metrics['acc'][0]:.3f} | Sens {metrics['sens'][0]:.3f} | Spec {metrics['spec'][0]:.3f} | "
              f"calib slope={sl:.3f} E/O={eo:.3f}")
        for m in ['auc', 'acc', 'sens', 'spec']:
            p, lo, hi = metrics[m]
            rows.append({'Model': name, 'Dataset': disp, 'Metric': m.upper(),
                         'Value': p, 'CI_low': lo, 'CI_high': hi})

# ---- DeLong 比较 ----
print("\nDeLong 两两检验 (2变量 vs 3变量):")
delong_rows = []
for key, disp in [(k, d) for k, _, _, d in DATASETS]:
    z, p = delong_roc_test(y[key], MODELS['Combined2'][f'prob_{key}'],
                           MODELS['Combined3'][f'prob_{key}'])
    a2 = roc_auc_score(y[key], MODELS['Combined2'][f'prob_{key}'])
    a3 = roc_auc_score(y[key], MODELS['Combined3'][f'prob_{key}'])
    print(f"  [{disp}] AUC(2var)={a2:.4f} vs AUC(3var)={a3:.4f}  Δ={a3-a2:+.4f}  DeLong P={p:.4f}")
    delong_rows.append({'Dataset': disp, 'AUC_2var': a2, 'AUC_3var': a3,
                        'delta_AUC': a3 - a2, 'DeLong_P': p})

# ---- 汇总输出 ----
summary = ["=" * 70, "敏感性分析汇总: XGBoost 2变量 vs 3变量(加Sex)", "=" * 70,
           f"scale_pos_weight={scale_pos_weight:.4f}", ""]
for name in ['Combined2', 'Combined3']:
    aucs = MODELS[name]['cv_aucs']
    summary.append(f"{name} 内部5-fold CV AUC: mean={aucs.mean():.4f} sd={aucs.std():.4f}")
summary.append("")
summary.append("DeLong (2var vs 3var):")
for r in delong_rows:
    summary.append(f"  {r['Dataset']}: AUC2={r['AUC_2var']:.4f} AUC3={r['AUC_3var']:.4f} "
                   f"Δ={r['delta_AUC']:+.4f} P={r['DeLong_P']:.4f}")

out_csv = os.path.join(OUTPUT_DIR, 'sensitivity_sex_metrics.csv')
pd.DataFrame(rows).to_csv(out_csv, index=False, encoding='utf-8-sig')
out_delong = os.path.join(OUTPUT_DIR, 'sensitivity_sex_delong.csv')
pd.DataFrame(delong_rows).to_csv(out_delong, index=False, encoding='utf-8-sig')
out_txt = os.path.join(OUTPUT_DIR, 'sensitivity_sex_summary.txt')
with open(out_txt, 'w', encoding='utf-8') as f:
    f.write("\n".join(summary) + "\n")

print("\n".join(summary))
print(f"\nSaved: {out_csv}")
print(f"Saved: {out_delong}")
print(f"Saved: {out_txt}")
