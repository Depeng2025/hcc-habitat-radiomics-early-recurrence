# -*- coding: utf-8 -*-
"""
=====================================================================
STEP 4b: 影像组学特征级 SHAP —— 18 个 LASSO 特征 (按生境分区着色)
=====================================================================
背景: 最终联合模型仅 2 变量 (mixed_RADSCORE + AFP), 其 SHAP 蜂群图信息
      量有限 (近似可加). 本脚本在 radscore 内部 18 个被 LASSO 选中的
      影像组学特征上直接训练 XGBoost, 用 SHAP 量化各特征与各生境分区
      (瘤内 H1/H2/H3 + 瘤周 5mm PERI5) 对 HCC 复发的判别贡献.

输出: 第四步/output/SHAP_Summary_18features.tiff
      —— SHAP 蜂群图 (点按特征值红高蓝低着色), y 轴特征标签按生境分区着色,
         特征按 [分区聚合重要性 → 区内单个重要性] 降序分组排列.

依赖: pandas, numpy, shap, xgboost, matplotlib, PIL
=====================================================================
"""
import os
import io
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from PIL import Image
from sklearn.metrics import roc_auc_score
import xgboost as xgb
import shap

# ---------------- 路径 ----------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STEP1_OUT = os.path.join(os.path.dirname(BASE_DIR), '第一步', 'output')
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

LABEL_COL = 'label'
SEED = 42

# 分区配色
PART_COLORS = {'H1': '#d62728', 'H2': '#2ca02c', 'H3': '#ff7f0e', 'PERI5': '#9467bd'}

plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans'],
    'axes.unicode_minus': False,
    'font.size': 12,
})

# XGBoost 最优参数 (与第三步一致)
_BEST = {'colsample_bytree': 0.6, 'learning_rate': 0.05, 'max_depth': 2,
         'min_child_weight': 5, 'n_estimators': 100, 'reg_alpha': 0.1,
         'reg_lambda': 2.0, 'subsample': 0.8}


def safe_savefig(fig, path, dpi=300):
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=dpi, bbox_inches='tight')
    buf.seek(0)
    Image.open(buf).convert('RGB').save(path, format='TIFF',
                                        compression='tiff_lzw', dpi=(dpi, dpi))
    return path


def short_name(feat):
    """z_PERI5_PVP_glrlm_RunLengthNonUniformity -> PERI5 · PVP · RunLengthNonUniformity"""
    parts = feat.split('_')
    assert parts[0] == 'z'
    rest = parts[1:]
    if len(rest) == 2:                       # e.g. z_H2_ratio
        return f"{rest[0]} · {rest[1]}"
    return f"{rest[0]} · {rest[1]} · {rest[3]}"


def partition_of(feat):
    return feat.split('_')[1]


# ---------------- 数据 ----------------
df = pd.read_excel(os.path.join(STEP1_OUT, 'train_selected.xlsx'))
feats = [c for c in df.columns if c.startswith('z_')]
X = df[feats].values.astype(float)
y = df[LABEL_COL].values.astype(int)

scale_pos_weight = (y == 0).sum() / (y == 1).sum()
print(f"训练集 n={len(df)}, 阳性={int(y.sum())}, scale_pos_weight={scale_pos_weight:.4f}")

# ---------------- 模型 + SHAP ----------------
params = {'objective': 'binary:logistic', 'random_state': SEED, 'n_jobs': -1,
          'eval_metric': 'logloss', 'verbosity': 0, 'scale_pos_weight': scale_pos_weight}
params.update(_BEST)
model = xgb.XGBClassifier(**params).fit(X, y)

explainer = shap.TreeExplainer(model)
shap_vals = explainer.shap_values(X)

# 各数据集 AUC (供参考)
aucs = {}
for key, sel in [('train', 'train_selected.xlsx'), ('val', 'val_selected.xlsx'),
                 ('test', 'test_selected.xlsx')]:
    d = pd.read_excel(os.path.join(STEP1_OUT, sel))
    prob = model.predict_proba(d[feats].values.astype(float))[:, 1]
    aucs[key] = roc_auc_score(d[LABEL_COL].values.astype(int), prob)
print(f"18特征 XGBoost AUC: train={aucs['train']:.4f} val={aucs['val']:.4f} "
      f"test={aucs['test']:.4f}")

# ---------------- 特征重要性 + 分区聚合 ----------------
imp = pd.Series(np.abs(shap_vals).mean(axis=0), index=feats, name='mean|SHAP|')
partition_agg = imp.groupby(partition_of).sum().sort_values(ascending=False)
print("\n分区聚合重要性 (Σ mean|SHAP|):")
for p, v in partition_agg.items():
    print(f"  {p:<6} {v:.4f}")

# 分组排序: 分区按聚合重要性降序, 区内按单个重要性降序
ordered_feats = []
for p in partition_agg.index:
    members = imp[imp.index.map(partition_of) == p].sort_values(ascending=False)
    ordered_feats += list(members.index)

order_idx = [feats.index(f) for f in ordered_feats]
X_ord = X[:, order_idx]
shap_ord = shap_vals[:, order_idx]
names_ord = [short_name(f) for f in ordered_feats]

# ---------------- 蜂群图 ----------------
fig = plt.figure(figsize=(12, 8))
shap.summary_plot(shap_ord, features=X_ord, feature_names=names_ord,
                  plot_type="dot", sort=False, show=False,
                  max_display=len(names_ord))
ax = plt.gca()

# y 轴特征标签按分区着色
for tick in ax.get_yticklabels():
    label = tick.get_text()
    p = None
    for feat in feats:
        if short_name(feat) == label:
            p = partition_of(feat)
            break
    if p is not None:
        tick.set_color(PART_COLORS[p])
        tick.set_fontweight('bold')

# 分区图例 (置于 colorbar 右侧, 不遮挡蜂群图)
handles = [mpatches.Patch(color=c, label=p) for p, c in PART_COLORS.items()]
cax = [a for a in fig.axes if a is not ax][0]   # colorbar 轴
legend_x = cax.get_position().x1 + 0.02         # colorbar 右缘 (figure 坐标)
fig.legend(handles=handles, title='Habitat partition', loc='center left',
           bbox_to_anchor=(legend_x, 0.5), framealpha=0.9,
           fontsize=10, title_fontsize=10)

plt.title("SHAP Summary Plot — 18 Radiomics Features by Habitat Partition\n"
          "(XGBoost)", fontsize=13)
plt.tight_layout()
out = safe_savefig(fig, os.path.join(OUTPUT_DIR, 'SHAP_Summary_18features.tiff'), dpi=300)
plt.close()

print("\n特征重要性 (mean|SHAP|, 按分区):")
for f in ordered_feats:
    print(f"  {partition_of(f):<6} {short_name(f):<55} {imp[f]:.4f}")
print(f"\n已保存: {out}")
