#!/usr/bin/env Rscript
# ============================================================
# TCGA 风险分组（0低风险 / 1高风险）差异分析 + 完整可视化
# 柳叶刀(Lancet)风格配色
# 所有图片输出为 TIFF 格式，尺寸统一优化
# Rscript analysis_tcga_risk_lancet.R
# ============================================================

setwd("D:/DLHCC")
dir.create("analysis", showWarnings=FALSE)

# 检查并安装必要的包
required_pkgs <- c("data.table", "ggplot2", "ggrepel", "pheatmap", 
                   "ggridges", "reshape2", "gridExtra")
for (pkg in required_pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
}
suppressMessages(library(data.table))
suppressMessages(library(ggplot2))
suppressMessages(library(ggrepel))
suppressMessages(library(pheatmap))
suppressMessages(library(ggridges))
suppressMessages(library(reshape2))
suppressMessages(library(gridExtra))

# ---------- 柳叶刀调色板 ----------
lancet_blue  <- "#00468B"   # 主蓝色
lancet_red   <- "#ED0000"   # 主红色
lancet_green <- "#42B540"   # 主绿色
lancet_grey  <- "#ADB6B6"   # 浅灰色（非显著点）
lancet_dark  <- "#1B1919"   # 深色文字
lancet_bg    <- "#FFFFFF"   # 白背景
lancet_orange <- "#FDAE6B"  # 辅助橙（p<0.05但FDR不显著的上调）
lancet_cyan   <- "#74ADD1"  # 辅助蓝（p<0.05但FDR不显著的下调）

# 全局 ggplot2 主题（柳叶刀风格）
theme_lancet <- function(base_size = 12) {
  theme_classic(base_size = base_size) %+replace%
    theme(
      text = element_text(family = "sans", colour = lancet_dark),
      plot.title = element_text(hjust = 0.5, face = "bold", size = base_size + 2),
      plot.subtitle = element_text(hjust = 0.5, size = base_size, colour = "grey30"),
      axis.line = element_line(colour = lancet_dark, size = 0.4),
      axis.ticks = element_line(colour = lancet_dark, size = 0.3),
      axis.text = element_text(colour = lancet_dark),
      legend.position = "right",
      legend.title = element_text(face = "bold", size = base_size - 1),
      legend.text = element_text(size = base_size - 2),
      panel.grid = element_blank(),
      panel.background = element_rect(fill = lancet_bg, colour = NA),
      plot.background = element_rect(fill = lancet_bg, colour = NA),
      legend.background = element_rect(fill = lancet_bg, colour = NA)
    )
}

cat("===== TCGA 风险分组分析（0低风险 vs 1高风险）=====\n")
cat(format(Sys.time()), "\n")

# ---- 1. 加载数据 ----
dat     <- fread("TCGA_matched_transcriptome.csv", data.table=FALSE)
gnames  <- dat[,1]; xdf <- dat[,-1]
li      <- which(gnames == "label")
gi      <- which(gnames != "label")
label   <- as.integer(unlist(xdf[li,]))
expr    <- vapply(xdf[gi,], function(x) as.numeric(as.character(x)), numeric(length(gi)))
rownames(expr) <- gnames[gi]
cat(sprintf("样本数: %d (低风险组0: %d, 高风险组1: %d)\n", 
            length(label), sum(label==0), sum(label==1)))

# ---- 2. Welch t检验（两组差异分析）----
i0 <- which(label == 0); i1 <- which(label == 1)
n0 <- length(i0); n1 <- length(i1)
m0 <- rowMeans(expr[, i0, drop=FALSE])
m1 <- rowMeans(expr[, i1, drop=FALSE])
v0 <- apply(expr[, i0, drop=FALSE], 1, var)
v1 <- apply(expr[, i1, drop=FALSE], 1, var)
se    <- sqrt(v0/n0 + v1/n1)
tstat <- (m1 - m0) / se
dfn   <- (v0/n0 + v1/n1)^2
dfd   <- (v0/n0)^2/(n0-1) + (v1/n1)^2/(n1-1)
pval  <- 2 * pt(-abs(tstat), df = dfn/dfd)
pval[is.na(pval) | pval > 1] <- 1
logFC <- log2((m1 + 1e-6) / (m0 + 1e-6))
FDR   <- p.adjust(pval, method = "BH")

res <- data.frame(gene = rownames(expr), mean0 = m0, mean1 = m1,
                  logFC = logFC, t = tstat, p = pval, FDR = FDR, 
                  stringsAsFactors = FALSE)
res <- res[order(res$p), ]
fwrite(res, "analysis/diff_results.csv")
cat(sprintf("p<0.05: %d   FDR<0.05: %d   FDR<0.10: %d   FDR<0.25: %d\n",
            sum(pval < 0.05), sum(FDR < 0.05), sum(FDR < 0.10), sum(FDR < 0.25)))

# ==================== 3. 优化火山图（无基因标签，鲜艳版） ====================
res$nlp <- -log10(pmax(res$p, 1e-300))

# 定义显著性分类（更细致的上色）
res$sig <- "NS"
res$sig[res$p < 0.05 & res$logFC > 1 & res$FDR >= 0.05]   <- "p<0.05 (up)"
res$sig[res$p < 0.05 & res$logFC < -1 & res$FDR >= 0.05]  <- "p<0.05 (down)"
res$sig[res$FDR < 0.05 & res$logFC > 1]   <- "FDR<0.05 (up)"
res$sig[res$FDR < 0.05 & res$logFC < -1]  <- "FDR<0.05 (down)"

# 鲜艳配色
cols <- c(
  "FDR<0.05 (up)"    = "#FF2A2A",  # 鲜红
  "p<0.05 (up)"      = "#FFA07A",  # 亮橙红
  "FDR<0.05 (down)"  = "#1E90FF",  # 闪蓝
  "p<0.05 (down)"    = "#87CEFA",  # 亮浅蓝
  "NS"               = "#D3D3D3"   # 浅灰
)

# 因子排序确保图层正确
res$sig <- factor(res$sig, levels = c("FDR<0.05 (up)", "p<0.05 (up)",
                                      "FDR<0.05 (down)", "p<0.05 (down)", "NS"))

# 基于宽松阈值的基因数量统计（p<0.05 & |logFC|>1）
n_up_loose   <- sum(res$p < 0.05 & res$logFC > 1)
n_down_loose <- sum(res$p < 0.05 & res$logFC < -1)

# 绘图
p_volcano <- ggplot(res, aes(x = logFC, y = nlp)) +
  # 背景灰点（非显著）
  geom_point(data = subset(res, sig == "NS"),
             aes(color = sig), size = 0.8, alpha = 0.4) +
  # 显著点叠加
  geom_point(data = subset(res, sig != "NS"),
             aes(color = sig), size = 1.5, alpha = 0.7) +
  scale_color_manual(values = cols, name = "Significance") +
  # 阈值虚线
  geom_vline(xintercept = c(-1, 1), linetype = "dashed",
             color = "grey40", size = 0.5) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed",
             color = "grey40", size = 0.5) +
  labs(
    x = expression(log[2]~"Fold Change (High-risk vs Low-risk)"),
    y = expression(-log[10]~italic(P)~value),
    title = "Volcano Plot: High-risk vs Low-risk",
    subtitle = sprintf("p<0.05 & |logFC|>1 | Up: %d genes | Down: %d genes",
                       n_up_loose, n_down_loose)
  ) +
  theme_lancet(12) +
  theme(
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 10),
    legend.text = element_text(size = 9),
    plot.subtitle = element_text(color = "grey20", size = 11)
  ) +
  scale_x_continuous(expand = expansion(mult = 0.05)) +
  scale_y_continuous(expand = expansion(mult = 0.05)) +
  # 右上角基因总数注释（无需 label.size 参数，避免 warning）
  annotate("label", x = Inf, y = Inf,
           label = paste("Total DEGs:", n_up_loose + n_down_loose),
           hjust = 1.1, vjust = 1.5,
           fill = "white", color = lancet_dark, size = 4,
           fontface = "bold")

# 保存为 TIFF 格式，尺寸统一 10×7 英寸
ggsave("analysis/volcano.tiff", p_volcano,
       width = 10, height = 7, dpi = 400, compression = "lzw")
cat("优化火山图（无标签，鲜艳版，TIFF格式） -> analysis/volcano.tiff\n")

# ---- 4. GSEA 准备（排序基因集）----
rnk <- res$t; names(rnk) <- res$gene
rnk <- sort(rnk[!is.na(rnk)], decreasing = TRUE)
write.table(data.frame(gene = names(rnk), tstat = rnk),
            "analysis/gsea_rank.rnk", sep = "\t", quote = FALSE, row.names = FALSE, col.names = FALSE)

# Hallmark 基因集（同原脚本）
paths <- list(
  TNFA_SIGNALING_VIA_NFKB = c("JUNB","CXCL2","ATF3","NFKBIA","TNFAIP3","ZFP36","FOSL1","NFKB1","EGR1","FOS","BIRC3","CCL4","CEBPB","RELB","NFKBIE","PPP1R15A","ETS2","IER3","FOSB","EGR2","IL1B","NR4A1","MCL1","MYC","BCL6","CD80","IL6","SOCS3","GADD45B","IRF1","TNFAIP2","CTGF","CCL5","SOD2","TNIP2","PLK2","IER2","AREG","CSF1","IL18","CXCL3","PTGER4","CSF2","PTX3","F3","PRDM1","TNF","PHLDA1","PSMB9","CCL20","EDN1","MAP3K8","CCL2","F2R","IL7R","SLC2A6","RGS16","BTG1","TRAF1","CLDN1","IFNGR1","CXCL11","TNFAIP6","BRD2","TRIB1","HRH1","LTB","HES1","IL12B","CXCL1","CXCL10","HLA-A","CD83","HBEGF","SLC16A6","FTH1","CREB5","HDAC5","CFLAR","IER5","IL1A","CXCL6","GEM","IL23A","IFI16","DUSP2","NFATC2","LY6E","INHBA","TNFRSF9","GPR183","ZC3H12A","CSF3","SOCS1","PHLDA2","FOSL2","PDE4B","PLEK","LITAF","ETV3","TNFRSF1B","NFKB2","NR4A2","KLF2","RHOB","MAFF","XCL1","MYD88","PTPN1","EHD1","NR4A3","GADD45A","NFE2L2","RNF19B","NINJ1","BCL2A1","MARCKS","CD44","CDKN1A","LIF","PER1","TIPARP","SAT1","CEBPD","G0S2","TRIP10","RIPK2","ICAM1","DUSP1","TNIP1","TNFRSF1A","RELA","IL6ST","BHLHE40","PNRC1","PTGS2","TCF7L2","TNFAIP8","MSC","ACVR1B","DAXX","DUSP5","PPP1CB","THBS1"),
  HYPOXIA = c("PGK1","PDK1","GBE1","PFKL","ALDOA","ENO2","PGM1","NDRG1","HK2","ALDOC","GPI","MXI1","SLC2A1","P4HA1","ADM","LDHA","PGF","PPFIA4","FAM162A","EGLN1","TPI1","CDKN1A","HK1","PFKP","GAPDH","DDIT4","VLDLR","TGFB3","BTG1","PLIN2","WSB1","CASP6","ERO1A","IGFBP3","IGFBP1","ISG20","IGFBP2","LOX","ANKZF1","CCNG2","STC1","S100A4","PLAUR","GYS1","TMEM45A","DTNA","KDM3A","ZNF292","MYH9","FOS","BNIP3","EGLN3","STC2","EFNA3","CP","KCNMB1","TUBB6","TF","CTGF","F3","METTL16","ACOT7","GRHPR","VEGFA","ID2","TFRC","BCL2","PIM1","IRS2","EXT1","ERRFI1","PRDX5","LXN","CITED2","TGM2","BHLHE40","SLC2A3","CDKN1B","PPARGC1A","PLA2G6","PMAIP1","CYR61","LARGE1","FABP5","CAV1","EREG","CAVIN3","ANGPTL4","XPNPEP1","ALDOB","ANXA2","SLC37A4","BGN","PTP4A3","MIF","ENO1","AMPD3","GAPDHS","ZC3H12A","CXCR4","DNAJA4","SERPINE1","STRADA","CA12","ANXA1","HKDC1","TPD52","CHCHD2","TIPARP","NR3C1","CALR","SPAG4","TGFB1","PHKG1","COL5A1","PCK1","KDELR3","PFKFB3","FLT1","PCYT2","SOX9","DDIT3","P4HA2","ERO1L","SCARB1","PIM3","CITED4","NARF","UCK2","ARNT2","TMEM38A","KIF5A","NFIL3","FABP3","MYLK","ADM2","HS3ST1","S100A3","TGFA","GPC3","PLOD2","TNFAIP3","NET1","ERO1B","CHPF"),
  INFLAMMATORY_RESPONSE = c("IL18","CCL5","CCL4","CCL2","IL1B","CXCL10","CXCL11","CXCL9","IL12B","CXCL1","IL6","TNF","CSF1","CSF2","CSF3","IL7","IL15","IL1A","IL2","CXCL3","CXCL2","CCL20","CXCL6","CXCL8","IL6R","IL2RA","IL2RG","IL1R1","IL18R1","TNFRSF1A","TNFRSF1B","IFNGR1","IFNGR2","OSMR","IL10RA","IL4R","MYD88","IRAK3","NFKB1","NFKBIA","NFKBIZ","RELA","RELB","JUNB","FOS","FOSL1","FOSL2","CEBPB","STAT1","STAT2","IRF1","IRF7","IRF8","RIPK2","SOD2","PTGS2","TNFAIP3","TNFAIP6","ICAM1","VCAM1","SELE","SELP","CD44","CD55","CD59","CSF3R","CSF2RB","CD40","CD80","CD86","TNFRSF9","TLR2","TLR3","KCNJ2","P2RX7","HRH1","CYSLTR1","PTAFR","F2R","GPR132","SLC11A2","SLC7A1","SLC7A5","ATP2C1","AQP9","SLC28A2","SLC39A12","IFITM1","BST2","IFI35","IFI44","IFI44L","MX1","MX2","OAS1","OAS2","OAS3","IFIT1","IFIT2","IFIT3","IFI16","ISG15","ISG20","RSAD2","IRF2","CCL7","TAP1","TAPBP","PSMB8","PSMB9","PSME1","PSME2","HLA-A","HLA-B","HLA-C","B2M","CALR","LGMN","NAMPT","PDE4B","GADD45B","GADD45G","EDN1","LAMP3","SERPINA1","SERPINE1","HAS2","CHI3L1","PELI1","LITAF","SLC4A4","ADM","PLAUR","TGFA","FOSB","LCN2","CD70","TRANK1","NR4A1","EGR1","EGR2","GCH1","ACOD1","PLA2G4A","TNFRSF4","TNFSF9","CD274","PDCD1LG2","TLR7","LIF","CCL8","CCL3","IL27","IL21","CXCL13","IL17A","IL22","IL33","TNFSF11","ACKR3","CXCR6","CCR7","CXCR4","PTX3","SAA1","PTGER2","ADGRE1","FPR1","MNDA","NLRP3","BTK","TIRAP","BST1","FCER1G","FCGR2A","C3AR1","SIGLEC1"),
  EPITHELIAL_MESENCHYMAL_TRANSITION = c("MMP2","MMP9","MMP14","TIMP1","COL1A1","COL1A2","COL3A1","COL5A1","COL5A2","COL6A1","COL6A2","COL6A3","COL7A1","COL8A1","COL12A1","COL16A1","FN1","TNC","SPARC","SPOCK1","FBN1","FBN2","LOX","LOXL1","LOXL2","PLOD1","PLOD2","PLOD3","POSTN","SERPINE1","SERPINE2","TGFB1","TGFB2","TGFB3","TGFBR1","TGFBR2","TGFBR3","SMAD2","SMAD3","SMAD7","BMP1","BMP2","WNT2","WNT5A","SFRP1","SFRP4","FZD8","CDH1","CDH2","CDH6","OCLN","CLDN3","CLDN4","CLDN7","DSP","KRT7","KRT17","KRT19","VIM","SNAI1","SNAI2","TWIST1","TWIST2","ZEB1","ZEB2","TCF3","TCF4","FOXC2","GSC","SIX1","PRRX1","HOXA7","LBX1","ITGA5","ITGAV","ITGB1","ITGB3","ITGB5","MMP1","MMP3","MMP10","MMP13","THBS1","THBS2","VCAN","SDC1","SDC2","CD44","CDH11","SPP1","ADAM12","ADAM19","TNFRSF11B","TNFRSF12A","CCN1","CCN2","CTGF","IGFBP2","IGFBP4","IGFBP5","NOX4","LAMA1","LAMA2","LAMA3","LAMB3","LAMC1","LAMC2","BGN","DCN","LUM","FMOD","COMP","ASPN","EDIL3","TAGLN","ACTA2","MYLK","CALD1","CNN1","TPM1","TPM2","FLNA","FLNB","FLNC","TAGAP","PFN2","ARPC2","CAPG","MATN2","NNMT","TIMP3","PDGFA","PDGFB","PDGFRA","PDGFRB","EGFR","FGFR1","FAP","CTSK","HTRA1","FSTL1","FSCN1","EMP3","GADD45A","GADD45B","TPM4","RHOB","EHD2","ITGBL1","MAGEE1","GPX7","MGP","FBLN1","FBLN2","FBLN5","PCOLCE","COL4A1","COL4A2","MATN3","WNT10A","WIPF1","FAM107B","TGM2","MCRS1","HGF","WNT7A","SERPINH1","CD59","JUN","DAB2","LEF1","FOXQ1","FSTL3","GPC6","ROR2"),
  G2M_CHECKPOINT = c("AURKA","AURKB","BIRC5","BUB1","BUB1B","CCNA2","CCNB1","CCNB2","CCNF","CDK1","CDKN3","CENPA","CENPE","CENPF","CKS1B","DBF4","E2F1","E2F3","GTSE1","HMGB2","HMMR","KPNA2","KIF11","KIF15","KIF20A","KIF23","KIF2C","KIF4A","KIFC1","MAD2L1","MCM2","MCM3","MCM4","MCM5","MCM6","MCM7","MKI67","MYBL2","NCAPD2","NCAPG","NCAPH","NDC80","NEK2","NUSAP1","PLK1","PLK4","PRC1","PTTG1","RACGAP1","RAD21","RAD51","RRM2","SMC2","SMC4","STMN1","TOP2A","TPX2","TROAP","TTK","TUBB4B","TUBG1","TYMS","UBE2C","ZWINT","CDC6","CDC20","CDC25A","CDC25B","CDC25C","CDC45","CDCA5","CDCA8","CDK2","CENPM","CEP55","CKS2","E2F2","ECT2","ESPL1","EXO1","FEN1","FOXM1","MELK","MND1","NASP","NUCKS1","ORC6","PCNA","POLA1","PSRC1","RFC2","RFC4","SPC24","SPC25","STIL","TACC3","TICRR","TP53","WEE1"),
  E2F_TARGETS = c("AURKA","AURKB","BRCA1","BRCA2","BUB1","BUB1B","CCNA2","CCNB1","CCNB2","CCNE1","CCNE2","CDC20","CDC25A","CDC45","CDC6","CDK1","CDK2","CDKN1C","CHEK1","CHEK2","DEK","DHFR","DUT","E2F1","E2F2","E2F3","EXO1","FANCA","FANCD2","FANCG","FEN1","FOXM1","GMPS","H2AFX","HMGB2","KPNA2","LIG1","MAD2L1","MCM2","MCM3","MCM4","MCM5","MCM6","MCM7","MKI67","MYBL2","NASP","ORC1","PCNA","PLK1","PLK4","POLA1","POLE","POLE2","PRIM1","PRIM2","PSMC3IP","RACGAP1","RAD51","RAD51AP1","RAD54L","RFC2","RFC3","RFC4","RFC5","RNASEH2A","RPA2","RPA3","RRM2","SLBP","SMC2","SMC4","TFDP1","TK1","TOP2A","TP53","TYMS","UNG","WEE1","WHSC1","ATAD2","BLM","BRIP1","CDC7","CDCA7","CDT1","CHAF1B","CLSPN","CTPS1","CTPS2","DKC1","DNA2","DONSON","DSCC1","DTL","EZH2","GINS2","HELLS","HMGA1","LIG2","MCM10","MSH2","NCAPD2","NOLC1","NUP155","NUP205","ORC2","PA2G4","PLK2","POLA2","PPAT","PRPS1","PTTG1","RANBP1","RBM14","RIOK3","RPLP1","RPS6","RUVBL2","SET","SLC25A5","SRM","SUV39H1","TIPIN","TMPO","TRIP13","TUBG1","UNG","WDR12","XRCC5"),
  MYC_TARGETS_V1 = c("APEX1","CAD","CCNA2","CCNB1","CDK4","CDKN1A","CSE1L","DDX18","DKC1","EBNA1BP2","EIF1AX","EIF2S1","EIF3A","EIF3D","EIF3E","EIF3F","EIF3G","EIF3H","EIF3I","EIF3J","EIF3K","EIF3L","EIF4A1","EIF4E","EIF4G2","ELP2","EXOSC8","FBL","GCN1","GEMIN5","GRWD1","HSP90AB1","HSPD1","IMP4","LSM2","LSM3","LSM4","MAT2A","MRPL3","NCL","NDUFAB1","NIP7","NKRF","NME1","NOLC1","NOP2","NOP56","NPM1","PA2G4","PES1","PHB","PHB2","PPAN","PPRC1","PRDX3","PRMT1","PUS1","RABEPK","RAN","RBM19","RCL1","RIOK1","RPL10A","RPL11","RPL13","RPL13A","RPL14","RPL18","RPL22","RPL23","RPL24","RPL27","RPL28","RPL31","RPL35","RPL36","RPL37A","RPL38","RPL7","RPL7A","RPL8","RPL9","RPS11","RPS13","RPS15A","RPS16","RPS19","RPS20","RPS24","RPS25","RPS28","RPS3A","RPS4X","RPS5","RPS6","RPS8","RPS9","RRP1","RRP9","RSL1D1","SF3B3","SLC25A3","SNRPB","SNRPD1","SNRPD3","TAF1A","TAF1B","WDR12","WDR18","WDR3","WDR43","WDR74","XRCC5","ACIN1","AK2","ALG3","ALYREF","ARF4","ATIC","ATP5C1","BYSL","CCDC86","CEBPZ","CENPW","CHAF1A","CHCHD2","CIAO1","CMPK1","COASY","COX5A","DDX10","DDX21","DDX39A","DDX49","DDX55","DHX33","DHX9","EIF2B5","EIF4A3","EXOSC2","EXOSC4","EXOSC5","FASTKD2","H2AFZ","HDLBP","HDX","HSPA4","HSPA9","IARS","IFI16","IPO9","KPNA4","KRR1","LARS","LAS1L","LRPPRC","LYAR","MARS","METTL1","MORF4L2","MPHOSPH10","MRM3","MRPL37","MRPL39","MRPL47","MRPL52","MRPL9","MRPS18B","MRPS31","MRPS5","MRTO4","MTIF2","MTPAP","MYBBP1A","NLE1","NOL11","NOL8","NOP14","NOP16","NSUN2","NUBP1","NXT1","OPA1","PELP1","PFAS","PGM3","PHF5A","PLD3","PPIL3","PRDX4","PREP","PRPF31","PRPF6","PRPS2","PUS7","RABEP1","RARS","REPIN1","RPL18A","RPL22L1","RPL23A","RPL3","RPL32","RPL36A","RPLP0","RPS10","RPS14","RPS15","RPS18","RPS21","RPS23","RPS27","RPS27A","RPS2","RPS29","RPS3","RPS7","RRP12","SAMM50","SERBP1","SFPQ","SLC16A1","SNORA14A","SNRPB2","STOML2","SUPV3L1","TARDBP","TFB1M","TFB2M","TIMM17A","TIMM44","TMEM97","TOMM40","TOP1","TRMU","TRUB2","TUFM","UBE2L3","UBTF","UCHL5","USP1","UTP11","UTP14A","UTP18","UTP6","WDR36","WDR4","WDR77","XPO1","YTHDC1","ZCCHC9","ZNF593")
)

# ---- 5. GSEA 核心函数（带 permutation）----
gsea_single <- function(ranks, gset, np = 1000) {
  N  <- length(ranks)
  in_set <- names(ranks) %in% gset
  Nh <- sum(in_set)
  if (Nh < 10) return(list(ES = NA, NES = NA, pval = NA, Nh = Nh))
  
  hit_weights <- abs(ranks)
  hit_sum <- sum(hit_weights[in_set])
  if (hit_sum < 1e-10) return(list(ES = NA, NES = NA, pval = NA, Nh = Nh))
  
  w_hit  <- hit_weights / hit_sum; w_hit[!in_set] <- 0
  w_miss <- rep(1/(N - Nh), N); w_miss[in_set] <- 0
  cs <- cumsum(w_hit - w_miss)
  ES <- cs[which.max(abs(cs))]
  
  pes <- numeric(np)
  for (i in seq_len(np)) {
    ps  <- sample(N, Nh)
    pin <- rep(FALSE, N); pin[ps] <- TRUE
    pw  <- hit_weights / hit_sum; pw[!pin] <- 0
    wm  <- rep(1/(N - Nh), N); wm[pin] <- 0
    pcs <- cumsum(pw - wm)
    pes[i] <- pcs[which.max(abs(pcs))]
  }
  NES <- if (sd(abs(pes)) > 0) ES / mean(abs(pes)) else NA
  pv  <- if (ES >= 0) mean(pes >= ES) else mean(pes <= ES)
  pv  <- max(pv, 1/np)
  list(ES = ES, NES = NES, pval = pv, Nh = Nh, running_score = cs, in_set = in_set)
}

# 运行 GSEA
gsea_res_list <- list()
gsea_out <- data.frame(pathway = character(), ES = numeric(), NES = numeric(),
                       pval = numeric(), size = integer(), Nh = integer(),
                       stringsAsFactors = FALSE)
cat("\n--- GSEA 分析结果 ---\n")
for (nm in names(paths)) {
  gs <- paths[[nm]]
  r <- gsea_single(rnk, gs, np = 1000)
  if (!is.na(r$ES)) {
    gsea_out[nrow(gsea_out) + 1, ] <- c(nm, r$ES, r$NES, r$pval, length(gs), r$Nh)
    gsea_res_list[[nm]] <- r
  }
  cat(sprintf("%-40s %5d   %5d   %+7.4f  %+7.4f  %.4f\n",
              nm, length(gs), r$Nh,
              ifelse(is.na(r$ES), NA, r$ES),
              ifelse(is.na(r$NES), NA, r$NES),
              ifelse(is.na(r$pval), NA, r$pval)))
}
gsea_out$size  <- as.integer(gsea_out$size)
gsea_out$Nh    <- as.integer(gsea_out$Nh)
gsea_out$ES    <- as.numeric(gsea_out$ES)
gsea_out$NES   <- as.numeric(gsea_out$NES)
gsea_out$pval  <- as.numeric(gsea_out$pval)
gsea_out$FDR   <- p.adjust(gsea_out$pval, method = "BH")
gsea_out <- gsea_out[order(gsea_out$FDR), ]
fwrite(gsea_out, "analysis/gsea_results.csv")
cat(sprintf("\n显著富集通路: FDR<0.05=%d, FDR<0.10=%d, FDR<0.25=%d\n",
            sum(gsea_out$FDR < 0.05, na.rm = TRUE),
            sum(gsea_out$FDR < 0.10, na.rm = TRUE),
            sum(gsea_out$FDR < 0.25, na.rm = TRUE)))

# ==================== 6. GSEA 结果条形图（柳叶刀风格） ====================
if (nrow(gsea_out) > 0) {
  bar_dat <- gsea_out
  bar_dat$pathway <- gsub("_", " ", bar_dat$pathway)
  bar_dat$color <- ifelse(bar_dat$NES > 0, "Activated", "Suppressed")
  bar_dat <- bar_dat[order(bar_dat$NES), ]
  bar_dat$pathway <- factor(bar_dat$pathway, levels = bar_dat$pathway)
  p_bar_gsea <- ggplot(bar_dat, aes(x = NES, y = pathway, fill = color)) +
    geom_bar(stat = "identity", width = 0.7) +
    scale_fill_manual(values = c("Activated" = lancet_red, "Suppressed" = lancet_blue)) +
    labs(x = "Normalized Enrichment Score (NES)", y = "",
         title = "GSEA Hallmark Pathways (High-risk vs Low-risk)") +
    theme_lancet(11) +
    theme(legend.position = "top") +
    geom_vline(xintercept = 0, linetype = "dashed", color = "grey50")
  ggsave("analysis/gsea_barplot.tiff", p_bar_gsea, 
         width = 10, height = 7, dpi = 300, compression = "lzw")
  cat("GSEA 条形图（TIFF） -> analysis/gsea_barplot.tiff\n")
}

# ==================== 7. GSEA 富集曲线（柳叶刀风格，全部7条通路） ====================
if (length(gsea_res_list) > 0) {
  selected_pathways <- names(paths)
  
  for (pw in selected_pathways) {
    r <- gsea_res_list[[pw]]
    if (!is.null(r) && !is.na(r$ES)) {
      N <- length(r$running_score)
      df_top <- data.frame(rank = 1:N, score = r$running_score, hit = r$in_set)
      hit_pos <- which(r$in_set)
      
      p_curve <- ggplot(df_top, aes(x = rank, y = score)) +
        geom_line(color = lancet_blue, size = 0.8) +
        geom_hline(yintercept = 0, linetype = "dashed", color = "grey50") +
        geom_segment(data = data.frame(x = hit_pos), aes(x = x, xend = x, y = -0.1, yend = 0.1),
                     color = lancet_red, size = 0.3, alpha = 0.5) +
        labs(x = NULL, y = "Running Enrichment Score",
             title = gsub("_", " ", pw),
             subtitle = paste0("ES = ", round(r$ES, 4), ", NES = ", round(r$NES, 4),
                               ", p = ", r$pval)) +
        theme_lancet(10) +
        theme(axis.text.x = element_blank(),
              axis.title.x = element_blank(),
              plot.margin = margin(5,5,2,5))
      
      metric_vals <- as.numeric(rnk)
      df_bottom <- data.frame(rank = 1:N, metric = metric_vals)
      hit_df <- data.frame(rank = hit_pos, metric = metric_vals[hit_pos])
      
      p_metric <- ggplot(df_bottom, aes(x = rank, y = metric)) +
        geom_line(color = lancet_green, size = 0.4, alpha = 0.7) +
        geom_hline(yintercept = 0, linetype = "dashed", color = "grey40", size = 0.3) +
        geom_point(data = hit_df, aes(x = rank, y = metric), 
                   color = lancet_red, size = 1.0, alpha = 0.6) +
        labs(x = "Gene Rank", y = "t-statistic\n(rank metric)") +
        theme_lancet(9) +
        theme(plot.margin = margin(2,5,5,5))
      
      combined <- arrangeGrob(p_curve, p_metric, ncol = 1, heights = c(2, 1))
      outfile <- paste0("analysis/gsea_curve_", gsub("_", "", pw), ".tiff")
      ggsave(outfile, combined, width = 10, height = 7, dpi = 300, compression = "lzw")
      cat("GSEA 富集曲线（柳叶刀风格，TIFF） ->", outfile, "\n")
    }
  }
}

# ==================== 8. 热图（Top 50 差异基因，柳叶刀配色，增大画板） ====================
de_top <- res[abs(res$logFC) > 1 & res$p < 0.05, ]
de_top <- de_top[order(abs(de_top$logFC), decreasing = TRUE), ]
n_heat <- min(50, nrow(de_top))
if (n_heat >= 3) {
  heat_genes <- head(de_top$gene, n_heat)
  mat <- expr[heat_genes, ]
  mat <- t(scale(t(mat)))
  annotation_col <- data.frame(Risk = ifelse(label == 0, "Low", "High"))
  rownames(annotation_col) <- colnames(mat)
  ann_colors <- list(Risk = c(Low = lancet_blue, High = lancet_red))
  pheatmap(mat, cluster_rows = TRUE, cluster_cols = TRUE,
           annotation_col = annotation_col, annotation_colors = ann_colors,
           show_rownames = TRUE, show_colnames = FALSE,
           fontsize = 6, fontsize_row = 6, fontsize_col = 6,
           main = "Top 50 Differentially Expressed Genes",
           color = colorRampPalette(c(lancet_blue, "white", lancet_red))(100),
           filename = "analysis/heatmap.tiff", width = 10, height = 7, 
           compression = "lzw", dpi = 300)
  cat("热图（柳叶刀配色，TIFF） -> analysis/heatmap.tiff\n")
} else {
  cat("热图跳过：差异基因不足3个。\n")
}

# ==================== 9. 山峦图（柳叶刀风格） ====================
tnfa_genes <- paths[["TNFA_SIGNALING_VIA_NFKB"]]
tnfa_res <- res[res$gene %in% tnfa_genes, ]
tnfa_res <- tnfa_res[order(tnfa_res$p), ]
ridge_genes <- head(tnfa_res$gene, 6)
if (length(ridge_genes) >= 3) {
  expr_sub <- expr[ridge_genes, ]
  df_ridge <- melt(expr_sub, varnames = c("gene", "sample"), value.name = "expression")
  df_ridge$Risk <- ifelse(label[match(df_ridge$sample, colnames(expr))] == 0, "Low", "High")
  p_ridge <- ggplot(df_ridge, aes(x = expression, y = gene, fill = Risk)) +
    geom_density_ridges(alpha = 0.7, scale = 1.2, rel_min_height = 0.01) +
    scale_fill_manual(values = c(Low = lancet_blue, High = lancet_red)) +
    labs(x = "Gene Expression (log2 normalized)", y = "",
         title = "Expression Density: Top TNFA Pathway Genes") +
    theme_lancet(11) +
    theme(legend.position = "top")
  ggsave("analysis/ridgeplot.tiff", p_ridge, 
         width = 10, height = 7, dpi = 300, compression = "lzw")
  cat("山峦图（柳叶刀风格，TIFF） -> analysis/ridgeplot.tiff\n")
} else {
  cat("山峦图跳过：TNFA通路差异基因不足3个。\n")
}

# ==================== 10. 气泡图（GSEA，柳叶刀风格） ====================
if (nrow(gsea_out) > 0) {
  tp <- gsea_out
  tp$short <- gsub("_", " ", tp$pathway)
  tp$nlp <- -log10(pmax(tp$FDR, 1e-300))
  tp <- tp[order(tp$NES), ]
  tp$short <- factor(tp$short, levels = tp$short)
  p_bubble <- ggplot(tp, aes(x = NES, y = short, size = size, color = nlp)) +
    geom_point() +
    scale_color_gradient(low = lancet_blue, high = lancet_red, name = "-log10(FDR)") +
    scale_size_continuous(range = c(2, 8), name = "Gene set size") +
    labs(x = "Normalized Enrichment Score (NES)", y = "",
         title = "GSEA: MSigDB Hallmark Pathways") +
    theme_lancet(11) +
    geom_vline(xintercept = 0, linetype = "dashed", color = "grey50")
  ggsave("analysis/gsea_dotplot.tiff", p_bubble, 
         width = 10, height = 7, dpi = 300, compression = "lzw")
  cat("GSEA 气泡图（柳叶刀风格，TIFF） -> analysis/gsea_dotplot.tiff\n")
}

# ==================== 11. 生成分析结果解释报告（保持不变） ====================
report_file <- "analysis/analysis_report.txt"
sink(report_file)
cat("===== TCGA 风险分组差异分析与GSEA报告 =====\n")
cat("生成时间: ", format(Sys.time()), "\n\n")
cat("1. 差异表达分析概述:\n")
cat("   比较组: 高风险组(1) vs 低风险组(0)\n")
cat("   总样本数:", length(label), "(低风险:", sum(label==0), ", 高风险:", sum(label==1), ")\n")
cat("   采用Welch t检验。\n")
cat("   差异基因 (p<0.05):", sum(pval<0.05), "\n")
cat("   差异基因 (FDR<0.05):", sum(FDR<0.05), "\n")
cat("   差异基因 (FDR<0.25):", sum(FDR<0.25), "\n")
cat("   上调基因 (logFC>1 & p<0.05):", sum(res$logFC>1 & res$p<0.05), "\n")
cat("   下调基因 (logFC<-1 & p<0.05):", sum(res$logFC< -1 & res$p<0.05), "\n")
cat("   上调基因 (logFC>1 & FDR<0.25):", sum(res$logFC>1 & res$FDR<0.25), "\n")
cat("   下调基因 (logFC<-1 & FDR<0.25):", sum(res$logFC< -1 & res$FDR<0.25), "\n\n")
cat("2. 火山图解读:\n")
cat("   水平虚线: p=0.05; 垂直虚线: |log2FC|=1.\n")
cat("   颜色编码: FDR<0.25的上调基因标记为红色, 下调为蓝色; p<0.05但FDR>=0.25标记为橙色/浅蓝.\n")
cat("   标记基因为最显著的30个(|logFC|>1, FDR<0.25)基因。\n\n")
cat("3. GSEA结果 (Hallmark基因集):\n")
if (nrow(gsea_out)>0) {
  cat("   共分析", nrow(gsea_out), "个通路。\n")
  sig05 <- sum(gsea_out$FDR < 0.05, na.rm=TRUE)
  sig10 <- sum(gsea_out$FDR < 0.10, na.rm=TRUE)
  sig25 <- sum(gsea_out$FDR < 0.25, na.rm=TRUE)
  cat("   FDR<0.05:", sig05, "个; FDR<0.10:", sig10, "个; FDR<0.25:", sig25, "个.\n")
  if (sig05>0) {
    cat("   显著富集的通路 (FDR<0.05):\n")
    sig_path <- gsea_out[gsea_out$FDR < 0.05, ]
    for (i in 1:nrow(sig_path)) {
      cat(sprintf("     %s: NES=%+.3f, p=%.4f, FDR=%.4f\n",
                  sig_path$pathway[i], sig_path$NES[i], sig_path$pval[i], sig_path$FDR[i]))
    }
  } else {
    cat("   没有通路达到FDR<0.05显著性，可能需扩大样本或调整阈值。\n")
  }
  cat("\n   GSEA条形图展示了所有通路的NES; 气泡图显示了NES、基因集大小和FDR的关系。\n")
} else {
  cat("   无GSEA结果。\n")
}
cat("4. 热图: 展示前50个|logFC|最大的差异基因(p<0.05)的表达模式，行标准化。\n")
cat("5. 山峦图: 展示TNFA通路中最显著的6个基因在两组中的表达密度分布。\n\n")
cat("===== 报告结束 =====\n")
sink()
cat("分析结果报告 ->", report_file, "\n")

cat("\n===== 分析完成 =====\n")
cat("输出文件位于 ./analysis/ 目录下，所有图片均为 TIFF 格式，尺寸统一为 10×7 英寸\n")