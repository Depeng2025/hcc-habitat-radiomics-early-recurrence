# -*- coding: utf-8 -*-
"""
Generate an English Supplementary Materials document (SCI journal style) per the
supplementary requirements listed at the end of the manuscript:
  Table S1: MRI equipment, sequences, and acquisition parameters across centers
  Table S2: Complete Hallmark GSEA results (all 50 gene sets)
  Table S3: The 18 LASSO-selected features in the final radiomics signature
  Figure S1: Comparison of eight machine learning classifiers (ROC + radar)
  Figure S2: Restricted cubic spline of mixed_RADSCORE vs early recurrence
"""
import os, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import pandas as pd
from docx import Document
from docx.shared import Pt, Cm, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from PIL import Image

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE_DIR)

# ============================================================
# Data
# ============================================================
gsea = pd.read_csv(os.path.join(ROOT, '第七步', 'output', 'gsea_results.csv'))
gsea = gsea.sort_values('NES', ascending=False).reset_index(drop=True)
gsea['sig'] = (gsea['NES'].abs() > 1) & (gsea['FDR q-val'] < 0.25)
n_up = int(((gsea['NES'] > 0) & gsea['sig']).sum())
n_dn = int(((gsea['NES'] < 0) & gsea['sig']).sum())

xl = pd.ExcelFile(os.path.join(ROOT, '第一步', 'output', 'Variable_Selection_Results.xlsx'))
lasso = xl.parse('Radscore_Formula_mixed')
lasso = lasso.reindex(lasso['Coefficient_standardized'].abs().sort_values(ascending=False).index)

PHASE_MAP = {'AP': 'Arterial phase (AP)', 'PVP': 'Portal venous phase (PVP)',
             'EP': 'Equilibrium phase (EP)'}
CLASS_MAP = {
    'glrlm': 'GLRLM', 'glszm': 'GLSZM', 'ngtdm': 'NGTDM',
    'glcm': 'GLCM', 'gldm': 'GLDM', 'firstorder': 'First-order',
}

def decode(feat):
    parts = feat.split('_')
    hab = parts[0]
    if len(parts) == 2 and parts[1] == 'ratio':
        return hab, 'Phase-independent', 'Shape (habitat volume fraction)'
    phase = PHASE_MAP.get(parts[1], parts[1])
    cls = CLASS_MAP.get(parts[2], parts[2])
    return hab, phase, cls

# MRI parameters (reuse existing Supplementary Materials.docx Table S1)
src = Document(os.path.join(ROOT, 'Supplementary Materials.docx'))
mri_tab = src.tables[0]
mri_header = None
mri_rows = []
for i, r in enumerate(mri_tab.rows):
    cells = [c.text.replace('\n', ' ').strip() for c in r.cells]
    if i == 1:
        mri_header = cells
    elif i >= 2:
        mri_rows.append(cells)

# ============================================================
# Build document
# ============================================================
doc = Document()
normal = doc.styles['Normal']
normal.font.name = 'Times New Roman'
normal.font.size = Pt(10.5)
normal._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

def set_run(r, size=10, bold=False, italic=False):
    r.font.size = Pt(size)
    r.bold = bold
    r.italic = italic
    r.font.name = 'Times New Roman'

def add_caption(text, bold=False, size=10.5):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    set_run(r, size=size, bold=bold)

def add_note(text, size=9):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(10)
    r = p.add_run(text)
    set_run(r, size=size, italic=True)

def add_page_break():
    doc.add_page_break()

def fill_table(header, rows, col_widths=None, first_col_left=True):
    table = doc.add_table(rows=1 + len(rows), cols=len(header))
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for j, h in enumerate(header):
        c = table.cell(0, j)
        c.text = ''
        run = c.paragraphs[0].add_run(h)
        set_run(run, size=10, bold=True)
        c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    for ri, row in enumerate(rows):
        for j, val in enumerate(row):
            c = table.cell(ri + 1, j)
            c.text = ''
            run = c.paragraphs[0].add_run(str(val))
            set_run(run, size=9.5)
            c.paragraphs[0].alignment = (
                WD_ALIGN_PARAGRAPH.LEFT if (j == 0 and first_col_left) else WD_ALIGN_PARAGRAPH.CENTER)
    if col_widths:
        for j, w in enumerate(col_widths):
            for r in table.rows:
                r.cells[j].width = Cm(w)
    return table

# ---- Title ----
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
tr = tp.add_run('Supplementary Materials')
set_run(tr, size=14, bold=True)

# ============================================================
# Table S1 — MRI parameters
# ============================================================
add_caption('Table S1. MRI equipment, sequences, and acquisition parameters across participating centers')
fill_table(mri_header, mri_rows,
           col_widths=[2.0, 3.2, 1.8, 1.6, 1.4, 1.9, 1.9, 2.0, 1.9])
add_note('Abbreviations: T1WI, T1-weighted imaging; T2WI, T2-weighted imaging; '
         'FS-T1WI, fat-suppressed T1-weighted imaging; CET1WI, contrast-enhanced T1-weighted imaging; '
         'HBP, hepatobiliary phase. MRI was performed on 3.0-T scanners (GE Discovery MR750, uMR880, and '
         'MAGNETOM Vida) using abdominal phased-array coils. Gadoxetic acid (Gd-EOB-DTPA, Primovist®, '
         'Bayer AG) was administered intravenously at 0.025 mmol/kg.')

add_page_break()

# ============================================================
# Table S2 — GSEA
# ============================================================
add_caption('Table S2. Complete Hallmark gene set enrichment analysis results (recurrent versus non-recurrent tumors)')

def fmt_p(v):
    if pd.isna(v):
        return '—'
    if v < 0.001:
        return '< 0.001'
    return f'{v:.4f}'

gsea_rows = []
for _, r in gsea.iterrows():
    direction = 'Upregulated' if r['NES'] > 0 else 'Downregulated'
    nes = f"{r['NES']:+.3f}"
    fdr = fmt_p(r['FDR q-val'])
    nom = fmt_p(r['NOM p-val'])
    mark = '' if r['sig'] else '†'
    gsea_rows.append([r['Term'] + mark, direction, nes, fdr, nom])
fill_table(['Hallmark gene set', 'Direction (recurrent vs non-recurrent)', 'NES',
            'FDR q-value', 'Nominal P value'],
           gsea_rows, col_widths=[6.0, 3.8, 1.8, 2.0, 2.2])
add_note(f'Gene set enrichment analysis was performed on all 20,530 tested genes ranked by the t-statistic '
         f'(gseapy prerank; 1,000 permutations, seed 42) across all 50 MSigDB Hallmark gene sets. '
         f'Gene sets with |NES| > 1 and FDR < 0.25 were considered significant ({n_up} upregulated and '
         f'{n_dn} downregulated in recurrent tumors). A dagger (†) denotes gene sets that did not meet '
         f'the significance threshold and are listed for completeness. NES > 0 indicates enrichment '
         f'(activation) in recurrent tumors; NES < 0 indicates suppression.')

add_page_break()

# ============================================================
# Table S3 — LASSO features
# ============================================================
add_caption('Table S3. The 18 LASSO-selected features included in the final radiomics signature')
lasso_rows = []
for idx, (_, r) in enumerate(lasso.iterrows(), 1):
    feat = r['Feature']
    hab, phase, cls = decode(feat)
    b_std = f"{r['Coefficient_standardized']:+.4f}"
    b_orig = f"{r['Coefficient_original_scale']:+.6g}"
    lasso_rows.append([str(idx), feat, hab, phase, cls, b_std, b_orig])
fill_table(['No.', 'Feature', 'Habitat', 'Phase', 'Feature class',
            'Standardized coefficient', 'Original-scale coefficient'],
           lasso_rows, col_widths=[1.0, 5.4, 1.5, 2.8, 2.6, 2.0, 2.2], first_col_left=False)
add_note('Abbreviations: GLCM, gray-level co-occurrence matrix; GLDM, gray-level dependence matrix; '
         'GLRLM, gray-level run length matrix; GLSZM, gray-level size zone matrix; NGTDM, neighboring '
         'gray-tone difference matrix. H1, H2, and H3 denote three intratumoral habitats, and PERI5 denotes '
         'the 5-mm peritumoral region; AP, PVP, and EP denote the arterial, portal venous, and equilibrium '
         '(delayed) phases, respectively. All features were z-score standardized (mean 0, SD 1) using '
         'training-set statistics before LASSO. The standardized coefficient is the LASSO coefficient on '
         'the z-scored scale; the original-scale coefficient applies to raw feature values. H2_ratio is a '
         'morphological habitat volume fraction computed directly from the segmentation mask and is '
         'independent of contrast phase. The 18 features comprised 7 from PERI5, 4 from H1, 5 from H2, '
         'and 2 from H3.')

add_page_break()

# ============================================================
# Figure S1 — eight classifiers (2x2 grid, legend below)
# ============================================================
fig1_files = [
    (os.path.join(ROOT, '第二步', 'output', 'roc_curves_training_set.tiff'), 3.1),
    (os.path.join(ROOT, '第二步', 'output', 'roc_curves_validation_set.tiff'), 3.1),
    (os.path.join(ROOT, '第二步', 'output', 'radar_chart_training_set.tiff'), 3.1),
    (os.path.join(ROOT, '第二步', 'output', 'radar_chart_validation_set.tiff'), 3.1),
]
grid = doc.add_table(rows=2, cols=2)
grid.alignment = WD_TABLE_ALIGNMENT.CENTER
for k, (fpath, w_in) in enumerate(fig1_files):
    im = Image.open(fpath)
    aspect = im.size[1] / im.size[0]
    cell = grid.cell(k // 2, k % 2)
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(fpath, width=Inches(w_in), height=Inches(w_in * aspect))

add_caption('Figure S1. Comparison of eight machine learning classifiers. '
            '(A, B) Receiver operating characteristic (ROC) curves for the training (A) and validation (B) cohorts; '
            '(C, D) radar charts of overall performance for the training (C) and validation (D) cohorts. '
            'Eight classifiers—AdaBoost, decision tree, Gaussian naive Bayes, k-nearest neighbors, logistic '
            'regression, multilayer perceptron, support vector machine, and XGBoost—were compared. '
            'XGBoost achieved the highest training AUC (0.880) and a validation AUC of 0.851, which did not differ '
            'significantly from logistic regression, the best-performing classifier in the validation cohort '
            '(AUC 0.854; DeLong P = 0.798). Given the small training–validation AUC gap and the absence of '
            'evident overfitting, XGBoost was selected as the final model.', size=9.5)

add_page_break()

# ============================================================
# Figure S2 — RCS (legend below)
# ============================================================
rcs_path = os.path.join(ROOT, '第五步', 'output', 'RCS_OR_Curve.tiff')
im = Image.open(rcs_path)
aspect = im.size[1] / im.size[0]
w_in = 5.6
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run()
run.add_picture(rcs_path, width=Inches(w_in), height=Inches(w_in * aspect))

add_caption('Figure S2. Restricted cubic spline (RCS) of the relationship between mixed_RADSCORE and early '
            'recurrence risk. The solid line represents the odds ratio (OR) after adjustment for AFP, with the '
            'median training-set score (mixed_RADSCORE = −0.23) as the reference (OR = 1); the shaded band '
            'denotes the 95% confidence interval, and the dashed line marks OR = 1. The recurrence risk increased '
            'monotonically with increasing mixed_RADSCORE. The test for nonlinearity was not significant '
            '(P = 0.383; χ² = 1.918, df = 2). Within the central 90% of the score distribution, the OR '
            'ranged from 0.17 to 3.43; estimates at the extremes of the score range are less precise owing to '
            'sparse data and should be interpreted with caution.', size=9.5)

# ============================================================
# Save
# ============================================================
out_path = os.path.join(ROOT, '补充资料_English.docx')
doc.save(out_path)
print('SAVED:', out_path)
