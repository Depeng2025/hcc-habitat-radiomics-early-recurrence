# -*- coding: utf-8 -*-
"""
=====================================================================
STEP 5: RCS 限制性立方样条分析 (mixed_RADSCORE → HCC风险)
=====================================================================
展示核心连续变量 mixed_RADSCORE(联合影像组学评分) 与 HCC 风险的非线性剂量-反应关系。

图1: RCS OR曲线 - mixed_RADSCORE 与 HCC 调整OR (95%CI), 含拐点标注 (中央90%范围)
图2: RCS 预测概率曲线 - mixed_RADSCORE 对 HCC 预测概率的影响 (协变量固定在均值)
图3: 亚组RCS - 按性别分层 (Sex)
图4: 亚组RCS - 按年龄分层 (Age <60 vs >=60)
图5: RCS森林图 - 关键评分水平的调整OR (对数刻度)

方法: 限制性立方样条(Harrell方法) + 逻辑回归
  主分析: 4个节点 (5%, 35%, 65%, 95% 分位数)
  亚组分析: 3个节点 (5%, 50%, 95%) + 中央90%暴露范围 (小亚组样本受限, 提高稳定性)
  参考值: mixed_RADSCORE 训练集中位数 (OR=1)
  调整协变量: AFP (同最终术前预测模型)
  非线性检验: 样条项联合Wald检验
  OR曲线95%CI: delta方法 (含网格与参考预测间的协方差项, Var(diff)=se²grid+se²ref-2Cov)

输入: 第一步/output/train_selected.xlsx + 第一步/input/Train.csv (按case_id合并)
输出: 第五步/output/
  - RCS_OR_Curve.tiff                  (RCS OR曲线, 含拐点标注)
  - RCS_Predicted_Probability.tiff     (RCS预测概率曲线)
  - RCS_Subgroup_Sex.tiff              (亚组RCS: 按性别分层)
  - RCS_Subgroup_Age.tiff              (亚组RCS: 按年龄分层)
  - RCS_Forest_Plot.tiff               (RCS森林图)
  - rcs_results.xlsx                   (样条系数/节点/非线性检验/曲线数据/效应表)
  - rcs_summary.txt                    (分析总结)

依赖库: pandas, numpy, scipy, statsmodels, matplotlib, openpyxl, Pillow
=====================================================================
"""

import os
import io
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy import stats
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from PIL import Image
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 配置
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STEP1_DIR = os.path.join(os.path.dirname(BASE_DIR), '第一步')
STEP1_OUT = os.path.join(STEP1_DIR, 'output')
CLIN_INPUT_DIR = os.path.join(STEP1_DIR, 'input')
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

LABEL_COL = 'label'
EXPOSURE = 'mixed_RADSCORE'             # 连续暴露变量 (联合影像组学评分)
OUTCOME = 'label'                       # HCC 结局
COVARIATES = ['AFP']                         # 调整协变量 (术前预测模型, 不含术后分化)
N_KNOTS = 4                             # 主分析节点数 (5%,35%,65%,95%)
SUBGROUP_KNOTS = 3                      # 亚组节点数 (5%,50%,95%; 小样本稳定)
N_GRID = 100                            # 绘图网格点数
EFFECT_LEVELS = [-2.0, -1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5]  # 效应表/森林图水平
AGE_CUT = 60                            # 年龄分层切点
SUBGROUP_YMAX = 12.0                    # 亚组图OR显示上限 (CI在尾部被截断)
Z_ALPHA = 1.96                          # 95%CI

# 图件风格
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['DejaVu Sans', 'Arial'],
    'axes.unicode_minus': False,
})

# ============================================================
# 通用TIFF保存 (PNG→Pillow tiff_lzw, 项目统一约定)
# ============================================================
def safe_savefig(fig, path, **kwargs):
    dpi = kwargs.get('dpi', 300)
    base, ext = os.path.splitext(path)
    n = 1
    while True:
        try:
            if ext.lower() in ('.tiff', '.tif'):
                buf = io.BytesIO()
                fig.savefig(buf, format='png', dpi=dpi, bbox_inches='tight')
                buf.seek(0)
                Image.open(buf).convert('RGB').save(
                    path, format='TIFF', compression='tiff_lzw', dpi=(dpi, dpi))
            else:
                fig.savefig(path, **kwargs)
            return path
        except (PermissionError, OSError):
            n += 1
            path = f"{base}_{n}{ext}"
            if n > 50:
                raise
            print(f"  文件被占用, 保存为: {path}")

# ============================================================
# RCS 基函数 (Harrell方法)
# ============================================================
def rcs_basis(x, knots):
    """限制性立方样条基函数.
    Returns: (n, k-1) 数组, 第一列是x, 其余是样条项
    """
    x = np.asarray(x, dtype=float)
    k = np.sort(np.asarray(knots, dtype=float))
    n_k = len(k)
    k_min, k_max = k[0], k[-1]

    # 第一个基函数 = x
    X = [x.copy()]

    # 后续基函数 (Harrell公式)
    for j in range(1, n_k - 1):
        kj = k[j]
        term = np.maximum(x - kj, 0) ** 3 \
               - np.maximum(x - k_min, 0) ** 3 * (k_max - kj) / (k_max - k_min) \
               - np.maximum(x - k_max, 0) ** 3 * (kj - k_min) / (k_max - k_min)
        X.append(term)

    return np.column_stack(X)

# ============================================================
# 加载数据 (train_selected.xlsx 按case_id合并临床变量, 同第3/4步)
# ============================================================
print("Loading data...")
df = pd.read_excel(os.path.join(STEP1_OUT, 'train_selected.xlsx'))
clin = pd.read_csv(os.path.join(CLIN_INPUT_DIR, 'Train.csv'))
df[LABEL_COL] = df[LABEL_COL].astype(int)
df['case_id'] = df['case_id'].astype(str)
clin['case_id'] = clin['case_id'].astype(str)
df = df.merge(clin[['case_id'] + COVARIATES + ['Sex', 'Age']], on='case_id', how='left')
for c in COVARIATES + ['Sex', 'Age']:
    df[c] = pd.to_numeric(df[c], errors='coerce')
print(f"训练集: {len(df)} 例, HCC阳性: {int(df[OUTCOME].sum())} ({df[OUTCOME].mean()*100:.1f}%)")
print(f"{EXPOSURE} 范围: [{df[EXPOSURE].min():.3f}, {df[EXPOSURE].max():.3f}]")

y = df[OUTCOME].values
x = df[EXPOSURE].values

# 完整案例分析 (所有协变量非缺失)
valid_mask = np.ones(len(df), dtype=bool)
for c in COVARIATES:
    valid_mask &= df[c].notna().values
df = df[valid_mask].reset_index(drop=True)
y = df[OUTCOME].values
x = df[EXPOSURE].values
print(f"完整案例: {len(df)}")

# 节点位置 (主分析: 5%, 35%, 65%, 95% 分位数, Harrell标准)
knots = np.quantile(x, [0.05, 0.35, 0.65, 0.95])
print(f"主分析节点: {np.round(knots, 4)}")

# 参考值 = 训练集中位数 (OR=1, 相对"中位患者")
REF_VALUE = float(np.median(x))
print(f"参考值 (中位数): {REF_VALUE:.4f}")

# 主分析OR曲线的暴露范围 = 中央90% (5th-95th分位数, 避免稀疏尾部外推)
X_LO, X_HI = np.quantile(x, [0.05, 0.95])
print(f"主分析曲线范围 (中央90%): [{X_LO:.3f}, {X_HI:.3f}]")

# ============================================================
# RCS 逻辑回归 (调整协变量)
# ============================================================
print("\n拟合RCS逻辑回归 (调整协变量)...")
X_rcs = rcs_basis(x, knots)

# 设计矩阵: 截距 + RCS基函数 + 协变量
X_covs = df[COVARIATES].values
X_full = np.column_stack([np.ones(len(x)), X_rcs, X_covs])
model = sm.GLM(y, X_full, family=sm.families.Binomial()).fit()

# 提取系数
coefs = model.params
cov = model.cov_params()

# 系数名称: const, x, spline_1, spline_2, ..., covariates
basis_names = ['const'] + [EXPOSURE] + [f'spline_{i}' for i in range(1, len(knots)-1)] + COVARIATES
print(f"RCS模型: {len(knots)-1} 个{EXPOSURE}基函数 + {len(COVARIATES)} 个协变量")

# RCS基函数的列索引 (0=const, 1=x, 2..k-1=splines)
spline_cols = list(range(2, len(knots)))  # 仅样条项

# ============================================================
# 非线性检验 (样条项联合Wald检验, 调整后)
# ============================================================
print("\n非线性检验 (调整协变量)...")
# H0: 所有样条项系数=0 (即线性关系)
if len(spline_cols) >= 1:
    R = np.zeros((len(spline_cols), len(coefs)))
    for i, idx in enumerate(spline_cols):
        R[i, idx] = 1
    beta_spline = R @ coefs
    cov_spline = R @ cov @ R.T
    chi2 = beta_spline @ np.linalg.inv(cov_spline) @ beta_spline
    p_nonlinear = stats.chi2.sf(chi2, len(spline_cols))
    print(f"非线性检验 (样条项联合Wald): chi2={chi2:.3f}, p={p_nonlinear:.4f}")
else:
    p_nonlinear = np.nan
    print("样条项不足, 无法做非线性检验")

# ============================================================
# 计算调整OR曲线 (协变量固定在均值)
# ============================================================
print("\n计算调整OR曲线...")
x_grid = np.linspace(X_LO, X_HI, N_GRID)
X_grid_rcs = rcs_basis(x_grid, knots)

# 协变量固定在均值
cov_mean = df[COVARIATES].mean().values

# 构建网格设计矩阵: 截距 + RCS(x_grid) + 协变量均值
X_grid_full = np.column_stack([np.ones(len(x_grid)), X_grid_rcs, np.tile(cov_mean, (len(x_grid), 1))])

# 参考值设计矩阵 (mixed_RADSCORE=REF_VALUE, 协变量同样均值)
X_ref_rcs = rcs_basis(np.array([REF_VALUE]), knots)
X_ref_full = np.column_stack([np.ones(1), X_ref_rcs, cov_mean.reshape(1, -1)])

# 预测logit
logit_pred = X_grid_full @ coefs
logit_ref = X_ref_full @ coefs

# delta方法 SE: Var(logit) = X @ cov_RCS @ X.T (仅RCS部分变化, 协变量固定)
nk = len(knots)
X_grid_var = X_grid_full[:, :nk]
X_ref_var = X_ref_full[:, :nk]
cov_rcs = cov[:nk, :nk]

se_pred = np.sqrt(np.diag(X_grid_var @ cov_rcs @ X_grid_var.T))
se_ref = np.sqrt(X_ref_var @ cov_rcs @ X_ref_var.T)[0]

# OR相对参考值
logit_diff = logit_pred - logit_ref
or_values = np.exp(logit_diff)

# 正确delta方法: Var(grid-ref) = Var(grid)+Var(ref)-2Cov(grid,ref) (含协方差项)
cov_gr = X_grid_var @ cov_rcs @ X_ref_var.T          # (n, 1)
var_diff = se_pred**2 + se_ref**2 - 2 * cov_gr[:, 0]
se_diff = np.sqrt(np.clip(var_diff, 0, None))
or_ci_low = np.exp(logit_diff - Z_ALPHA * se_diff)
or_ci_high = np.exp(logit_diff + Z_ALPHA * se_diff)

# 任意水平处的OR + CI (效应表/森林图用; 直接对样条求值, 支持中央90%以外的稀疏尾部)
def or_at(lev):
    X_lev_rcs = rcs_basis(np.array([lev]), knots)
    X_lev_full = np.column_stack([np.ones(1), X_lev_rcs, cov_mean.reshape(1, -1)])
    X_lev_var = X_lev_full[:, :nk]
    logit_lev = X_lev_full @ coefs
    diff = logit_lev - logit_ref
    se_lev = np.sqrt(X_lev_var @ cov_rcs @ X_lev_var.T)[0]
    cov_lev_ref = (X_lev_var @ cov_rcs @ X_ref_var.T)[0, 0]
    var_d = se_lev**2 + se_ref**2 - 2 * cov_lev_ref
    se_d = np.sqrt(max(var_d, 0))
    return (float(np.exp(diff)[0]),
            float(np.exp(diff - Z_ALPHA * se_d)[0]),
            float(np.exp(diff + Z_ALPHA * se_d)[0]))

# ============================================================
# 图1: 增强RCS OR曲线 (拐点标注 + 斜率变化)
# ============================================================
print("\n绘制增强RCS OR曲线 (拐点标注)...")

# 拐点 = OR/logit 上升最快的点
slopes = np.gradient(logit_pred, x_grid)
max_slope_idx = np.argmax(slopes)
inflection_x = x_grid[max_slope_idx]
inflection_or = or_values[max_slope_idx]
print(f"拐点(OR上升最快): {EXPOSURE}={inflection_x:.3f}, OR={inflection_or:.2f}")

fig, ax = plt.subplots(figsize=(10, 7))
ax.plot(x_grid, or_values, color='#1E8CE6', linewidth=2.5, label=f'OR ({EXPOSURE})')
ax.fill_between(x_grid, or_ci_low, or_ci_high, color='#1E8CE6', alpha=0.2, label='95% CI')
ax.axhline(y=1, color='black', linestyle='--', linewidth=1.5, label='OR = 1 (reference)')
# 参考值竖线
ax.axvline(x=REF_VALUE, color='gray', linestyle=':', linewidth=1, alpha=0.7,
           label=f'Reference (median): {REF_VALUE:.2f}')

# 标注节点
for k in knots:
    ax.axvline(x=k, color='orange', linestyle=':', linewidth=1, alpha=0.5)

# 标注拐点 (OR上升最快处)
ax.axvline(x=inflection_x, color='red', linestyle='--', linewidth=1.5,
           label=f'Inflection: {inflection_x:.3f}')
ax.scatter(inflection_x, inflection_or, color='red', s=80, zorder=5)

# 标注非线性p值
if not np.isnan(p_nonlinear):
    sig_str = "P<0.001" if p_nonlinear < 0.001 else f"P={p_nonlinear:.3f}"
    ax.text(0.98, 0.98, f'Non-linearity {sig_str}',
            transform=ax.transAxes, ha='right', va='top',
            bbox=dict(boxstyle='round', fc='wheat', alpha=0.8), fontsize=12)

ax.set_xlabel('Mixed Radiomics Score (mixed_RADSCORE)', fontsize=13)
ax.set_ylabel('Adjusted Odds Ratio (OR)', fontsize=13)
ax.set_title('RCS Curve: Mixed Radiomics Score and HCC Risk', fontsize=15, fontweight='bold')
ax.set_ylim(0, max(or_ci_high.max() * 1.15, 2.5))
ax.legend(loc='upper left', fontsize=10)
ax.grid(True, linestyle='--', alpha=0.3)
for s in ['top', 'right']:
    ax.spines[s].set_visible(False)
plt.tight_layout()
rcs_or_path = safe_savefig(fig, os.path.join(OUTPUT_DIR, 'RCS_OR_Curve.tiff'))
plt.close()
print(f"  RCS OR曲线: {rcs_or_path}")

# ============================================================
# 图2: RCS 预测概率曲线 (协变量固定在均值) + 暴露分布直方图
# ============================================================
print("\n绘制RCS预测概率曲线...")
pred_prob = 1 / (1 + np.exp(-logit_pred))

fig, ax = plt.subplots(figsize=(10, 7))
ax.plot(x_grid, pred_prob, color='#E67E22', linewidth=2.5, label='Predicted probability')
ax.axvline(x=REF_VALUE, color='gray', linestyle=':', linewidth=1, alpha=0.7,
           label=f'Reference (median): {REF_VALUE:.2f}')
for k in knots:
    ax.axvline(x=k, color='orange', linestyle=':', linewidth=1, alpha=0.5)
ax.axvline(x=inflection_x, color='red', linestyle='--', linewidth=1.5,
           label=f'Inflection: {inflection_x:.3f}')

# 暴露分布直方图 (右轴)
ax2 = ax.twinx()
counts, bins, _ = ax2.hist(x, bins=30, color='#95A5A6', alpha=0.35, edgecolor='white')
ax2.set_ylabel('Frequency', fontsize=12)
ax2.set_yticks([])
ax2.set_ylim(0, counts.max() * 1.5)

ax.set_xlabel('Mixed Radiomics Score (mixed_RADSCORE)', fontsize=13)
ax.set_ylabel('Predicted Probability of HCC', fontsize=13)
ax.set_title('RCS Predicted Probability: Mixed Radiomics Score and HCC Risk',
             fontsize=15, fontweight='bold')
ax.legend(loc='upper left', fontsize=10)
ax.grid(True, linestyle='--', alpha=0.3)
for s in ['top', 'right']:
    ax.spines[s].set_visible(False)
plt.tight_layout()
rcs_prob_path = safe_savefig(fig, os.path.join(OUTPUT_DIR, 'RCS_Predicted_Probability.tiff'))
plt.close()
print(f"  RCS预测概率曲线: {rcs_prob_path}")

# ============================================================
# 亚组RCS函数 (3节点 + 中央90%暴露范围, 提高小亚组稳定性)
# ============================================================
def fit_subgroup_rcs(sub_df):
    """对子集拟合3节点RCS逻辑回归 (中央90%范围), 返回OR曲线 + 有效样本量."""
    sub_x = sub_df[EXPOSURE].values
    qlo, qhi = np.quantile(sub_x, [0.05, 0.95])
    keep = (sub_x >= qlo) & (sub_x <= qhi)
    sub = sub_df[keep]
    if len(sub) < 30:
        return None
    sy = sub[OUTCOME].values
    sx = sub[EXPOSURE].values
    sknots = np.quantile(sx, [0.05, 0.5, 0.95])

    sub_X_rcs = rcs_basis(sx, sknots)
    sub_covs = sub[COVARIATES].values
    sub_X_full = np.column_stack([np.ones(len(sy)), sub_X_rcs, sub_covs])
    try:
        sub_model = sm.GLM(sy, sub_X_full, family=sm.families.Binomial()).fit()
    except Exception as e:
        print(f"  子集拟合失败: {e}")
        return None

    sub_coefs = sub_model.params
    sub_cov = sub_model.cov_params()

    # 网格 (中央90%范围)
    sub_grid = np.linspace(sx.min(), sx.max(), N_GRID)
    sub_grid_rcs = rcs_basis(sub_grid, sknots)
    sub_cov_mean = sub[COVARIATES].mean().values

    # 网格和参考的设计矩阵 (参考值统一用全局中位数, 便于亚组间比较)
    G_full = np.column_stack([np.ones(len(sub_grid)), sub_grid_rcs,
                              np.tile(sub_cov_mean, (len(sub_grid), 1))])
    R_full = np.column_stack([np.ones(1), rcs_basis(np.array([REF_VALUE]), sknots),
                              sub_cov_mean.reshape(1, -1)])

    logit_g = G_full @ sub_coefs
    logit_r = R_full @ sub_coefs

    # delta方法 SE (含协方差项)
    snk = len(sknots)
    G_var = G_full[:, :snk]
    R_var = R_full[:, :snk]
    cov_rcs_sub = sub_cov[:snk, :snk]
    se_g = np.sqrt(np.diag(G_var @ cov_rcs_sub @ G_var.T))
    se_r = np.sqrt(R_var @ cov_rcs_sub @ R_var.T)[0]
    cov_gr = G_var @ cov_rcs_sub @ R_var.T
    var_d = se_g**2 + se_r**2 - 2 * cov_gr[:, 0]
    se_d = np.sqrt(np.clip(var_d, 0, None))

    diff = logit_g - logit_r
    return (sub_grid, np.exp(diff),
            np.exp(diff - Z_ALPHA * se_d), np.exp(diff + Z_ALPHA * se_d),
            len(sub), sknots)

# ============================================================
# 图3: 亚组RCS - 按性别分层
# ============================================================
print("\n绘制亚组RCS曲线 (性别分层, 3节点+中央90%)...")
fig, ax = plt.subplots(figsize=(10, 7))
colors_sub = {'Male': '#1E8CE6', 'Female': '#E74C3C'}
subgroup_summary = []

for sex_val, gname in [(1, 'Male'), (0, 'Female')]:
    sub = df[df['Sex'] == sex_val]
    if len(sub) < 50:
        print(f"  跳过 {gname}: n={len(sub)} < 50")
        continue
    res = fit_subgroup_rcs(sub)
    if res is None:
        continue
    g_grid, g_or, g_lo, g_hi, n_eff, sk = res
    color = colors_sub[gname]
    ax.plot(g_grid, g_or, color=color, linewidth=2.5, label=f'{gname} (n={n_eff})')
    ax.fill_between(g_grid, np.clip(g_lo, 0.01, SUBGROUP_YMAX),
                    np.clip(g_hi, 0.01, SUBGROUP_YMAX), color=color, alpha=0.15)
    subgroup_summary.append(
        f"  Sex={gname}: n={len(sub)} (中央90% n={n_eff}), 阳性 {int(sub[OUTCOME].sum())}, "
        f"OR范围 [{g_or.min():.2f}, {g_or.max():.2f}], 3节点={np.round(sk, 3)}")
    print(subgroup_summary[-1])

ax.axhline(y=1, color='black', linestyle='--', linewidth=1.5, label='OR = 1')
ax.set_ylim(0, SUBGROUP_YMAX)
ax.set_xlabel('Mixed Radiomics Score (mixed_RADSCORE)', fontsize=13)
ax.set_ylabel('Adjusted Odds Ratio (OR)', fontsize=13)
ax.set_title('RCS by Sex: Mixed Radiomics Score and HCC Risk', fontsize=15, fontweight='bold')
ax.text(0.99, 0.02, f'CI truncated at OR={SUBGROUP_YMAX:.0f} for display; '
                     'curves within central 90% of subgroup exposure',
        transform=ax.transAxes, ha='right', va='bottom', fontsize=8, color='gray')
ax.legend(loc='upper left', fontsize=10)
ax.grid(True, linestyle='--', alpha=0.3)
for s in ['top', 'right']:
    ax.spines[s].set_visible(False)
plt.tight_layout()
rcs_sex_path = safe_savefig(fig, os.path.join(OUTPUT_DIR, 'RCS_Subgroup_Sex.tiff'))
plt.close()
print(f"  RCS性别分层: {rcs_sex_path}")

# ============================================================
# 图4: 亚组RCS - 按年龄分层 (<60 vs >=60)
# ============================================================
print("\n绘制亚组RCS曲线 (年龄分层, 3节点+中央90%)...")
fig, ax = plt.subplots(figsize=(10, 7))
colors_age = {f'<{AGE_CUT}': '#27AE60', f'>={AGE_CUT}': '#8E44AD'}

for age_mask, aname in [(df['Age'] < AGE_CUT, f'<{AGE_CUT}'),
                        (df['Age'] >= AGE_CUT, f'>={AGE_CUT}')]:
    sub = df[age_mask]
    if len(sub) < 50:
        print(f"  跳过 {aname}: n={len(sub)} < 50")
        continue
    res = fit_subgroup_rcs(sub)
    if res is None:
        continue
    g_grid, g_or, g_lo, g_hi, n_eff, sk = res
    color = colors_age[aname]
    ax.plot(g_grid, g_or, color=color, linewidth=2.5, label=f'{aname} (n={n_eff})')
    ax.fill_between(g_grid, np.clip(g_lo, 0.01, SUBGROUP_YMAX),
                    np.clip(g_hi, 0.01, SUBGROUP_YMAX), color=color, alpha=0.15)
    subgroup_summary.append(
        f"  Age {aname}: n={len(sub)} (中央90% n={n_eff}), 阳性 {int(sub[OUTCOME].sum())}, "
        f"OR范围 [{g_or.min():.2f}, {g_or.max():.2f}], 3节点={np.round(sk, 3)}")
    print(subgroup_summary[-1])

ax.axhline(y=1, color='black', linestyle='--', linewidth=1.5, label='OR = 1')
ax.set_ylim(0, SUBGROUP_YMAX)
ax.set_xlabel('Mixed Radiomics Score (mixed_RADSCORE)', fontsize=13)
ax.set_ylabel('Adjusted Odds Ratio (OR)', fontsize=13)
ax.set_title(f'RCS by Age Group: Mixed Radiomics Score and HCC Risk', fontsize=15, fontweight='bold')
ax.text(0.99, 0.02, f'CI truncated at OR={SUBGROUP_YMAX:.0f} for display; '
                     'curves within central 90% of subgroup exposure',
        transform=ax.transAxes, ha='right', va='bottom', fontsize=8, color='gray')
ax.legend(loc='upper left', fontsize=10)
ax.grid(True, linestyle='--', alpha=0.3)
for s in ['top', 'right']:
    ax.spines[s].set_visible(False)
plt.tight_layout()
rcs_age_path = safe_savefig(fig, os.path.join(OUTPUT_DIR, 'RCS_Subgroup_Age.tiff'))
plt.close()
print(f"  RCS年龄分层: {rcs_age_path}")

# ============================================================
# 输出结果Excel
# ============================================================
print("\n输出结果...")
wb = Workbook()
header_font = Font(bold=True, color='FFFFFF', size=11)
header_fill = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
thin = Side(style='thin')
border = Border(left=thin, right=thin, top=thin, bottom=thin)

def write_df(ws, dataframe, start_row=1):
    for j, col in enumerate(dataframe.columns, 1):
        cell = ws.cell(row=start_row, column=j, value=str(col))
        cell.font = header_font; cell.fill = header_fill; cell.border = border
    for i, (_, row) in enumerate(dataframe.iterrows()):
        for j, col in enumerate(dataframe.columns, 1):
            val = row[col]
            cell = ws.cell(row=start_row+1+i, column=j,
                           value=round(val, 4) if isinstance(val, float) else val)
            cell.font = Font(size=10); cell.border = border
    for j, col in enumerate(dataframe.columns, 1):
        width = max(dataframe[col].astype(str).str.len().max()+3, len(col)+3, 10)
        ws.column_dimensions[get_column_letter(j)].width = min(width, 50)
    return start_row + len(dataframe) + 1

# Sheet1: 样条系数
ws1 = wb.active
ws1.title = "RCS Coefficients"
coef_rows = []
for i, name in enumerate(basis_names):
    coef_rows.append({
        'Basis': name,
        'Coefficient': coefs[i],
        'SE': np.sqrt(cov[i, i]),
        'z': coefs[i] / np.sqrt(cov[i, i]),
        'P_value': 2 * (1 - stats.norm.cdf(abs(coefs[i] / np.sqrt(cov[i, i])))),
    })
r = write_df(ws1, pd.DataFrame(coef_rows))

# Sheet2: 节点位置
ws2 = wb.create_sheet("Knots")
knot_rows = [{'Knot': f'k{i+1}',
              'Percentile': ['5%','35%','65%','95%'][i] if N_KNOTS==4 else f'{(i+1)/(N_KNOTS+1)*100:.0f}%',
              'Value': knots[i]} for i in range(N_KNOTS)]
r = write_df(ws2, pd.DataFrame(knot_rows))

# Sheet3: 非线性检验
ws3 = wb.create_sheet("Nonlinearity Test")
test_rows = [{
    'Test': 'Wald test for non-linearity',
    'Chi-square': chi2 if not np.isnan(p_nonlinear) else np.nan,
    'df': len(spline_cols) if not np.isnan(p_nonlinear) else np.nan,
    'P_value': p_nonlinear,
}]
r = write_df(ws3, pd.DataFrame(test_rows))

# Sheet4: 曲线数据 (中央90%范围)
ws4 = wb.create_sheet("Curve Data")
curve_rows = [{
    EXPOSURE: x_grid[i], 'OR': or_values[i],
    'OR_CI_low': or_ci_low[i], 'OR_CI_high': or_ci_high[i]
} for i in range(len(x_grid))]
r = write_df(ws4, pd.DataFrame(curve_rows))

# Sheet5: RCS效应表 - 不同评分水平的调整OR (相对中位参考, 精确求值)
ws5 = wb.create_sheet("Effect Table")
effect_rows = []
or_ref, _, _ = or_at(REF_VALUE)
effect_rows.append({
    EXPOSURE: REF_VALUE,
    'Adjusted OR': '1.00 (Reference)',
    'OR_low': 1.0, 'OR_high': 1.0,
    'P_value': 'Reference',
    'In_central90': 'yes',
})
for lev in EFFECT_LEVELS:
    or_v, ci_lo, ci_hi = or_at(lev)
    in90 = 'yes' if (X_LO <= lev <= X_HI) else 'no (sparse tail)'
    effect_rows.append({
        EXPOSURE: lev,
        'Adjusted OR': f"{or_v:.2f} ({ci_lo:.2f}-{ci_hi:.2f})",
        'OR_low': ci_lo, 'OR_high': ci_hi,
        'P_value': '<0.05' if (ci_lo > 1 or ci_hi < 1) else '>=0.05',
        'In_central90': in90,
    })
r = write_df(ws5, pd.DataFrame(effect_rows))

# ============================================================
# 图5: 森林图 (Forest Plot) - RCS效应 (对数刻度)
# ============================================================
print("\n绘制RCS森林图 (对数刻度)...")
fig, ax = plt.subplots(figsize=(10, 7))

# 倒序显示 (参考值在最下)
plot_levels = EFFECT_LEVELS[::-1]  # [1.5, 1.0, ..., -2.0]
y_pos = np.arange(len(plot_levels) + 1)  # 最后一行 = 参考值

# 先计算所有水平, 确定x轴范围
level_ors = {lev: or_at(lev) for lev in plot_levels}

max_label_x = 2.0
for i, lev in enumerate(plot_levels):
    or_v, ci_lo, ci_hi = level_ors[lev]
    ax.scatter(or_v, i, marker='s', color='#1E8CE6', s=50, zorder=5)
    ax.hlines(i, ci_lo, ci_hi, color='#1E8CE6', linewidth=2)
    # 须线
    ax.plot([ci_lo, ci_lo], [i-0.2, i+0.2], color='#1E8CE6', linewidth=1.5)
    ax.plot([ci_hi, ci_hi], [i-0.2, i+0.2], color='#1E8CE6', linewidth=1.5)
    label_txt = f'{or_v:.2f} ({ci_lo:.2f}-{ci_hi:.2f})'
    # 右侧标注OR值 (对数偏移)
    ax.text(ci_hi * 1.25, i, label_txt, va='center', fontsize=10)
    max_label_x = max(max_label_x, ci_hi * 1.25)

# 参考值行 (菱形, 最下方)
ref_row = len(plot_levels)
ax.scatter(1.0, ref_row, marker='D', color='black', s=60, zorder=5)
ax.axhline(y=ref_row, color='gray', linestyle='--', linewidth=0.5, alpha=0.5)
ax.text(1.25, ref_row, '1.00 (Reference)', va='center', fontsize=10)

# 参考线 OR=1
ax.axvline(x=1, color='black', linestyle='--', linewidth=1.5)

# 设置y轴
ax.set_yticks(y_pos)
ax.set_yticklabels([f'{EXPOSURE}={lev:.1f}' for lev in plot_levels] + ['Reference (median)'],
                   fontsize=11)

ax.set_xscale('log')
ax.set_xlim(0.02, max_label_x * 1.05)
ax.set_xlabel('Adjusted Odds Ratio (95% CI, log scale)', fontsize=13)
ax.set_ylabel('', fontsize=12)
ax.set_title('RCS Effect: Mixed Radiomics Score and HCC Risk (Forest Plot)',
             fontsize=14, fontweight='bold')
ax.grid(True, axis='x', linestyle='--', alpha=0.3)
for s in ['top', 'right']:
    ax.spines[s].set_visible(False)
plt.tight_layout()
forest_path = safe_savefig(fig, os.path.join(OUTPUT_DIR, 'RCS_Forest_Plot.tiff'))
plt.close()
print(f"  RCS森林图: {forest_path}")

xlsx_path = os.path.join(OUTPUT_DIR, 'rcs_results.xlsx')
wb.save(xlsx_path)
print(f"  Excel: {xlsx_path}")

# ============================================================
# 总结文本
# ============================================================
summary_txt = []
summary_txt.append("=" * 58)
summary_txt.append("STEP 5: RCS 分析结果总结 (HCC Habitat Radiomics)")
summary_txt.append("=" * 58)
summary_txt.append(f"暴露: {EXPOSURE} (联合影像组学评分)")
summary_txt.append(f"结局: HCC (label)")
summary_txt.append(f"样本: {len(df)} (训练集, 合并临床变量后)")
summary_txt.append(f"调整协变量: {', '.join(COVARIATES)} (术前预测模型)")
summary_txt.append(f"主分析节点数: {N_KNOTS} (5%, 35%, 65%, 95%)")
summary_txt.append(f"主分析节点位置: {np.round(knots, 4)}")
summary_txt.append(f"主分析曲线范围 (中央90%): [{X_LO:.3f}, {X_HI:.3f}]")
summary_txt.append(f"参考值: {EXPOSURE}={REF_VALUE:.4f} (训练集中位数, OR=1)")
summary_txt.append("")
summary_txt.append(f"非线性检验: chi2={chi2:.3f}, df={len(spline_cols)}, P={p_nonlinear:.4f}")
summary_txt.append("")
# OR范围 (中央90%)
min_or_idx = np.argmin(or_values)
max_or_idx = np.argmax(or_values)
summary_txt.append(f"OR范围 (中央90%): {or_values.min():.3f} ({EXPOSURE}={x_grid[min_or_idx]:.3f}) ~ "
                   f"{or_values.max():.3f} ({EXPOSURE}={x_grid[max_or_idx]:.3f})")
summary_txt.append(f"拐点(OR上升最快): {EXPOSURE}={inflection_x:.3f}, OR={inflection_or:.2f}")
summary_txt.append("")
summary_txt.append("[RCS效应表] (相对中位参考; In_central90=no 表示超出中央90%的稀疏尾部外推)")
for row in effect_rows:
    summary_txt.append(f"  {EXPOSURE}={row[EXPOSURE]:+.2f}: OR={row['Adjusted OR']} "
                       f"({row['P_value']}) [{row['In_central90']}]")
summary_txt.append("")
summary_txt.append("[亚组RCS] (3节点+中央90%, 参考值同为全局中位数)")
summary_txt.extend(subgroup_summary)
summary_txt.append("")
summary_txt.append("[方法学说明]")
summary_txt.append("  - OR曲线95%CI采用delta方法, 含网格与参考预测间的协方差项")
summary_txt.append("  - 亚组分析样本有限, 改用3节点(5/50/95%)并限制在中央90%暴露范围以稳定估计")
summary_txt.append("  - 亚组图CI在OR=12处截断显示; 小样本亚组高分段估计欠精确")
summary_txt.append("")
summary_txt.append("[输出文件]")
summary_txt.append("  RCS_OR_Curve.tiff (RCS OR曲线, 含拐点标注)")
summary_txt.append("  RCS_Predicted_Probability.tiff (RCS预测概率曲线)")
summary_txt.append("  RCS_Subgroup_Sex.tiff (亚组RCS: 性别分层)")
summary_txt.append("  RCS_Subgroup_Age.tiff (亚组RCS: 年龄分层)")
summary_txt.append("  RCS_Forest_Plot.tiff (RCS森林图, 对数刻度)")
summary_txt.append("  rcs_results.xlsx (系数/节点/检验/效应表/曲线数据)")

txt_path = os.path.join(OUTPUT_DIR, 'rcs_summary.txt')
with open(txt_path, 'w', encoding='utf-8') as f:
    f.write('\n'.join(summary_txt))
print(f"  总结: {txt_path}")

# ============================================================
print("\n" + "=" * 58)
print("STEP 5 RCS 分析完成!")
print("=" * 58)
print(f"所有输出在: {OUTPUT_DIR}")
