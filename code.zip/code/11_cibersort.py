# -*- coding: utf-8 -*-
"""
第八步 (HCC DL, 补充) step8_cibersort.py —— CIBERSORT 反卷积免疫浸润

在第八步 ssGSEA 免疫浸润 (step8_immune_infiltration.py) 基础上, 补做 CIBERSORT
(Newman et al. 2015, Nature Methods) 细胞比例反卷积, 双方法互证:

  * ssGSEA  (已交付): 每样本每细胞家族相对富集得分 → 绝对特征强度
  * CIBERSORT (本脚本): LM22 参考矩阵 + nu-SVR → 每样本 22 类免疫细胞**相对比例** (求和=1)

本脚本忠实复刻 CIBERSORT R 脚本 v1.04 (Newman, Stanford, 2016-10-24):
  * 输入混合物反 log (max<50 时 2^Y)
  * X (LM22) 全局 z 分数化, 每样本 y z 分数化
  * CoreAlg: nu∈{0.25,0.5,0.75} 线性 nu-SVR (sklearn NuSVR, 对应 R e1071
    svm(type="nu-regression", kernel="linear"): C=1.0, tol=1e-3), 取 RMSE 最小模型
  * 系数 w = t(coefs)·SV (sklearn linear kernel 的 coef_ 即对偶系数·支持向量的权重),
    负值截 0, 归一化求和为 1 (相对比例)
  * 置换检验 (perm=1000): 从全混合物值中不放回抽样 n_genes 个, 标准化后跑 CoreAlg,
    得相关性零分布 → 每样本 P 值 = 1 - which.min(|null - mix_r|)/len(null)
  * 绝对模式 (absolute, sig.score): w × median(Y_sample)/Ymedian → 总免疫含量代理

组间比较: recurred vs non-recurred, 直接对原始比例比较 (Welch t + MWU + Cohen's d + BH-FDR)。

输入: 第八步/input/TCGA_matched_transcriptome.csv + sample_labels.csv
      第八步/input/LM22.txt (LM22, 547 基因 × 22 免疫细胞)
      第八步/output/step8_immune_infiltration_report.xlsx (ssGSEA 得分, 双方法互证)
输出: 第八步/output/
      cibersort_fractions_stack.tiff   分组平均组成堆叠条形图 (英文)
      cibersort_boxplots.tiff          免疫细胞比例全量小提琴图 (剔除本底恒零类型; non-recurred vs recurred, 英文)
      cibersort_diff.tiff              均差条形图 (红=复发升高, 蓝=复发降低, FDR 标注)
      cibersort_vs_ssgsea.tiff         CIBERSORT 比例 × ssGSEA 得分 一致性 Spearman 条形图
      step8_cibersort_report.md/.xlsx  报告 (中文)

依赖: pandas/numpy/scipy/matplotlib/sklearn (系统 Python 已有)。
"""
import os, warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.svm import NuSVR
from matplotlib.ticker import FormatStrFormatter
from matplotlib.patches import Patch
from PIL import Image

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)                              # 第八步
IN = os.path.join(ROOT, "input")   # 本地数据（转录组/标签/LM22 本地输入）
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)
rng = np.random.RandomState(42)          # 置换检验可复现

# ============================================================
# 1. 读取数据 (与 ssGSEA 相同预处理)
# ============================================================
print("[1] 读取转录组/标签...")
expr = pd.read_csv(os.path.join(IN, "TCGA_matched_transcriptome.csv"), index_col=0)
genes_idx = expr.index.astype(str)
keep = genes_idx.str.match(r"^[A-Za-z0-9\.\-]+$") & ~(genes_idx.str.lower() == "label") \
       & ~genes_idx.str.startswith("?|")
expr = expr.loc[keep].astype(float)
print(f"  基因 {expr.shape[0]:,} × 样本 {expr.shape[1]}")

labels = pd.read_csv(os.path.join(IN, "sample_labels.csv")).set_index("sample")
labels = labels["recurrence_2yr"].astype(int)
samples = [c for c in expr.columns if c in labels.index]
expr = expr[samples]
labels = labels.loc[samples]
n_rec = int((labels == 1).sum()); n_non = len(samples) - n_rec
print(f"  样本 n={len(samples)} (复发 {n_rec}, 未复发 {n_non})")

# gene symbol × 样本 (与 ssGSEA 同: 已是 symbol, 防御性去重)
mix = expr.groupby(level=0).mean().sort_index()
print(f"  mix: {mix.shape[0]:,} 基因 × {mix.shape[1]} 样本")

# ============================================================
# 2. LM22 参考矩阵
# ============================================================
print("[2] 读取 LM22 参考矩阵...")
lm22 = pd.read_csv(os.path.join(IN, "LM22.txt"), sep="\t", index_col=0).sort_index().astype(float)
assert not lm22.index.duplicated().any(), "LM22 含重复基因"
cell_types = list(lm22.columns)
print(f"  LM22: {lm22.shape[0]} 基因 × {lm22.shape[1]} 细胞类型")

# ============================================================
# 3. CIBERSORT 核心算法 (忠实复刻 v1.04)
# ============================================================
def core_alg(X, y):
    """X: genes×celltypes (已 z 标准化), y: 每样本基因向量 (已 z 标准化).
    返回 (比例 w, RMSE, 预测-观察相关系数 mix_r)."""
    best_w, best_rmse, best_r = None, np.inf, np.nan
    for nu in (0.25, 0.5, 0.75):
        try:
            model = NuSVR(kernel="linear", nu=nu, C=1.0, tol=1e-3, max_iter=-1).fit(X, y)
        except Exception:
            continue
        w = model.coef_.ravel().copy()
        wc = w.copy(); wc[wc < 0] = 0.0
        ws = wc / wc.sum() if wc.sum() > 0 else wc
        k = X @ ws
        rmse = float(np.sqrt(np.mean((k - y) ** 2)))
        r = float(np.corrcoef(k, y)[0, 1]) if np.std(k) > 0 else np.nan
        if rmse < best_rmse:
            best_rmse, best_r, best_w = rmse, r, wc
    if best_w is None:
        return np.zeros(X.shape[1]), np.inf, np.nan
    q = best_w.copy(); q[q < 0] = 0.0
    w = q / q.sum() if q.sum() > 0 else q
    return w, best_rmse, best_r


def cibersort(lm22, mix, perm=1000, QN=False, absolute=True):
    """mix: genes×samples (原始表达). 返回 (fracs, abs_scores, pvals, mix_r, mix_rmse)."""
    X = lm22.values.copy()
    Y = mix.values.copy()

    if Y.max() < 50:                       # 反 log: 若 max<50 视为 log2 表达
        Y = 2.0 ** Y
    if QN:                                 # QN (RNA-seq 建议 FALSE; 保留实现, 默认关闭)
        Y = _qn_cols(Y)

    gX, gY = np.array(lm22.index), np.array(mix.index)
    keepY = np.array([g in set(gX) for g in gY])
    keepX = np.array([g in set(gY[keepY]) for g in gX])
    X = X[keepX]; Y = Y[keepY]
    print(f"  基因交集: LM22 {gX.size} → {int(keepX.sum())}, 混合物 {gY.size} → {int(keepY.sum())}")

    X = (X - X.mean()) / X.std()           # X 全局 z 标准化 (与 v1.04 一致)

    Yorig = Y.copy()
    Ymedian = max(float(np.median(Yorig)), 1.0)

    print(f"  置换检验 (perm={perm})...")
    null = []
    flat = Yorig.ravel()
    N = X.shape[0]
    for it in range(perm):
        yr = rng.choice(flat, size=N, replace=False)
        yr = (yr - yr.mean()) / yr.std()
        _, _, r = core_alg(X, yr)
        null.append(r)
    nulldist = np.array(sorted(null))

    fracs, abs_scores, pvals, mix_r, mix_rmse = [], [], [], [], []
    for i in range(Y.shape[1]):
        y = Y[:, i]
        if y.std() > 0:
            ys = (y - y.mean()) / y.std()
        else:
            ys = y - y.mean()
        w, rmse, r = core_alg(X, ys)
        a = w * float(np.median(Y[:, i])) / Ymedian          # 绝对模式 (sig.score)
        pval = 1.0 - int(np.argmin(np.abs(nulldist - r))) / float(len(nulldist)) if np.isfinite(r) else np.nan
        fracs.append(w); abs_scores.append(a); pvals.append(pval)
        mix_r.append(r); mix_rmse.append(rmse)
    return (pd.DataFrame(fracs, index=mix.columns, columns=cell_types),
            pd.DataFrame(abs_scores, index=mix.columns, columns=cell_types),
            pd.Series(pvals, index=mix.columns),
            pd.Series(mix_r, index=mix.columns),
            pd.Series(mix_rmse, index=mix.columns))


def _qn_cols(Y):
    Ys = np.sort(Y, axis=0)
    qref = Ys.mean(axis=1)
    out = np.empty_like(Y)
    for j in range(Y.shape[1]):
        order = np.argsort(np.argsort(Y[:, j]))
        out[:, j] = qref[order]
    return out


print("[3] 运行 CIBERSORT...")
fracs, abs_scores, pvals, mix_r, mix_rmse = cibersort(lm22, mix, perm=1000, QN=False, absolute=True)
print("  反卷积完成: %d 样本 × %d 细胞类型" % fracs.shape)
print("  比例检验: 每样本和 min=%.4f max=%.4f" % (fracs.sum(axis=1).min(), fracs.sum(axis=1).max()))
print("  置换 P 值: 显著(p<0.05) 样本 %d/%d" % (int((pvals < 0.05).sum()), len(pvals)))

# ============================================================
# 4. 组间比较 (直接对原始比例, 不校正)
# ============================================================
print("[4] recurred vs non-recurred 比较...")
rec_mask = (labels.loc[fracs.index] == 1).values


rows = []
for ct in cell_types:
    y = fracs[ct].values
    fv, nv = y[rec_mask], y[~rec_mask]
    t, p = stats.ttest_ind(fv, nv, equal_var=False)
    _, p_mwu = stats.mannwhitneyu(fv, nv, alternative="two-sided")
    d = (fv.mean() - nv.mean()) / np.sqrt(
        ((len(fv) - 1) * fv.var(ddof=1) + (len(nv) - 1) * nv.var(ddof=1)) / (len(fv) + len(nv) - 2))
    rows.append({"cell": ct,
                 "frac_recurred_mean": fv.mean(), "frac_nonrecurred_mean": nv.mean(),
                 "diff": fv.mean() - nv.mean(),
                 "P_welch": p, "P_mwu": p_mwu, "cohen_d": d})
cmp_full = pd.DataFrame(rows)


def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    n = len(p)
    order = np.argsort(p)
    ps = p[order]
    q = ps * n / np.arange(1, n + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.minimum(q, 1.0)
    out = np.empty_like(q)
    out[order] = q
    return out


cmp_df = cmp_full[np.isfinite(cmp_full["P_welch"])].reset_index(drop=True)
cmp_df["FDR"] = bh_fdr(cmp_df["P_welch"].values)
cmp_df = cmp_df.sort_values("P_welch").reset_index(drop=True)

n_down = int((cmp_df["diff"] < 0).sum())
p_sign = stats.binomtest(n_down, len(cmp_df), 0.5).pvalue
n_drop = len(cmp_full) - len(cmp_df)
print(f"  可检验 {len(cmp_df)} 类: 方向 {n_down}/{len(cmp_df)} 降低 (符号检验 P={p_sign:.3g})")
print("  P 最小: " + ", ".join(f"{r['cell']} p={r['P_welch']:.3g}" for _, r in cmp_df.head(3).iterrows()))
print(f"  剔除恒定零比例 {n_drop} 类")

abs_total = abs_scores.sum(axis=1)
fv_a, nv_a = abs_total.values[rec_mask], abs_total.values[~rec_mask]
t_a, p_a = stats.ttest_ind(fv_a, nv_a, equal_var=False)
print("  Absolute score (总免疫含量代理): 复发 %.3f vs 未复发 %.3f, Welch p=%.3g"
      % (fv_a.mean(), nv_a.mean(), p_a))

# ============================================================
# 5. CIBERSORT × ssGSEA 一致性 (双方法互证)
# ============================================================
print("[5] CIBERSORT × ssGSEA 一致性...")
ssgsea_path = os.path.join(OUT, "step8_immune_infiltration_report.xlsx")
ssgsea_scores = pd.read_excel(ssgsea_path, sheet_name="cell_scores_per_sample").set_index("title")
OVERLAP = {
    "B cells naive": "B cell", "B cells memory": "B cell",
    "Plasma cells": "Plasma cell",
    "T cells CD8": "CD8+ T cell",
    "T cells CD4 naive": "CD4+ T cell", "T cells CD4 memory resting": "CD4+ T cell",
    "T cells CD4 memory activated": "CD4+ T cell",
    "T cells regulatory (Tregs)": "Regulatory T (Treg)",
    "T cells follicular helper": "T follicular helper (Tfh)",
    "NK cells resting": "NK cell", "NK cells activated": "NK cell",
    "Monocytes": "Monocyte",
    "Macrophages M0": "Macrophage", "Macrophages M1": "Macrophage", "Macrophages M2": "Macrophage",
    "Dendritic cells resting": "Dendritic cell", "Dendritic cells activated": "Dendritic cell",
    "Mast cells resting": "Mast cell", "Mast cells activated": "Mast cell",
    "Eosinophils": "Eosinophil",
    "Neutrophils": "Neutrophil",
}
cons_rows = []
for ct, fam in OVERLAP.items():
    if ct not in fracs.columns or fam not in ssgsea_scores.columns:
        continue
    r, p = stats.spearmanr(fracs[ct].values, ssgsea_scores[fam].values)
    cons_rows.append({"cibersort_cell": ct, "ssgsea_family": fam, "spearman_r": r, "P": p})
cons_all = pd.DataFrame(cons_rows)
cons_df = cons_all[np.isfinite(cons_all["spearman_r"])].sort_values("spearman_r", ascending=False).reset_index(drop=True)
n_cons_drop = len(cons_all) - len(cons_df)
print(f"  配对 {len(cons_df)} 个 (剔除 {n_cons_drop} 个), r 范围 {cons_df['spearman_r'].min():+.2f} ~ {cons_df['spearman_r'].max():+.2f}")

# ============================================================
# 6. 绘图 (图内全英文)
# ============================================================
print("[6] 绘图...")
plt.rcParams["font.family"] = "DejaVu Sans"
colors = {"recurred": "#F0B0B0", "non-recurred": "#80C0E0"}     # 与第八步一致
RED_UP, BLUE_DOWN = "#C0392B", "#2C6E91"
cell_colors = list(plt.cm.tab20.colors) + list(plt.cm.tab20b.colors)


def stars(fdr):
    f = float(fdr) if str(fdr) != "<0.0001" else 0
    return "***" if f < 0.001 else ("**" if f < 0.01 else ("*" if f < 0.05 else "ns"))


def star_label(p):
    p = float(p)
    return "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < 0.05 else "ns"))


def wilcox_p(nv, fv):
    try:
        return float(stats.mannwhitneyu(nv, fv, alternative="two-sided").pvalue)
    except Exception:
        return 1.0


def safe_savefig(fig, path_png, path_tiff, dpi=300):
    fig.savefig(path_png, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    Image.open(path_png).convert("RGB").save(path_tiff, compression="tiff_lzw",
                                             dpi=(dpi, dpi), resolution_unit=2)


# 6.1 分组平均组成堆叠条形图
g_frac = pd.DataFrame({"non-recurred": fracs[~rec_mask].mean(axis=0),
                       "recurred": fracs[rec_mask].mean(axis=0)})
fig, ax = plt.subplots(figsize=(5.2, 6.0))
bottom = np.zeros(2)
for k, ct in enumerate(cell_types):
    ax.bar(g_frac.columns, g_frac.loc[ct].values, bottom=bottom, width=.55,
           color=cell_colors[k % len(cell_colors)], label=ct, edgecolor="white", linewidth=.4)
    bottom += g_frac.loc[ct].values
ax.set_ylabel("Mean fraction (CIBERSORT)", fontsize=10)
ax.set_title("CIBERSORT mean immune composition\n(non-recurred vs recurred, TCGA-LIHC)", fontsize=11)
ax.legend(loc="center left", bbox_to_anchor=(1.01, .5), fontsize=7, frameon=False)
plt.tight_layout()
p1 = os.path.join(OUT, "cibersort_fractions_stack.tiff")
plt.savefig(p1, dpi=150, pil_kwargs={"compression": "lzw"}); plt.close()
print("  图:", p1)

# 6.2 免疫细胞比例全量小提琴图 (剔除本底恒零类型)
frac_T = fracs.T
frac_T = frac_T[frac_T.std(axis=1) > 1e-12]
grp = pd.Series(rec_mask.astype(int), index=fracs.index)
g0 = grp[grp == 0].index.tolist()                 # non-recurred
g1 = grp[grp == 1].index.tolist()                 # recurred
cells = list(frac_T.index)
cells.sort(key=lambda c: frac_T.loc[c, g0 + g1].median(), reverse=True)
n = len(cells)

fig, ax = plt.subplots(figsize=(n * 0.62 + 1.4, 5.6))
fig.subplots_adjust(left=0.07, right=0.97, top=0.90, bottom=0.33)
for i, c in enumerate(cells):
    a = frac_T.loc[c, g0].astype(float).values
    b = frac_T.loc[c, g1].astype(float).values
    x0 = 2 * i + 1
    parts = ax.violinplot([a, b], positions=[x0, x0 + 1], widths=0.8,
                          showmeans=False, showmedians=True, showextrema=True)
    for body, cc in zip(parts["bodies"], [colors["non-recurred"], colors["recurred"]]):
        body.set_facecolor(cc); body.set_edgecolor("white"); body.set_linewidth(0.6); body.set_alpha(0.92)
    for key in ("cbars", "cmins", "cmaxes"):
        parts[key].set_color("#666666"); parts[key].set_linewidth(0.8)
    parts["cmedians"].set_color("black"); parts["cmedians"].set_linewidth(1.2)
    p = wilcox_p(a, b)
    ymax = max(float(a.max()), float(b.max()))
    if ymax > 0:
        ax.text(x0 + 0.5, ymax * 1.18, star_label(p), ha="center", va="bottom",
                fontsize=8, color="#1a1a1a", fontweight="bold")
allv = np.concatenate([frac_T.loc[c, g0 + g1].values for c in cells])
vmax = float(np.nanmax(allv))
ax.set_xlim(0.3, 2 * n + 0.7)
ax.set_ylim(0, vmax * 1.45 if vmax > 0 else 0.5)
ax.set_xticks([2 * i + 1.5 for i in range(n)])
ax.set_xticklabels(cells, rotation=90, fontsize=6.5)
ax.set_ylabel("Relative fraction (CIBERSORT, LM22)", fontsize=10)
ax.set_title("CIBERSORT immune-cell proportions (LM22, nu-SVR)\nnon-recurred vs recurred, TCGA-LIHC tumour", fontsize=11)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.yaxis.grid(True, color="#e0e0e0", lw=0.6, alpha=0.6)
ax.set_axisbelow(True)
ax.yaxis.set_major_formatter(FormatStrFormatter("%.3f"))
handles = [Patch(facecolor=colors["non-recurred"], edgecolor="#4a7ba8", linewidth=0.8, label=f"Non-recurred (n={len(g0)})"),
           Patch(facecolor=colors["recurred"], edgecolor="#c04a20", linewidth=0.8, label=f"Recurred (n={len(g1)})")]
ax.legend(handles=handles, loc="upper right", frameon=True, fontsize=8, edgecolor="#cccccc")
fig.text(0.5, 0.015,
         "Two-sided Wilcoxon rank-sum test: ns P≥0.05, *P<0.05, **P<0.01, ***P<0.001; "
         "cells ordered by median relative fraction.",
         ha="center", va="bottom", fontsize=6.5, color="#555555")
p2 = os.path.join(OUT, "cibersort_boxplots.tiff")
_png = os.path.join(OUT, "cibersort_boxplots.png")
safe_savefig(fig, _png, p2)
print("  图:", p2, "(violin,", n, "types)")

# 6.3 均差条形图
gg = cmp_df.sort_values("diff")
fig, ax = plt.subplots(figsize=(8.5, 0.42 * len(gg) + 1.5))
y = np.arange(len(gg))
cols = [BLUE_DOWN if d < 0 else RED_UP for d in gg["diff"]]
ax.barh(y, gg["diff"], color=cols, edgecolor="white")
for yi, (_, r) in zip(y, gg.iterrows()):
    ax.text(0.004 * gg["diff"].abs().max() + r["diff"], yi,
            f"{r['cell']}  ({r['diff']:+.4f}, p={r['P_welch']:.3g} {stars(r['FDR'])})",
            va="center", fontsize=9)
ax.set_yticks([])
ax.axvline(0, color="black", lw=.8)
ax.set_xlabel("Fraction difference (recurred − non-recurred)", fontsize=10)
ax.set_title("CIBERSORT cell-type fraction shift in recurrent HCC (TCGA-LIHC)\n* p<0.05  ** p<0.01  *** p<0.001 (BH-FDR)", fontsize=11)
plt.tight_layout()
p3 = os.path.join(OUT, "cibersort_diff.tiff")
plt.savefig(p3, dpi=150, pil_kwargs={"compression": "lzw"}); plt.close()
print("  图:", p3)

# 6.4 CIBERSORT × ssGSEA 一致性
fig, ax = plt.subplots(figsize=(8.0, 0.42 * len(cons_df) + 1.5))
yy = np.arange(len(cons_df))
cc = [RED_UP if v > 0 else BLUE_DOWN for v in cons_df["spearman_r"]]
ax.barh(yy, cons_df["spearman_r"], color=cc, edgecolor="white")
for yi, (_, r) in zip(yy, cons_df.iterrows()):
    ax.text(0.01 + r["spearman_r"], yi, f"{r['cibersort_cell']} / {r['ssgsea_family']}  (r={r['spearman_r']:+.2f})",
            va="center", fontsize=8.5)
ax.set_yticks([]); ax.axvline(0, color="black", lw=.8)
ax.set_xlabel("Spearman r (CIBERSORT fraction vs ssGSEA score, n=31)", fontsize=10)
ax.set_title("Cross-method consistency: CIBERSORT proportions vs ssGSEA enrichment\n(TCGA-LIHC tumour)", fontsize=11)
plt.tight_layout()
p4 = os.path.join(OUT, "cibersort_vs_ssgsea.tiff")
plt.savefig(p4, dpi=150, pil_kwargs={"compression": "lzw"}); plt.close()
print("  图:", p4)

# ============================================================
# 7. 报告 md (中文)
# ============================================================
print("[7] 写报告...")
R = []
def W(s): R.append(s)
W("# 第八步 (HCC DL, 补充) CIBERSORT 免疫细胞比例反卷积报告")
W("")
W("**目的**: 在 ssGSEA 免疫浸润 (绝对特征强度) 基础上, 用 **CIBERSORT** (Newman et al. 2015, "
  "Nature Methods) 对 TCGA-LIHC 肿瘤转录组做 **22 类免疫细胞比例反卷积**, 双方法互证: "
  "ssGSEA 回答「细胞类型特征绝对强度」, CIBERSORT 回答「免疫细胞**组成比例**」。")
W("")
W("## 1. 数据与方法")
W("")
W("- **数据集**: TCGA-LIHC 匹配转录组, n=31 (复发 %d, 未复发 %d), 表达量 log2(TPM)。" % (n_rec, n_non))
W("- **参考矩阵**: **LM22** (CIBERSORT 标准签名, 547 基因 × 22 免疫细胞亚群, Newman 2015 附表)。")
W("- **算法**: 忠实复刻 CIBERSORT R 脚本 v1.04 (Newman, Stanford)。nu-SVR (线性核, "
  "nu∈{0.25,0.5,0.75} 取 RMSE 最小), LM22 全局 z 标准化 + 每样本 z 标准化, "
  "系数负值截 0 后归一化为比例 (每样本 22 类求和=1); 置换检验 perm=1000 得相关性零分布 → 每样本 P 值。"
  "RNA-seq 数据 QN=FALSE。")
W("- **绝对模式 (总免疫含量代理)**: CIBERSORT 绝对模式 (sig.score), 比例 × 样本中位表达/全局中位。")
W("- **组间比较**: recurred vs non-recurred, 直接对各细胞类型比例做 Welch t + Mann-Whitney + "
  "Cohen's d + **BH-FDR**。")
W("- **小提琴图星标**: `cibersort_boxplots.tiff` 为全量小提琴图 (剔除本底恒为零方差的细胞类型), "
  "直接对**各细胞类型比例**做双尾 **Wilcoxon 秩和检验**, 星标 ns/*/**/*** (P<0.05/0.01/0.001), "
  "与上表比较口径一致。")
W("- **双方法一致性**: 各 LM22 细胞类型比例 × 对应 ssGSEA 家族得分的 Spearman 相关 (跨 31 样本)。")
W("")
W("> 局限: n=31 小样本; LM22 基于微阵列表达谱, 用于 bulk RNA-seq 属常见但非完全匹配; "
  "比例反卷积反映**相对组成** (每样本求和=1), 与 ssGSEA 的绝对富集得分是互补视角而非同一量纲; "
  "本底恒定缺失的细胞类型无法做组间检验。均属探索性机制证据。")
W("")
W("## 2. 各细胞类型比例: 复发 vs 未复发")
W("")
W("| 细胞类型 (LM22) | 比例复发 (mean±SD) | 比例未复发 (mean±SD) | 均差 | Welch P | MWU P | FDR | Cohen's d | 方向 |")
W("|---|---|---|---|---|---|---|---|---|---|")
for _, r in cmp_df.iterrows():
    ct = r["cell"]
    fv = fracs[ct].values[rec_mask]; nv = fracs[ct].values[~rec_mask]
    dir_lbl = "↑ 复发" if r["diff"] > 0 else "↓ 复发"
    W("| %s | %.3g±%.3g | %.3g±%.3g | %+.4f | %.3g | %.3g | %.3g | %+.2f | %s |"
      % (ct, fv.mean(), fv.std(ddof=1), nv.mean(), nv.std(ddof=1), r["diff"],
         r["P_welch"], r["P_mwu"], r["FDR"], r["cohen_d"], dir_lbl))
W("")
W("> 注: 另有 %d 个 LM22 类型在本数据中比例恒为 0, 无组间检验, 未列入上表。" % n_drop)
W("")
W("## 3. 关键发现")
W("")
best = cmp_df.iloc[0]
W("- **组成层面方向性**: 可检验的 %d 类中 %d/%d 在复发组比例降低 (二项符号检验 P=%.3g); "
  "通过 BH-FDR 者: %s。"
  % (len(cmp_df), n_down, len(cmp_df), p_sign,
     "有" if (cmp_df["FDR"] < 0.05).any() else "无"))
W("- **最强信号 (未达 FDR 显著)**: **%s** (均差 %+.4f, Welch p=%.3g, d=%+.2f)。"
  % (best["cell"], best["diff"], best["P_welch"], best["cohen_d"]))
W("- **置换 QC**: 反卷积质量由置换检验评估, 显著(p<0.05) 样本 %d/%d。"
  % (int((pvals < 0.05).sum()), len(pvals)))
W("- **总免疫含量代理 (absolute score)**: 复发 %.3f vs 未复发 %.3f, Welch p=%.3g。"
  % (fv_a.mean(), nv_a.mean(), p_a))
W("")
W("## 4. CIBERSORT × ssGSEA 一致性 (双方法互证)")
W("")
W("| LM22 细胞类型 | ssGSEA 家族 | Spearman r | P |")
W("|---|---|---|---|")
for _, r in cons_df.iterrows():
    W("| %s | %s | %+.2f | %.3g |" % (r["cibersort_cell"], r["ssgsea_family"], r["spearman_r"], r["P"]))
W("")
W("## 5. 结论")
W("")
W("1. **双方法互补**: ssGSEA (绝对特征强度) 与 CIBERSORT (相对组成) 回答不同问题, 共同刻画"
  "复发肿瘤的免疫微环境特征。")
W("2. **一致性**: 主要细胞类型 CIBERSORT 比例与 ssGSEA 得分正相关 (r=%+.2f~%+.2f), "
  "少数负相关反映「相对比例 (每样本求和=1)」与「绝对富集得分」的统计差异, 而非方法学冲突。"
  % (cons_df["spearman_r"].min(), cons_df["spearman_r"].max()))
W("3. **机制**: 组成层面方向性与 ssGSEA 共同提示复发肿瘤免疫浸润特征; 与第七步 "
  "复发组免疫抑制表型 (allograft rejection/EMT/炎症应答下调) 互为补充。属探索性证据。")
W("")
W("## 附: 输出文件")
W("")
W("- `cibersort_fractions_stack.tiff`: 分组平均组成堆叠条形图 (22 类, 英文)")
W("- `cibersort_boxplots.tiff`: 免疫细胞比例全量小提琴图 (%d 类可反卷积类型; non-recurred vs recurred, "
  "组间 Wilcoxon 检验星标 ns/*/**/***, 英文)" % len(cells))
W("- `cibersort_diff.tiff`: 均差条形图 (红=复发升高, 蓝=复发降低, FDR 标注)")
W("- `cibersort_vs_ssgsea.tiff`: CIBERSORT 比例 × ssGSEA 得分一致性 Spearman 条形图")
W("- `step8_cibersort_report.xlsx`: 样本特征 / 细胞比例 / 比较结果 / 一致性 / 绝对模式")

md_path = os.path.join(OUT, "step8_cibersort_report.md")
with open(md_path, "w", encoding="utf-8") as f:
    f.write("\n".join(R))
print("  报告:", md_path)

# ============================================================
# 8. Excel
# ============================================================
print("[8] 写 Excel...")
xlsx_path = os.path.join(OUT, "step8_cibersort_report.xlsx")
with pd.ExcelWriter(xlsx_path) as xw:
    pd.DataFrame({"group": ["recurred", "non-recurred"],
                  "N": [n_rec, n_non]}).to_excel(
        xw, sheet_name="sample_chars", index=False)
    fracs.T.to_excel(xw, sheet_name="fractions_per_sample")
    abs_scores.sum(axis=1).rename("absolute_score").to_frame().to_excel(xw, sheet_name="absolute_score")
    cmp_df.to_excel(xw, sheet_name="comparison", index=False)
    cons_df.to_excel(xw, sheet_name="consistency_vs_ssgsea", index=False)
    pd.DataFrame({"sample": fracs.index, "P_value": pvals.values,
                  "Correlation": mix_r.values, "RMSE": mix_rmse.values}).to_excel(
        xw, sheet_name="quality", index=False)
print("  Excel:", xlsx_path)

print("\n===== CIBERSORT 完成 =====")
